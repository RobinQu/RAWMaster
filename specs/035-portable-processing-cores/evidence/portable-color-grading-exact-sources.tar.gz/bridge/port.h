#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
void *z3_program(const char *library, void *metal_device,const char *wire,size_t bytes);
void *z3_surfaces(void *metal_device,uint32_t width,uint32_t height);
void *z3_texture(void *surfaces,uint32_t index);
typedef uint32_t (*ZCurrent)(void*,uint64_t);
int32_t z3_render(void *program,void *surfaces,const char *name,size_t n,uint64_t revision,ZCurrent current,void *authority);
void z3_release(void *obj);
#ifdef __cplusplus
}
#endif

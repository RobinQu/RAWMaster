#!/usr/bin/env python3
"""Replay the two RAW band fixture samples through the actual raster C ABI."""
import argparse
import ctypes as c
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path.cwd() / 'Modules/ImageEdit/tests'))
from replay_named_coverage import Coverage, digest, open_runtime, render


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('runtime', type=Path)
    args.add_argument('samples', type=Path)
    args.add_argument('output', type=Path)
    args.add_argument('--gpu', action='store_true')
    args = args.parse_args()
    library = open_runtime(args.runtime)
    cases = []
    for src in sorted(args.samples.glob('*.bin')):
        raw = src.read_bytes()[64:]
        assert len(raw) % 64 == 0
        count = len(raw) // 64
        assert count % 512 == 0
        pixels = b''.join(raw[k + 16:k + 32] for k in range(0, len(raw), 64))
        stock = b''.join(raw[k + 32:k + 48] for k in range(0, len(raw), 64))
        surface = b''.join(raw[k + 48:k + 64] for k in range(0, len(raw), 64))
        expected = memoryview(stock).cast('f')
        values = (c.c_float * (count * 4)).from_buffer_copy(pixels)
        wire = Path(str(src)+'.json').read_bytes()
        plan = c.c_void_p()
        assert library.rm_image_plan_open_v2(wire, len(wire), None, 0, int(args.gpu), c.byref(plan)) == 0
        try:
            result, elapsed = render(library, plan, 512, count // 512, values, (Coverage * 0)())
        finally:
            library.rm_image_plan_close_v1(plan)
        out = memoryview(result).cast('f')
        errors = [abs(a-b) for a,b in zip(out, expected)]
        assert result[12::16] == stock[12::16] and all(out[i] == 1.0 for i in range(3, len(out), 4))
        cases.append({'case': src.stem, 'pixels': count, 'recipeSHA': digest(wire),
            'sampleSHA': digest(src.read_bytes()), 'stockSHA': digest(stock), 'surfaceSHA': digest(surface),
            'outputSHA': digest(result),'maximumAbsolute': max(errors), 'over2e6Components': sum(v>2e-6 for v in errors),
            'sameAsStock': result == stock, 'sameAsMetalSurface': result == surface, 'elapsedMs': elapsed})
    assert len(cases) == 12
    document = {'runtimeSHA': digest(args.runtime.read_bytes()), 'backend': 'gpu' if args.gpu else 'cpu',
        'samplePixels': sum(i['pixels'] for i in cases), 'maximumAbsolute': max(i['maximumAbsolute'] for i in cases),
        'over2e6Components': sum(i['over2e6Components'] for i in cases), 'cases': cases}
    args.output.write_text(json.dumps(document, indent=2) + '\n')


if __name__ == '__main__':
    main()

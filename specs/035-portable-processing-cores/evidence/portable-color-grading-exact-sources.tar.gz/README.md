# 两源 RAW 的色轮和曲线对照

在 RAWMaster 仓库根目录将源码归档解到 `output/035-development/phase-ac/grade/`。
构建 Release 测试包，使用 `swift build -c release --build-tests -Xswiftc -enable-testing --jobs 7`。
`build-witness.sh` 链接本次 Release 的显影和显示对象。`GradeWitness.swift` 的输入依次是原片路径、同片旧画面的归档 JSON、本次输出 JSON 和逗号分隔的控件 ID。设置匹配的 `RAWMASTER_FLASHRAW_LIBRARY` 和封存的 `AB_IMAGE_RUNTIME`。直接半幅对照另将同一运行库复制到探针自己的 Swift 资源包，通过 `AC_VERIFY_NATIVE_HALF=1` 走正常 C ABI。借入 IOSurface 的完整原尺寸对照每次都执行。

普通矩阵选 `grading-balance,grading-blending,grading-luminance`。`AC_GRADE_COMPOUND=1`
添加两个非中性 PCHIP 曲线，使用相同旧引擎的完整重新显影作为显示参考。此组的半幅用两边共同的 GPU 采样器。`AC_EXTREME_WHEELS=1` 以 `grading-balance` 为模板替换参数，覆盖平衡、混合及亮度端点。

两组普通矩阵的独立逐行窗口包含同一原片像素、原引擎值和候选值。将每组的两源输出放在各自目录，通过 `python3 replay.py <runtime> <samples-dir> <report.json>` 重放 CPU。加 `--gpu` 重放 Metal 或 Vulkan。Linux 的软件 Vulkan 设备与复测方法记录在 `linux-revised.sh` 中，原片、输出窗口和编译产物未打包。

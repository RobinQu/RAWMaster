import CZRadial
import AppKit
import CoreImage
import CryptoKit
import Darwin
import Foundation
import Metal
import RAWMasterCore
import RAWMasterImage
@testable import RAWMasterImaging

@main private enum GradeWitness {
    static func context(_ name: String, queue: MTLCommandQueue? = nil) -> CIContext {
        let options: [CIContextOption: Any] = [
            .name: name, .workingColorSpace: DevelopmentColorEngineV3.linearSRGB,
            .workingFormat: CIFormat.RGBAf.rawValue, .cacheIntermediates: false, .memoryTarget: 512,
        ]
        if let queue { return CIContext(mtlCommandQueue: queue, options: options) }
        return CIContext(options: options)
    }

    static func milliseconds(_ begin: UInt64) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e6
    }

    static func peak() throws -> Int64 {
        var info = task_vm_info_data_t()
        var words = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.stride)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(words)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &words)
            }
        }
        guard status == KERN_SUCCESS else { throw DevelopmentError.invalidEncoding }
        return info.ledger_phys_footprint_peak
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func raster(_ pixels: PreviewPixels) throws -> Data {
        guard pixels.outputSize == CGSize(width: 2400, height: 1600) else { throw DevelopmentError.invalidEncoding }
        let frame = DevelopmentPreviewFrame(frameID: UUID(), image: pixels.image, sessionID: .init(),
            sourceGeneration: 1, consumerID: .init(), revision: 1, quality: .settled,
            canonicalPixelSize: pixels.nativeSize, outputPixelSize: pixels.outputSize, outputKey: "half-fit-probe", approximate: false)
        var bytes = Data(count: 2400 * 1600 * 4)
        try bytes.withUnsafeMutableBytes { try frame.copyDisplayRGBA8(into: $0) }
        return bytes
    }

    static func diff(_ expected: Data, _ actual: Data) -> [String: Any] {
        precondition(expected.count == actual.count && expected.count == 2400 * 1600 * 4)
        var changedPixels = 0, maxCode = 0, alphaChanges = 0, edgeChanges = 0, sum = 0
        expected.withUnsafeBytes { (left: UnsafeRawBufferPointer) in
            actual.withUnsafeBytes { (right: UnsafeRawBufferPointer) in
                for index in stride(from: 0, to: expected.count, by: 4) {
                    var changed = false
                    for channel in 0..<4 {
                        let error = abs(Int(left[index + channel]) - Int(right[index + channel]))
                        if error > 0 {
                            maxCode = max(maxCode, error)
                            sum += error
                            if channel == 3 { alphaChanges += 1 }
                            changed = true
                        }
                    }
                    if changed {
                        let x = (index / 4) % 2400
                        let y = (index / 4) / 2400
                        if x == 0 || x == 2399 || y == 0 || y == 1599 { edgeChanges += 1 }
                        changedPixels += 1
                    }
                }
            }
        }
        return ["changedPixels": changedPixels, "edgePixels": edgeChanges, "alphaValues": alphaChanges,
                "maxCodeDifference": maxCode, "meanAbsoluteCodeDifference": Double(sum) / Double(expected.count)]
    }

    static func snapshot(_ raw: URL) throws -> EditingSourceSnapshot {
        let hash = try RenderFiles.hash(raw)
        guard let size = try raw.resourceValues(forKeys:[.fileSizeKey]).fileSize else { throw DevelopmentError.unreadable }
        return .init(projectID: "035-curves",assetID: hash,contentSHA256: hash,byteCount: Int64(size),
                     admissionFingerprint: "curves-v3",sourceLocation: raw)
    }


    struct Uniforms {
        var shape: SIMD4<UInt32>
        var ellipse: SIMD4<Float>
        var adjust: SIMD4<Float>
        var tone: SIMD4<Float>
    }
    final class Authority {
        let check: () throws -> Void
        init(_ check: @escaping () throws -> Void){self.check=check}
    }
    static let authorityCallback: @convention(c) (UnsafeMutableRawPointer?,UInt64)->UInt32 = { ctx,revision in
        guard let ctx,revision>0 else{return 0}
        let object=Unmanaged<Authority>.fromOpaque(ctx).takeUnretainedValue()
        do {try object.check();return 1} catch {return 0}
    }
    static func pipeline(_ library: MTLLibrary,_ name: String,_ device: MTLDevice) throws -> MTLComputePipelineState {
        guard let code=library.makeFunction(name:name) else {throw DevelopmentV3Error.invalidGraph}
        return try device.makeComputePipelineState(function:code)
    }
    static func texture(_ dev: MTLDevice,_ w:Int,_ h:Int) throws -> MTLTexture {
        let layout=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:.rgba32Float,width:w,height:h,mipmapped:false)
        layout.storageMode = .private;layout.usage=[.shaderRead,.shaderWrite,.renderTarget]
        guard let t=dev.makeTexture(descriptor:layout) else {throw DevelopmentError.invalidEncoding};return t
    }
    static func stats(_ b:MTLBuffer)->[String:Any] {
        let s=b.contents().bindMemory(to:UInt32.self,capacity:7)
        return ["pixels":s[0],"changedPixels":s[1],"changedComponents":s[2],"alphaChanges":s[3],"maxAbs":Float(bitPattern:s[4]),"nonfinitePixels":s[5],"over2e6Pixels":s[6]]
    }
    static func process(raw:URL,archive:URL,out:URL,ids:Set<String>) throws {
        guard let device=MTLCreateSystemDefaultDevice(),let queue=device.makeCommandQueue(),
              let input=try JSONSerialization.jsonObject(with:Data(contentsOf:archive)) as? [String:Any],
              let ops=input["operations"] as? [[String:Any]] else {throw DevelopmentError.invalidEncoding}
        let opt=MTLCompileOptions();opt.mathMode = .fast
        let here=URL(fileURLWithPath:CommandLine.arguments[0]).deletingLastPathComponent().deletingLastPathComponent()
        let runtime = URL(fileURLWithPath: ProcessInfo.processInfo.environment["AB_IMAGE_RUNTIME"]!)
        let runtimeSeal = try RenderFiles.hash(runtime)
        let testLib=try device.makeLibrary(source:String(contentsOf:here.appendingPathComponent("measure.metal"),encoding:.utf8),options:opt)
        let sampler=try pipeline(testLib,"halfSample",device), export=try pipeline(testLib,"exportGrade",device)
        let comp=try pipeline(testLib,"compare",device), gather=try pipeline(testLib,"gatherGrade",device)
        let shot=try snapshot(raw)
        guard shot.contentSHA256 == input["sourceSHA256"] as? String else {throw DevelopmentV3Error.invalidGraph}
        let cap=try RenderFiles.verifiedPreviewCapture(shot)
        defer {try? FileManager.default.removeItem(at:cap.url.deletingLastPathComponent())}
        let check={try cap.requireCurrent(at:cap.url)}
        let uploaded=try FlashRawImageFactory.nativePreviewImage(capture:cap.url,rawDetails:nil,retainNativeTexture:true)
        let w=Int(uploaded.image.extent.width),h=Int(uploaded.image.extent.height)
        let pool=FlashRawCanonicalTexturePool(byteBudget:1024*1024*1024)
        let key=FlashRawCanonicalTextureKey(sourceKey:shot.contentSHA256,captureStamp:cap.stamp,contract:"ab-independent-grading",width:w,height:h)
        let pin=try pool.acquireNative(key){uploaded};defer{pin.release()}
        guard try pin.checkOpaqueUpload(pin.image,cancellation:check),let filter=CIRAWFilter(imageURL:cap.url) else {throw DevelopmentV3Error.invalidGraph}
        let wb=DevelopmentAsShotWhiteBalance(temperature:filter.neutralTemperature,tint:filter.neutralTint)
        var report=[[String:Any]]()
        for op in ops {
            guard let id=op["id"] as? String,ids.contains(id),let descriptions=op["stateDescriptions"] as? [[String:Any]],
                  let old=op["firstStateFullFrameDigests"] as? [String] else {continue}
            for (i,row) in descriptions.enumerated() {
                try autoreleasepool {
                    let bytes=try JSONSerialization.data(withJSONObject:row)
                    var recipe = try JSONDecoder().decode(DevelopmentRecipe.self, from: bytes)
                    guard var p = recipe.adjustmentsV3, p.masks.isEmpty, var grade = p.legacyBasis?.color?.grading,
                          try FlashRawImageFactory.applyInputAdjustments(p, to: pin.image, asShotWhiteBalance: wb) === pin.image else {
                        throw DevelopmentV3Error.invalidGraph
                    }
                    let extreme = ProcessInfo.processInfo.environment["AC_EXTREME_WHEELS"] == "1"
                    if extreme {
                        grade.blending = i==0 ? 0 : 100
                        grade.balance = i==0 ? -100 : 100
                        grade.midtones = .init(hueDegrees: 127, saturation: 80, luminance: i==0 ? -70 : 66)
                        grade.global = .init(hueDegrees: 291, saturation: 100, luminance: i==0 ? -100 : 100)
                        p.legacyBasis?.color?.grading = grade
                        recipe.adjustmentsV3 = p
                    }
                    let compound = ProcessInfo.processInfo.environment["AC_GRADE_COMPOUND"] == "1"
                    let wireGrade = try JSONSerialization.jsonObject(with: JSONEncoder().encode(grade))
                    var nodes: [[String: Any]] = [["id":"source","op":"source"], ["id":"grade","op":"color_grading_v2","image":"source","grading":wireGrade]]
                    var finalNode = "grade"
                    if compound {
                        let curve = DevelopmentCurve(points: [.init(x: 0, y: 0), .init(x: 0.26, y: 0.32),
                                                               .init(x: 0.68, y: 0.59), .init(x: 1, y: 1)])
                        let red = DevelopmentCurve(points: [.init(x: 0, y: 0), .init(x: 0.48, y: 0.53), .init(x: 1, y: 1)])
                        p.curves = .init(enabled: true, rgb: .init(curve: curve), red: .init(curve: red), algorithm: .legacyPCHIPV1)
                        recipe.adjustmentsV3 = p
                        var curvesOnly = p
                        curvesOnly.legacyBasis = nil
                        let table = try PreviewPortableCurvesLevels.recipe(curvesOnly)
                        guard let source = try JSONSerialization.jsonObject(with: table) as? [String: Any],
                              let operators = source["nodes"] as? [[String: Any]],
                              var curves = operators.first(where: { $0["id"] as? String == "curves-levels" }) else {
                            throw DevelopmentV3Error.invalidGraph
                        }
                        curves["image"] = "grade"
                        nodes.append(curves)
                        finalNode = "curves-levels"
                    }
                    let wire: [String: Any] = [
                        "version": 2, "working": "extended-linear-srgb-premul-f32", "output": finalNode, "nodes": nodes
                    ]
                    let wireData = try JSONSerialization.data(withJSONObject: wire, options: [.sortedKeys])
                    let direct = ProcessInfo.processInfo.environment["AC_VERIFY_NATIVE_HALF"] == "1"
                    let directPlan = direct ? try RAWMasterImageKernel.RasterPlan(recipe: wireData, backend: .cpu) : nil
                    let halfProgram = try directPlan.map { try RAWMasterImageKernel.NativeHalfProgram(recipe: $0, device: device) }
                    let params=Uniforms(shape:.init(UInt32(w),UInt32(h),0,256),ellipse:.zero,adjust:.zero,tone:.zero)
                    let ctx=context("z3-stock-develop");defer{ctx.clearCaches()}
                    let graph=try DevelopmentCanonicalFiniteGPU.$residentPhotoWorkingBudget.withValue(DevelopmentCanonicalFiniteGPU.workingSetLimit){
                        try DevelopmentRendererV3.develop(cap.url,recipe:recipe,suppliedRawBase:pin.image,context:ctx,residentGlobalSource:pin)
                    }
                    let stockDisplay=try raster(V3PreviewMaterializer.materialize(graph,context:ctx,maxPixel:2400))
                    let referenceDigest = digest(stockDisplay)
                    if !compound && !extreme, referenceDigest != old[i] { throw NSError(domain:"stock archive \(id) \(i)",code:1) }
                    ctx.clearCaches()
                    let bandContext=context("ab-grade-reference",queue:queue);defer{bandContext.clearCaches()}
                    let nativeStock=try texture(device,w,256), nativePort=try texture(device,w,256)
                    let halfStock=try texture(device,w/2,h/2),halfPort=try texture(device,w/2,h/2)
                    guard let nativeCounts=device.makeBuffer(length:32,options:.storageModeShared),let halfCounts=device.makeBuffer(length:32,options:.storageModeShared),
                          let record=device.makeBuffer(length:512*64,options:.storageModeShared) else {throw DevelopmentError.invalidEncoding}
                    memset(nativeCounts.contents(),0,32);memset(halfCounts.contents(),0,32)
                    var surfaceOwners:[Int:UnsafeMutableRawPointer]=[:]
                    let authority=Authority { try check();guard pin.isCurrent(for:pin.image) else {throw DevelopmentV3Error.invalidGraph} }
                    let json=String(decoding:wireData,as:UTF8.self)
                    guard let pg=z3_program(runtime.path,Unmanaged.passUnretained(device as AnyObject).toOpaque(),json,wireData.count) else {throw NSError(domain:"public program open",code:1)}
                    defer {for v in surfaceOwners.values {z3_release(v)};z3_release(pg)}
                    var prm=params
                    var samples=withUnsafeBytes(of:&prm){Data($0)}
                    func dispatch(_ cmd:MTLCommandBuffer,_ ps:MTLComputePipelineState,_ imgs:[MTLTexture],_ xs:Int,_ ys:Int,
                                  _ set:(MTLComputeCommandEncoder)->Void) throws {
                        guard let e=cmd.makeComputeCommandEncoder() else {throw DevelopmentError.invalidEncoding}
                        e.setComputePipelineState(ps);for (idx,t) in imgs.enumerated(){e.setTexture(t,index:idx)}
                        set(e);let grid=MTLSize(width:xs,height:ys,depth:1)
                        e.dispatchThreads(grid,threadsPerThreadgroup:.init(width:8,height:8,depth:1));e.endEncoding()
                    }
                    func compare(_ cmd:MTLCommandBuffer,_ x:MTLTexture,_ y:MTLTexture,_ b:MTLBuffer,_ ww:Int,_ hh:Int)throws{
                        var dims=SIMD2<UInt32>(UInt32(ww),UInt32(hh))
                        try dispatch(cmd,comp,[x,y],ww,hh){$0.setBuffer(b,offset:0,index:0);$0.setBytes(&dims,length:8,index:1)}
                    }
                    func drain(_ cmd:MTLCommandBuffer)throws{cmd.commit();cmd.waitUntilCompleted();guard cmd.status == .completed else{throw cmd.error ?? DevelopmentError.invalidEncoding}}
                    let ok:Bool?=try pin.withCheckedOpaqueTexture(for:pin.image,check:check){photo in
                        guard photo.pixelFormat == .rgba16Float,photo.width==w,photo.height==h else {throw DevelopmentV3Error.invalidGraph}
                        if let halfProgram, let directPlan {
                            let pass = MTLRenderPassDescriptor()
                            pass.colorAttachments[0].texture = halfPort
                            pass.colorAttachments[0].loadAction = .clear
                            pass.colorAttachments[0].storeAction = .store
                            pass.colorAttachments[0].clearColor = .init(red: 0, green: 0, blue: 0, alpha: 0)
                            guard let begin = queue.makeCommandBuffer(), let clear = begin.makeRenderCommandEncoder(descriptor: pass)
                            else { throw DevelopmentError.invalidEncoding }
                            clear.endEncoding()
                            try drain(begin)
                            try check()
                            try halfProgram.render(directPlan, input: photo, output: halfPort, revision: 1) { revision in
                                revision == 1 && (try? authority.check()) != nil
                            }
                            try check()
                        }
                        for y in stride(from:0,to:h,by:256){
                            try autoreleasepool {
                                try check()
                                let rows=min(256,h-y);prm.shape.z=UInt32(y);prm.shape.w=UInt32(rows)
                                let dest=CIRenderDestination(mtlTexture:nativeStock,commandBuffer:nil);dest.isFlipped=false;dest.isDithered=false;dest.isClamped=false;dest.alphaMode = .premultiplied;dest.colorSpace=DevelopmentColorEngineV3.linearSRGB
                                let task=try bandContext.startTask(toRender:graph.image,from:CGRect(x:0,y:y,width:w,height:rows),to:dest,at:.zero)
                                _=try task.waitUntilCompleted();try check()
                                guard let cmd=queue.makeCommandBuffer() else {throw DevelopmentError.invalidEncoding}
                                if surfaceOwners[rows]==nil {
                                    guard let owner=z3_surfaces(Unmanaged.passUnretained(device as AnyObject).toOpaque(),UInt32(w),UInt32(rows)) else{throw DevelopmentError.invalidEncoding}
                                    surfaceOwners[rows]=owner
                                }
                                let so=surfaceOwners[rows]!
                                func io(_ index:UInt32)->MTLTexture{Unmanaged<AnyObject>.fromOpaque(z3_texture(so,index)).takeUnretainedValue() as! MTLTexture}
                                guard let photoCopy=queue.makeCommandBuffer() else {throw DevelopmentError.invalidEncoding}
                                try dispatch(photoCopy,export,[photo,io(0)],w,rows){$0.setBytes(&prm,length:64,index:0)}
                                try drain(photoCopy);try authority.check()
                                let rc=z3_render(pg,so,"",0,UInt64(y+1),authorityCallback,Unmanaged.passUnretained(authority).toOpaque())
                                guard rc==0 else{throw NSError(domain:"public frame render",code:Int(rc))}
                                try authority.check()
                                guard let blit=cmd.makeBlitCommandEncoder() else {throw DevelopmentError.invalidEncoding}
                                blit.copy(from:io(2),sourceSlice:0,sourceLevel:0,sourceOrigin:.init(x:0,y:0,z:0),sourceSize:.init(width:w,height:rows,depth:1),
                                          to:nativePort,destinationSlice:0,destinationLevel:0,destinationOrigin:.init(x:0,y:0,z:0))
                                blit.endEncoding()
                                try compare(cmd,nativeStock,nativePort,nativeCounts,w,rows)
                                let sampled = direct ? [(nativeStock, halfStock)] : [(nativeStock, halfStock), (nativePort, halfPort)]
                                for pair in sampled {
                                    try dispatch(cmd,sampler,[pair.0,pair.1],w/2,rows/2){$0.setBytes(&prm,length:64,index:0)}
                                }
                                try dispatch(cmd,gather,[photo,nativeStock,nativePort],512,1){$0.setBuffer(record,offset:0,index:0);$0.setBytes(&prm,length:64,index:1)}
                                try drain(cmd);try check()
                                samples.append(record.contents().assumingMemoryBound(to:UInt8.self),count:512*64)
                                bandContext.clearCaches()
                            }
                        }
                        return true
                    }
                    guard ok==true,let last=queue.makeCommandBuffer() else{throw DevelopmentError.invalidEncoding}
                    try compare(last,halfStock,halfPort,halfCounts,w/2,h/2);try drain(last);try check()
                    let display=context("z3-identical-display");defer{display.clearCaches()}
                    func visible(_ t:MTLTexture)throws->Data{
                        guard let img=CIImage(mtlTexture:t,options:[.colorSpace:DevelopmentColorEngineV3.linearSRGB]) else{throw DevelopmentError.invalidEncoding}
                        return try raster(V3PreviewMaterializer.materialize(graph,context:display,maxPixel:2400,checkedLinearHalf:img))
                    }
                    let viaCI=try visible(halfStock),viaPort=try visible(halfPort)
                    let np=stats(nativeCounts),hp=stats(halfCounts)
                    guard (np["pixels"] as? UInt32)==UInt32(w*h),(hp["pixels"] as? UInt32)==UInt32(w*h/4) else {throw DevelopmentV3Error.invalidGraph}
                    let result:[String:Any]=["id":id,"state":i,"referenceSHA256":referenceDigest,"originalGradeArchiveSHA256":old[i],"compound":compound,"extreme":extreme,"nativeHalfProductABI":direct,"stockBandedDisplaySHA256":digest(viaCI),
                        "candidateDisplaySHA256":digest(viaPort),"stockBandVsArchive":diff(stockDisplay,viaCI),"candidateVsArchive":diff(stockDisplay,viaPort),
                        "candidateVsStockBand":diff(viaCI,viaPort),"nativeRGBAf":np,"halfRGBAf":hp,"shader":"public IOSurface C ABI","sampleBytes":samples.count,"sampleSHA256":digest(samples)]
                    let sampleURL=out.deletingPathExtension().appendingPathExtension("\(id)-\(i).bin")
                    try samples.write(to:sampleURL,options:.withoutOverwriting)
                    try wireData.write(to:sampleURL.appendingPathExtension("json"),options:.withoutOverwriting)
                    report.append(result)
                    let body:[String:Any]=["cases":report,"inputSHA256":shot.contentSHA256,"archiveSHA256":try RenderFiles.hash(archive),
                        "nativeSize":[w,h],"device":device.name,"runtimeSHA256":runtimeSeal,"sampleContract":"uint4 x/logicalY/0/0 + 3 float4s input/stock/port, header 64"]
                    try JSONSerialization.data(withJSONObject:body,options:[.prettyPrinted,.sortedKeys]).write(to:out,options:.atomic)
                    print("\(id)/\(i) native \(np) half \(hp) display \(diff(stockDisplay,viaPort))");fflush(stdout)
                }
            }
        }
        try check()
    }
    static func main()throws{
        let argv=CommandLine.arguments;guard argv.count==5 else {throw DevelopmentError.invalidEncoding}
        try process(raw:URL(fileURLWithPath:argv[1]),archive:URL(fileURLWithPath:argv[2]),out:URL(fileURLWithPath:argv[3]),ids:Set(argv[4].split(separator:",").map(String.init)))
    }
}

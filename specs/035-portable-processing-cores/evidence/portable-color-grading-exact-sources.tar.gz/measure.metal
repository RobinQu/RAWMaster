#include <metal_stdlib>
using namespace metal;
struct U {uint4 shape;float4 ellipse,adj,tone;};
struct R {uint4 coordinate;float4 src,stock,gpu;};
kernel void halfSample(texture2d<float,access::sample> native [[texture(0)]],texture2d<float,access::write> halfsize [[texture(1)]],
 constant U& p [[buffer(0)]],uint2 id [[thread_position_in_grid]]){
 if(id.x>=p.shape.x/2||id.y>=p.shape.w/2)return;
 constexpr sampler s(coord::normalized,address::clamp_to_edge,filter::linear);
 float2 uv=float2(2*id+1)/float2(native.get_width(),native.get_height());
 halfsize.write(native.sample(s,uv,level(0)),uint2(id.x,id.y+p.shape.z/2));
}
kernel void compare(texture2d<float,access::read> a [[texture(0)]],texture2d<float,access::read> b [[texture(1)]],
 device atomic_uint* out [[buffer(0)]],constant uint2& dims [[buffer(1)]],
 uint2 id [[thread_position_in_grid]],uint lane [[thread_index_in_simdgroup]]){
 bool active=all(id<dims);float4 r=active?a.read(id):0, v=active?b.read(id):0;
 uint4 rb=as_type<uint4>(r), vb=as_type<uint4>(v);uint4 ch=uint4(rb!=vb);
 uint finite=uint(any((rb&0x7f800000u)==0x7f800000u)||any((vb&0x7f800000u)==0x7f800000u));
 float4 d=abs(v-r);uint mx=as_type<uint>(max(max(d.x,d.y),max(d.z,d.w)));
 uint n=simd_sum(uint(active)),m=simd_sum(uint(any(ch!=0))),c=simd_sum(ch.x+ch.y+ch.z+ch.w),al=simd_sum(ch.w);
 uint f=simd_sum(finite),o=simd_sum(uint(any(d>2e-6f))),md=simd_max(mx);
 if(lane==0){atomic_fetch_add_explicit(out,n,memory_order_relaxed);if(m){atomic_fetch_add_explicit(out+1,m,memory_order_relaxed);atomic_fetch_add_explicit(out+2,c,memory_order_relaxed);
 atomic_fetch_add_explicit(out+3,al,memory_order_relaxed);atomic_fetch_max_explicit(out+4,md,memory_order_relaxed);}if(f)atomic_fetch_add_explicit(out+5,f,memory_order_relaxed);
 if(o)atomic_fetch_add_explicit(out+6,o,memory_order_relaxed);}
}
kernel void gatherGrade(texture2d<float,access::read> source [[texture(0)]], texture2d<float,access::read> a [[texture(1)]],
 texture2d<float,access::read> b [[texture(2)]], device R* rec [[buffer(0)]],constant U& u [[buffer(1)]],uint id [[thread_position_in_grid]]){
 if(id>=512)return;
 uint y=(id*167u+17u)%u.shape.w, yy=y+u.shape.z;
 uint x=(id*8731u+yy*31u) % u.shape.x;
 uint2 local=uint2(x,y); rec[id]=R{uint4(x,yy,0,0),source.read(uint2(x,u.shape.y-1-yy)),a.read(local),b.read(local)};
}
kernel void exportGrade(texture2d<float,access::read> photo [[texture(0)]], texture2d<float,access::write> out [[texture(1)]],
 constant U& p [[buffer(0)]],uint2 id [[thread_position_in_grid]]){
 if(id.x>=p.shape.x||id.y>=p.shape.w)return;
 out.write(photo.read(uint2(id.x,p.shape.y-1-id.y-p.shape.z)),id);
}

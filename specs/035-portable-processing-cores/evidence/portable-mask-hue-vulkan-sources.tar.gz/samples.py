import sys,subprocess,json,os
from pathlib import Path
z=Path(__file__).resolve().parent
base=Path(os.environ.get('RADIAL_FROZEN','/repo/output/035-development/phase-z/radial-port'))
runner=base/'bin'/('linux-replay-node' if sys.platform=='linux' else 'replay-node')
lib=Path(sys.argv[1]).resolve()
onlyHue=sys.argv[2]!='all'
out={}
for variant in sys.argv[3:]:
 dest=z/(sys.platform+'-sample-'+variant)
 dest.mkdir(exist_ok=True)
 env=dict(os.environ,RM_AA_HUE_WGSL=str(z/'variants'/(variant+'.wgsl')))
 group={}
 for row in (base/'intake.tsv').read_text().splitlines():
  key,sample,wire,mask=row.split()
  if onlyHue and '.color-mask-hue-' not in key: continue
  prog=subprocess.run([str(runner),str(lib),os.environ.get('AA_BACKEND','1'),str(base/sample),str(base/wire),mask,str(dest/(key+'.rgba'))],env=env,capture_output=True,check=True)
  group[key]=json.loads(prog.stdout)
 (dest/'summary.json').write_text(json.dumps(group,indent=2)+'\n')
 out[variant]={'over':sum(x['over2e6'] for x in group.values()),'max':max(x['maxAbs'] for x in group.values()),'per':{k:v['over2e6'] for k,v in group.items() if v['over2e6']},'changed':sum(x['changedComponents'] for x in group.values())}
print(json.dumps(out,indent=2))

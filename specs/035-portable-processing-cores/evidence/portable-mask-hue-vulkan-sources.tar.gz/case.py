import ctypes as c,json,os,sys
from pathlib import Path
z=Path(__file__).resolve().parent
class Mask(c.Structure):
 _fields_=[('id',c.c_char_p),('idBytes',c.c_size_t),('values',c.POINTER(c.c_float)),('count',c.c_size_t)]
def run(library,variant,backend=1):
 os.environ["RM_AA_HUE_WGSL"]=str(z/'variants'/(variant+'.wgsl'))
 q=json.loads((z/'fixtures/one-pixel.json').read_text())
 lib=c.CDLL(str(library));F=c.POINTER(c.c_float);ptr=c.c_void_p
 lib.rm_image_plan_open_v2.argtypes=[c.c_char_p,c.c_size_t,c.c_char_p,c.c_size_t,c.c_uint32,c.POINTER(ptr)]
 lib.rm_image_plan_render_v2.argtypes=[ptr,c.c_uint32,c.c_uint32,F,c.c_size_t,c.POINTER(Mask),c.c_size_t,F,c.c_size_t]
 lib.rm_image_plan_close_v1.argtypes=[ptr]
 wire=json.dumps(q['wire']).encode();name=q['wire']['nodes'][0]['mask'].encode()
 source=(c.c_float*4)(*q['source']);out=(c.c_float*4)(7,7,7,7);mask=(c.c_float*1)(q['coverage']);desc=Mask(name,len(name),mask,1);p=ptr()
 code=lib.rm_image_plan_open_v2(wire,len(wire),None,0,backend,c.byref(p));assert not code,(variant,code)
 try:
  ret=lib.rm_image_plan_render_v2(p,1,1,source,4,c.byref(desc),1,out,4)
  assert ret==0,(variant,ret)
 finally:lib.rm_image_plan_close_v1(p)
 return list(out)
if __name__=='__main__':
 path=Path(sys.argv[1]).resolve()
 names=sys.argv[2:] or [x.stem for x in sorted((z/'variants').glob('*.wgsl'))]
 print(json.dumps({n:run(path,n) for n in names},indent=2))

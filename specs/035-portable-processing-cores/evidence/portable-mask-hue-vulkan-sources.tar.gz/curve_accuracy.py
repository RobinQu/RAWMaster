import os,sys,ctypes as c,json,math,struct,random,statistics,collections
from case import z,Mask
from pathlib import Path
flt=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
def at(x):return struct.unpack('<f',struct.pack('<I',x))[0]
half=[struct.unpack('<e',struct.pack('<H',i))[0] for i in range(65536) if i&0x7c00!=0x7c00]
rng=random.Random(82981)
extra=[at((sign<<31)|(ex<<23)|m) for sign in (0,1) for ex in range(255) for m in [0,1,2,0x7ffffe,0x7fffff]+[rng.randrange(1<<23) for i in range(32)]]
extra += [at(bits(t)+i)*sgn for t in [.0031308,1.,2.,65504.] for i in range(-5,6) for sgn in (1,-1)]
values=half+extra
data=list(values)+[0.]*(3-len(values)%3)
counts=(len(data)//3+255)//256*256
data.extend([0.]*(counts*3-len(data)))
pixels=[v for i in range(counts) for v in (*data[i*3:i*3+3],1.)]
src=(c.c_float*(4*counts))(*pixels);mask=(c.c_float*counts)(*[1.]*counts);F=c.POINTER(c.c_float);ptr=c.c_void_p
lib=c.CDLL(str(Path(sys.argv[1]).resolve()))
lib.rm_image_plan_open_v2.argtypes=[c.c_char_p,c.c_size_t,c.c_char_p,c.c_size_t,c.c_uint32,c.POINTER(ptr)]
lib.rm_image_plan_render_v2.argtypes=[ptr,c.c_uint32,c.c_uint32,F,c.c_size_t,c.POINTER(Mask),c.c_size_t,F,c.c_size_t]
lib.rm_image_plan_close_v1.argtypes=[ptr]
recipe=json.loads((z/'fixtures/one-pixel.json').read_text())['wire'];wire=json.dumps(recipe).encode();name=recipe['nodes'][0]['mask'].encode()
desc=Mask(name,len(name),mask,counts)
def reference(v):
 a=abs(v)
 return math.copysign(12.92*a if a<=.0031308 else 1.055*(a**(1./2.4))-.055,v)
ref=list(map(reference,values))
report={}
for var in sys.argv[2:]:
 s=(z/'variants'/(var+'.wgsl')).read_text()
 ix=s.index('fn mask_tone_v3('); ixb=s.index('{',ix); fn='mask_encode' if var=='baseline' else 'mask_hue_encode'
 diagnostic=s[:ixb+1]+'\n    return vec4<f32>('+','.join(fn+'(pixel.'+w+')' for w in 'rgb')+',pixel.a);\n}\n'
 tmp=z/'variants'/('accuracy-'+var+'.wgsl');tmp.write_text(diagnostic)
 os.environ['RM_AA_HUE_WGSL']=str(tmp)
 p=ptr();code=lib.rm_image_plan_open_v2(wire,len(wire),None,0,1,c.byref(p));assert not code,code
 out=(c.c_float*(4*counts))()
 try: code=lib.rm_image_plan_render_v2(p,256,counts//256,src,4*counts,c.byref(desc),1,out,4*counts)
 finally:lib.rm_image_plan_close_v1(p)
 if code:report[var]={'renderError':code};continue
 actual=[out[(i//3)*4+i%3] for i in range(len(values))]
 rec={}
 for key,scope in [('nonlinearF16',[i for i,v in enumerate(half) if abs(v)>.0031308]),('extendedF32',[i for i,v in enumerate(values) if abs(v)>.0031308]),('linearHDR2',[i for i,v in enumerate(values) if .0031308<abs(v)<=2]),('linearToe',[i for i,v in enumerate(values) if abs(v)<=.0031308])]:
  worst=max(scope,key=lambda i:abs(bits(flt(ref[i]))-bits(actual[i])))
  ulps=[abs((bits(flt(ref[i]))&0x7fffffff)-(bits(actual[i])&0x7fffffff)) for i in scope]
  signbad=sum(math.copysign(1.,values[i])!=math.copysign(1.,actual[i]) and actual[i]!=0. for i in scope)
  rec[key]={'count':len(scope),'maxUlp':max(ulps),'p95Ulp':sorted(ulps)[int(.95*len(ulps))],'meanUlp':statistics.mean(ulps),'exact':ulps.count(0),'maxAbs':max(abs(actual[i]-ref[i]) for i in scope),'incorrectNonzeroSigns':signbad,'worstInput':values[worst], 'nonfinite':sum(not math.isfinite(actual[i]) for i in scope)}
 report[var]=rec
print(json.dumps(report,indent=2))

#include "rawmaster_image.h"
#include <array>
#include <cmath>
#include <cstring>
#include <dlfcn.h>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>
struct Uniforms { uint32_t shape[4];float rest[12]; };
struct Record { uint32_t x,y,mask,unused; float sample[4],reference[4],port[4]; };
int main(int argc,char** argv) {
    if(argc!=7)return 1;
    void* lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib){std::cerr<<dlerror();return 2;}
    auto open=(decltype(&rm_image_plan_open_v2))dlsym(lib,"rm_image_plan_open_v2");
    auto render=(decltype(&rm_image_plan_render_v2))dlsym(lib,"rm_image_plan_render_v2");
    auto close=(decltype(&rm_image_plan_close_v1))dlsym(lib,"rm_image_plan_close_v1");
    std::ifstream file(argv[3],std::ios::binary);Uniforms u{};
    if(!file.read((char*)&u,sizeof(u)))return 3;
    std::vector<std::array<float,4>> source,expected;std::vector<float> masks;
    Record r;while(file.read((char*)&r,sizeof(r))){
        std::array<float,4>s,e;std::memcpy(s.data(),r.sample,16);std::memcpy(e.data(),r.reference,16);
        source.push_back(s);expected.push_back(e);float m;std::memcpy(&m,&r.mask,4);masks.push_back(m);
    }
    if(!file.eof()||file.gcount()!=0||masks.empty()||masks.size()%512!=0)return 4;
    std::ifstream recipeFile(argv[4]);std::string recipe{std::istreambuf_iterator<char>(recipeFile),{}};
    RMImagePlan* plan=nullptr;int s=open((const uint8_t*)recipe.data(),recipe.size(),nullptr,0,std::stoul(argv[2]),&plan);
    if(s||!plan){std::cerr<<"open "<<s<<std::endl;return 5;}
    std::string name=argv[5];
    RMImageCoverageV2 binding{(uint8_t*)name.data(),name.size(),masks.data(),masks.size()};
    std::vector<std::array<float,4>> out(source.size());
    s=render(plan,512,source.size()/512,source[0].data(),4*source.size(),&binding,1,out[0].data(),4*out.size());close(plan);
    if(s){std::cerr<<"render "<<s<<std::endl;return 6;}
    size_t diff=0,pixels=0,bad=0,alpha=0,zero=0,partials=0;double sum=0;float mx=0;
    for(size_t i=0;i<out.size();i++) {
        bool changed=false;
        for(size_t c=0;c<4;c++){
            if(!std::isfinite(out[i][c]))return 7;
            float e=std::abs(out[i][c]-expected[i][c]);sum+=e;mx=std::max(mx,e);bad+=e>2e-6f;
            bool different=std::memcmp(&out[i][c],&expected[i][c],4)!=0;diff+=different;changed|=different;
            alpha+=different&&c==3;zero+=different&&masks[i]==0;
        }
        pixels+=changed;partials+=masks[i]>0&&masks[i]<1;
    }
    std::ofstream of(argv[6],std::ios::binary);of.write((const char*)out.data(),out.size()*16);
    std::cout<<"{\"pixels\":"<<out.size()<<",\"partial\":"<<partials<<",\"changedPixels\":"<<pixels
             <<",\"changedComponents\":"<<diff<<",\"maxAbs\":"<<mx<<",\"over2e6\":"<<bad<<",\"alphaDifferences\":"<<alpha
             <<",\"outsideDifferences\":"<<zero<<"}\n";
}

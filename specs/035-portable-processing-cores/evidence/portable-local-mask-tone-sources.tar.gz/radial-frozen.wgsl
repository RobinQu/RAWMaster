struct Uniforms {
    shape: vec4<u32>, // full width, full height, first logical (bottom-origin) row, this band rows
    ellipse: vec4<f32>, // center and radii in top-origin normalized mask space
    adjustment: vec4<f32>, // local exposure, highlights, shadows, saturation
    tone: vec4<f32>, // contrast, whites, blacks, hue
}
@group(0) @binding(0) var input_photo: texture_2d<f32>;
@group(0) @binding(1) var native_band: texture_storage_2d<rgba32float, write>;
@group(0) @binding(3) var coverage_plane: texture_2d<f32>;
@group(0) @binding(2) var<uniform> params: Uniforms;

fn smooth_mask(a:f32,b:f32,x:f32)->f32 {
    let t=clamp((x-a)/max(b-a,0.00001),0.0,1.0); return t*t*(3.0-2.0*t);
}
fn point_encode(x:f32)->f32 {
    let a=abs(x); if a<=0.0031308 {return sign(x)*(12.92*a);}
    return sign(x)*(1.055*pow(a,1.0/2.4)-0.055);
}
fn point_decode(x:f32)->f32 {
    let a=abs(x); if a<=0.04045 {return sign(x)*(a/12.92);}
    return sign(x)*pow((a+0.055)/1.055,2.4);
}
fn point_hsv(c:vec3<f32>)->vec3<f32> {
    let hi=max(c.r,max(c.g,c.b)); let lo=min(c.r,min(c.g,c.b)); let d=hi-lo;
    var h=0.0; var s=0.0;
    if d>1e-8 {
        if hi==c.r {h=(c.g-c.b)/d;} else if hi==c.g {h=2.0+(c.b-c.r)/d;} else {h=4.0+(c.r-c.g)/d;}
    }
    if hi>1e-8 {s=d/hi;} return vec3<f32>(fract(h/6.0),s,hi);
}
fn point_rgb(hsv:vec3<f32>)->vec3<f32> {
    let p=abs(fract(hsv.xxx+vec3<f32>(0.0,2.0/3.0,1.0/3.0))*6.0-3.0);
    return hsv.z*mix(vec3<f32>(1.0),clamp(p-1.0,vec3<f32>(0.0),vec3<f32>(1.0)),hsv.y);
}
fn radial_coverage(p:vec2<u32>)->f32 {
    let at=vec2<f32>(p)+0.5; let uv=vec2<f32>(at.x/f32(params.shape.x),1.0-at.y/f32(params.shape.y));
    let d=length((uv-params.ellipse.xy)/params.ellipse.zw);
    return clamp(1.0-smooth_mask(1.0,1.0,d),0.0,1.0);
}
fn local_tone(pixel:vec4<f32>,mask:f32)->vec4<f32> {
    // Source was checked as opaque finite half. Preserve the shader's zero-coverage identity.
    if mask<=0.0 {return pixel;}
    let adj=params.adjustment; let tone=params.tone; let l=vec3<f32>(0.2126,0.7152,0.0722);
    var c=pixel.rgb/pixel.a; c*=exp2(2.0*adj.x*mask);
    var y=dot(c,l); var enc=clamp(point_encode(y),0.0,1.0);
    c*=1.0+0.5*adj.y*smooth_mask(0.5,1.0,enc)*mask;
    c*=1.0+0.5*adj.z*(1.0-smooth_mask(0.0,0.5,enc))*mask;
    y=dot(c,l); enc=point_encode(y); let contrast=tone.x*mask;
    if enc>0.0 && enc<1.0 && contrast!=0.0 {
        let pivot=0.55; let power=exp2(1.3*contrast); var goal=0.0;
        if enc<pivot {goal=pivot*pow(enc/pivot,power);}
        else {goal=1.0-(1.0-pivot)*pow((1.0-enc)/(1.0-pivot),power);}
        let decoded=point_decode(goal);
        if abs(y)>1e-8 {c*=decoded/y;} else {c+=vec3<f32>(decoded-y);}
    }
    let black=0.05*tone.z*mask;c=(c-vec3<f32>(black))/(1.0-black);
    let white=smoothstep(0.45,1.0,clamp(point_encode(dot(c,l)),0.0,1.0));c*=1.0+0.35*tone.y*white*mask;
    let hue=tone.w*mask;
    if hue!=0.0 {
        let e=vec3<f32>(point_encode(c.r),point_encode(c.g),point_encode(c.b));
        var hsv=point_hsv(e); hsv.x=fract(hsv.x+hue+1.0);let shifted=point_rgb(hsv);
        c=vec3<f32>(point_decode(shifted.r),point_decode(shifted.g),point_decode(shifted.b));
    }
    let gray=dot(c,l);c=vec3<f32>(gray)+(c-vec3<f32>(gray))*(1.0+adj.w*mask);
    return vec4<f32>(c*pixel.a,pixel.a);
}
@compute @workgroup_size(8,8) fn radial_band(@builtin(global_invocation_id) id:vec3<u32>) {
    if id.x>=params.shape.x || id.y>=params.shape.w {return;}
    let p=id.xy+vec2<u32>(0u,params.shape.z);
    let s=textureLoad(input_photo,vec2<u32>(p.x,params.shape.y-1u-p.y),0);
    textureStore(native_band,id.xy,local_tone(s,textureLoad(coverage_plane,id.xy,0).a));
}

#!/bin/bash
set -euo pipefail
z="$(cd "$(dirname "$0")" && pwd)"
repo="$(git rev-parse --show-toplevel)"
products="$repo/.build/release"
maps="$repo/.build/out/Intermediates.noindex/GeneratedModuleMaps"
mkdir -p "$z/bin"
for name in radial radial-frozen radial-frozen-hue; do
 cargo run --locked --release --manifest-path "$z/compiler/Cargo.toml" -- "$z/$name.wgsl" "$z/$name.metal"
done
clang++ -target arm64-apple-macos15.0 -std=c++17 -O2 -fobjc-arc -I "$repo/Modules/ImageEdit/include" -c "$z/iosurface/port.mm" -o "$z/iosurface/port.o"
clang++ -std=c++17 -O2 -I "$repo/Modules/ImageEdit/include" "$z/replay-node.cpp" -o "$z/bin/replay-node"
flags=(); objects=()
for name in CFlashRaw CImageEditABI CLibraryCatalogABI; do flags+=(-Xcc "-fmodule-map-file=$maps/$name.modulemap"); done
for name in RAWMasterImaging RAWMasterCore RAWMasterImage RAWMasterLibrary RAWMasterPhotoExport MaskAI CFlashRaw CImageEditABI CLibraryCatalogABI; do objects+=("$products/$name.o"); done
for name in RAWMaster_RAWMasterImaging RAWMaster_RAWMasterCore ImageEdit_RAWMasterImage LibraryCatalog_RAWMasterLibrary PhotoExport_RAWMasterPhotoExport; do
 [[ -d "$z/bin/$name.bundle" ]] || cp -cR "$products/$name.bundle" "$z/bin/"
done
swiftc -O -parse-as-library -swift-version 5 -target arm64-apple-macos15.0 -I "$products" -I "$z/iosurface" -I "$repo/Sources/CSQLite" -I "$repo/experiments/MaskAI/Sources/CONNXRuntime" "${flags[@]}" "$z/RadialWitness.swift" "${objects[@]}" "$z/iosurface/port.o" -framework IOSurface -framework CoreVideo -framework AVKit -lc++ -lsqlite3 -lz -o "$z/bin/radial"

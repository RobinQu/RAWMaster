import CZRadial
import AppKit
import CoreImage
import CryptoKit
import Darwin
import Foundation
import Metal
import RAWMasterCore
@testable import RAWMasterImaging

@main private enum RadialWitness {
    static func context(_ name: String, queue: MTLCommandQueue? = nil) -> CIContext {
        let options: [CIContextOption: Any] = [
            .name: name, .workingColorSpace: DevelopmentColorEngineV3.linearSRGB,
            .workingFormat: CIFormat.RGBAf.rawValue, .cacheIntermediates: false, .memoryTarget: 512,
        ]
        if let queue { return CIContext(mtlCommandQueue: queue, options: options) }
        return CIContext(options: options)
    }

    static func milliseconds(_ begin: UInt64) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e6
    }

    static func peak() throws -> Int64 {
        var info = task_vm_info_data_t()
        var words = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.stride)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(words)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &words)
            }
        }
        guard status == KERN_SUCCESS else { throw DevelopmentError.invalidEncoding }
        return info.ledger_phys_footprint_peak
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func raster(_ pixels: PreviewPixels) throws -> Data {
        guard pixels.outputSize == CGSize(width: 2400, height: 1600) else { throw DevelopmentError.invalidEncoding }
        let frame = DevelopmentPreviewFrame(frameID: UUID(), image: pixels.image, sessionID: .init(),
            sourceGeneration: 1, consumerID: .init(), revision: 1, quality: .settled,
            canonicalPixelSize: pixels.nativeSize, outputPixelSize: pixels.outputSize, outputKey: "half-fit-probe", approximate: false)
        var bytes = Data(count: 2400 * 1600 * 4)
        try bytes.withUnsafeMutableBytes { try frame.copyDisplayRGBA8(into: $0) }
        return bytes
    }

    static func diff(_ expected: Data, _ actual: Data) -> [String: Any] {
        precondition(expected.count == actual.count && expected.count == 2400 * 1600 * 4)
        var changedPixels = 0, maxCode = 0, alphaChanges = 0, edgeChanges = 0, sum = 0
        expected.withUnsafeBytes { (left: UnsafeRawBufferPointer) in
            actual.withUnsafeBytes { (right: UnsafeRawBufferPointer) in
                for index in stride(from: 0, to: expected.count, by: 4) {
                    var changed = false
                    for channel in 0..<4 {
                        let error = abs(Int(left[index + channel]) - Int(right[index + channel]))
                        if error > 0 {
                            maxCode = max(maxCode, error)
                            sum += error
                            if channel == 3 { alphaChanges += 1 }
                            changed = true
                        }
                    }
                    if changed {
                        let x = (index / 4) % 2400
                        let y = (index / 4) / 2400
                        if x == 0 || x == 2399 || y == 0 || y == 1599 { edgeChanges += 1 }
                        changedPixels += 1
                    }
                }
            }
        }
        return ["changedPixels": changedPixels, "edgePixels": edgeChanges, "alphaValues": alphaChanges,
                "maxCodeDifference": maxCode, "meanAbsoluteCodeDifference": Double(sum) / Double(expected.count)]
    }

    static func snapshot(_ raw: URL) throws -> EditingSourceSnapshot {
        let hash = try RenderFiles.hash(raw)
        guard let size = try raw.resourceValues(forKeys:[.fileSizeKey]).fileSize else { throw DevelopmentError.unreadable }
        return .init(projectID: "035-curves",assetID: hash,contentSHA256: hash,byteCount: Int64(size),
                     admissionFingerprint: "curves-v3",sourceLocation: raw)
    }


    struct Uniforms {
        var shape: SIMD4<UInt32>
        var ellipse: SIMD4<Float>
        var adjust: SIMD4<Float>
        var tone: SIMD4<Float>
    }
    final class Authority {
        let check: () throws -> Void
        init(_ check: @escaping () throws -> Void){self.check=check}
    }
    static let authorityCallback: @convention(c) (UnsafeMutableRawPointer?,UInt64)->UInt32 = { ctx,revision in
        guard let ctx,revision>0 else{return 0}
        let object=Unmanaged<Authority>.fromOpaque(ctx).takeUnretainedValue()
        do {try object.check();return 1} catch {return 0}
    }
    static func pipeline(_ library: MTLLibrary,_ name: String,_ device: MTLDevice) throws -> MTLComputePipelineState {
        guard let code=library.makeFunction(name:name) else {throw DevelopmentV3Error.invalidGraph}
        return try device.makeComputePipelineState(function:code)
    }
    static func texture(_ dev: MTLDevice,_ w:Int,_ h:Int) throws -> MTLTexture {
        let layout=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:.rgba32Float,width:w,height:h,mipmapped:false)
        layout.storageMode = .private;layout.usage=[.shaderRead,.shaderWrite,.renderTarget]
        guard let t=dev.makeTexture(descriptor:layout) else {throw DevelopmentError.invalidEncoding};return t
    }
    static func stats(_ b:MTLBuffer)->[String:Any] {
        let s=b.contents().bindMemory(to:UInt32.self,capacity:7)
        return ["pixels":s[0],"changedPixels":s[1],"changedComponents":s[2],"alphaChanges":s[3],"maxAbs":Float(bitPattern:s[4]),"nonfinitePixels":s[5],"over2e6Pixels":s[6]]
    }
    static func process(raw:URL,archive:URL,out:URL,ids:Set<String>) throws {
        guard let device=MTLCreateSystemDefaultDevice(),let queue=device.makeCommandQueue(),
              let input=try JSONSerialization.jsonObject(with:Data(contentsOf:archive)) as? [String:Any],
              let ops=input["operations"] as? [[String:Any]] else {throw DevelopmentError.invalidEncoding}
        let opt=MTLCompileOptions();opt.mathMode = .fast
        let here=URL(fileURLWithPath:CommandLine.arguments[0]).deletingLastPathComponent().deletingLastPathComponent()
        let externalCoverage=ProcessInfo.processInfo.environment["Z3_CI_COVERAGE"]=="1"
        let real=ProcessInfo.processInfo.environment["Z3_PRODUCT_C_ABI"]=="1"
        let runtime=URL(fileURLWithPath:ProcessInfo.processInfo.environment["Z3_IMAGE_BINARY"] ?? here.appendingPathComponent("bin/mac-product.dylib").path)
        let runtimeSeal=real ? try RenderFiles.hash(runtime) : ""
        let variant=externalCoverage ? (ProcessInfo.processInfo.environment["Z3_HUE_LITERAL"]=="1" ? "radial-frozen-hue.metal":"radial-frozen.metal") : "radial.metal"
        let nativeLib=try device.makeLibrary(source:String(contentsOf:here.appendingPathComponent(variant),encoding:.utf8),options:opt)
        let testLib=try device.makeLibrary(source:String(contentsOf:here.appendingPathComponent("measure.metal"),encoding:.utf8),options:opt)
        let port=try pipeline(nativeLib,"radial_band",device), sampler=try pipeline(testLib,"halfSample",device)
        let export=try pipeline(testLib,"exportBand",device)
        let comp=try pipeline(testLib,"compare",device), gather=try pipeline(testLib,"gather",device)
        let shot=try snapshot(raw)
        guard shot.contentSHA256 == input["sourceSHA256"] as? String else {throw DevelopmentV3Error.invalidGraph}
        let cap=try RenderFiles.verifiedPreviewCapture(shot)
        defer {try? FileManager.default.removeItem(at:cap.url.deletingLastPathComponent())}
        let check={try cap.requireCurrent(at:cap.url)}
        let uploaded=try FlashRawImageFactory.nativePreviewImage(capture:cap.url,rawDetails:nil,retainNativeTexture:true)
        let w=Int(uploaded.image.extent.width),h=Int(uploaded.image.extent.height)
        let pool=FlashRawCanonicalTexturePool(byteBudget:1024*1024*1024)
        let key=FlashRawCanonicalTextureKey(sourceKey:shot.contentSHA256,captureStamp:cap.stamp,contract:"z3-independent-radial",width:w,height:h)
        let pin=try pool.acquireNative(key){uploaded};defer{pin.release()}
        guard try pin.checkOpaqueUpload(pin.image,cancellation:check),let filter=CIRAWFilter(imageURL:cap.url) else {throw DevelopmentV3Error.invalidGraph}
        let wb=DevelopmentAsShotWhiteBalance(temperature:filter.neutralTemperature,tint:filter.neutralTint)
        var report=[[String:Any]]()
        for op in ops {
            guard let id=op["id"] as? String,ids.contains(id),let descriptions=op["stateDescriptions"] as? [[String:Any]],
                  let old=op["firstStateFullFrameDigests"] as? [String] else {continue}
            for (i,row) in descriptions.enumerated() {
                try autoreleasepool {
                    let bytes=try JSONSerialization.data(withJSONObject:row)
                    let recipe=try JSONDecoder().decode(DevelopmentRecipe.self,from:bytes)
                    guard let p=recipe.adjustmentsV3,p.masks.count==1 else {throw DevelopmentV3Error.invalidGraph}
                    let l=p.masks[0],a=l.adjustments
                    guard l.enabled,l.kind == .radial,l.feather==0,!l.inverted,l.opacity==1,
                          try FlashRawImageFactory.applyInputAdjustments(p,to:pin.image,asShotWhiteBalance:wb) === pin.image else {throw DevelopmentV3Error.invalidGraph}
                    let params=Uniforms(shape:.init(UInt32(w),UInt32(h),0,256),ellipse:.init(Float(l.center.x),Float(l.center.y),Float(l.radiusX),Float(l.radiusY)),
                        adjust:.init(Float(a.exposure),Float(a.highlights),Float(a.shadows),Float(a.saturation)),
                        tone:.init(Float(a.contrast ?? 0),Float(a.whites ?? 0),Float(a.blacks ?? 0),Float(a.hue ?? 0)*(a.fineAdjustment==true ? 0.1:1)))
                    let ctx=context("z3-stock-develop");defer{ctx.clearCaches()}
                    let graph=try DevelopmentCanonicalFiniteGPU.$residentPhotoWorkingBudget.withValue(DevelopmentCanonicalFiniteGPU.workingSetLimit){
                        try DevelopmentRendererV3.develop(cap.url,recipe:recipe,suppliedRawBase:pin.image,context:ctx,residentGlobalSource:pin)
                    }
                    let stockDisplay=try raster(V3PreviewMaterializer.materialize(graph,context:ctx,maxPixel:2400))
                    guard digest(stockDisplay)==old[i] else {throw NSError(domain:"stock archive \(id) \(i)",code:1)}
                    ctx.clearCaches()
                    let scope=DevelopmentMaskEngineV3.ScopeSelection(l);try scope.capture(pin.image)
                    guard let scopeImage=scope.coverage else{throw DevelopmentV3Error.invalidGraph}
                    let bandContext=context("z3-original-native-band",queue:queue);defer{bandContext.clearCaches()}
                    guard let scopeQueue=device.makeCommandQueue() else {throw DevelopmentError.invalidEncoding}
                    let scopeContext=context("z3-independent-coverage-band",queue:scopeQueue);defer{scopeContext.clearCaches()}
                    let nativeStock=try texture(device,w,256),nativePort=try texture(device,w,256),coverBand=try texture(device,w,256)
                    let halfStock=try texture(device,w/2,h/2),halfPort=try texture(device,w/2,h/2)
                    guard let nativeCounts=device.makeBuffer(length:32,options:.storageModeShared),let halfCounts=device.makeBuffer(length:32,options:.storageModeShared),
                          let record=device.makeBuffer(length:512*64,options:.storageModeShared) else {throw DevelopmentError.invalidEncoding}
                    memset(nativeCounts.contents(),0,32);memset(halfCounts.contents(),0,32)
                    var surfaceOwners:[Int:UnsafeMutableRawPointer]=[:]
                    var cProgram:UnsafeMutableRawPointer?
                    let authority=Authority { try check();guard pin.isCurrent(for:pin.image) else {throw DevelopmentV3Error.invalidGraph} }
                    let maskName=l.id.uuidString
                    if real {
                        let recipeURL=here.appendingPathComponent("intake").appendingPathComponent("\(out.deletingPathExtension().lastPathComponent).\(id)-\(i).json")
                        let wire=try String(contentsOf:recipeURL,encoding:.utf8)
                        cProgram=z3_program(runtime.path,Unmanaged.passUnretained(device as AnyObject).toOpaque(),wire,wire.utf8.count)
                        guard cProgram != nil else {throw NSError(domain:"public program open",code:1)}
                    }
                    defer {for v in surfaceOwners.values{z3_release(v)};if let pg=cProgram{z3_release(pg)}}
                    var prm=params
                    var samples=withUnsafeBytes(of:&prm){Data($0)}
                    func dispatch(_ cmd:MTLCommandBuffer,_ ps:MTLComputePipelineState,_ imgs:[MTLTexture],_ xs:Int,_ ys:Int,
                                  _ set:(MTLComputeCommandEncoder)->Void) throws {
                        guard let e=cmd.makeComputeCommandEncoder() else {throw DevelopmentError.invalidEncoding}
                        e.setComputePipelineState(ps);for (idx,t) in imgs.enumerated(){e.setTexture(t,index:idx)}
                        set(e);let grid=MTLSize(width:xs,height:ys,depth:1)
                        e.dispatchThreads(grid,threadsPerThreadgroup:.init(width:8,height:8,depth:1));e.endEncoding()
                    }
                    func compare(_ cmd:MTLCommandBuffer,_ x:MTLTexture,_ y:MTLTexture,_ b:MTLBuffer,_ ww:Int,_ hh:Int)throws{
                        var dims=SIMD2<UInt32>(UInt32(ww),UInt32(hh))
                        try dispatch(cmd,comp,[x,y],ww,hh){$0.setBuffer(b,offset:0,index:0);$0.setBytes(&dims,length:8,index:1)}
                    }
                    func drain(_ cmd:MTLCommandBuffer)throws{cmd.commit();cmd.waitUntilCompleted();guard cmd.status == .completed else{throw cmd.error ?? DevelopmentError.invalidEncoding}}
                    let ok:Bool?=try pin.withCheckedOpaqueTexture(for:pin.image,check:check){photo in
                        guard photo.pixelFormat == .rgba16Float,photo.width==w,photo.height==h else {throw DevelopmentV3Error.invalidGraph}
                        for y in stride(from:0,to:h,by:256){
                            try autoreleasepool {
                                try check()
                                let rows=min(256,h-y);prm.shape.z=UInt32(y);prm.shape.w=UInt32(rows)
                                let dest=CIRenderDestination(mtlTexture:nativeStock,commandBuffer:nil);dest.isFlipped=false;dest.isDithered=false;dest.isClamped=false;dest.alphaMode = .premultiplied;dest.colorSpace=DevelopmentColorEngineV3.linearSRGB
                                let task=try bandContext.startTask(toRender:graph.image,from:CGRect(x:0,y:y,width:w,height:rows),to:dest,at:.zero)
                                _=try task.waitUntilCompleted();try check()
                                let maskDest=CIRenderDestination(mtlTexture:coverBand,commandBuffer:nil);maskDest.isFlipped=false;maskDest.isDithered=false;maskDest.isClamped=false;maskDest.alphaMode = .premultiplied;maskDest.colorSpace=DevelopmentColorEngineV3.linearSRGB
                                let maskTask=try scopeContext.startTask(toRender:scopeImage,from:CGRect(x:0,y:y,width:w,height:rows),to:maskDest,at:.zero)
                                _=try maskTask.waitUntilCompleted();try check()
                                guard let cmd=queue.makeCommandBuffer() else {throw DevelopmentError.invalidEncoding}
                                if let pg=cProgram {
                                    if surfaceOwners[rows]==nil {
                                        guard let owner=z3_surfaces(Unmanaged.passUnretained(device as AnyObject).toOpaque(),UInt32(w),UInt32(rows)) else{throw DevelopmentError.invalidEncoding}
                                        surfaceOwners[rows]=owner
                                    }
                                    let so=surfaceOwners[rows]!
                                    func io(_ index:UInt32)->MTLTexture{Unmanaged<AnyObject>.fromOpaque(z3_texture(so,index)).takeUnretainedValue() as! MTLTexture}
                                    guard let photoCopy=queue.makeCommandBuffer() else{throw DevelopmentError.invalidEncoding}
                                    try dispatch(photoCopy,export,[photo,coverBand,io(0),io(1)],w,rows){$0.setBytes(&prm,length:64,index:0)}
                                    try drain(photoCopy);try authority.check()
                                    let rc=z3_render(pg,so,maskName,maskName.utf8.count,UInt64(y+1),authorityCallback,Unmanaged.passUnretained(authority).toOpaque())
                                    guard rc==0 else{throw NSError(domain:"public frame render",code:Int(rc))}
                                    try authority.check()
                                    guard let blit=cmd.makeBlitCommandEncoder() else {throw DevelopmentError.invalidEncoding}
                                    blit.copy(from:io(2),sourceSlice:0,sourceLevel:0,sourceOrigin:.init(x:0,y:0,z:0),sourceSize:.init(width:w,height:rows,depth:1),
                                              to:nativePort,destinationSlice:0,destinationLevel:0,destinationOrigin:.init(x:0,y:0,z:0))
                                    blit.endEncoding()
                                } else {
                                    try dispatch(cmd,port,externalCoverage ? [photo,nativePort,coverBand] : [photo,nativePort],w,rows){$0.setBytes(&prm,length:64,index:0)}
                                }
                                try compare(cmd,nativeStock,nativePort,nativeCounts,w,rows)
                                for pair in [(nativeStock,halfStock),(nativePort,halfPort)]{
                                    try dispatch(cmd,sampler,[pair.0,pair.1],w/2,rows/2){$0.setBytes(&prm,length:64,index:0)}
                                }
                                try dispatch(cmd,gather,[photo,nativeStock,nativePort,coverBand],512,1){$0.setBuffer(record,offset:0,index:0);$0.setBytes(&prm,length:64,index:1)}
                                try drain(cmd);try check()
                                samples.append(record.contents().assumingMemoryBound(to:UInt8.self),count:512*64)
                                bandContext.clearCaches();scopeContext.clearCaches()
                            }
                        }
                        return true
                    }
                    guard ok==true,let last=queue.makeCommandBuffer() else{throw DevelopmentError.invalidEncoding}
                    try compare(last,halfStock,halfPort,halfCounts,w/2,h/2);try drain(last);try check()
                    let display=context("z3-identical-display");defer{display.clearCaches()}
                    func visible(_ t:MTLTexture)throws->Data{
                        guard let img=CIImage(mtlTexture:t,options:[.colorSpace:DevelopmentColorEngineV3.linearSRGB]) else{throw DevelopmentError.invalidEncoding}
                        return try raster(V3PreviewMaterializer.materialize(graph,context:display,maxPixel:2400,checkedLinearHalf:img))
                    }
                    let viaCI=try visible(halfStock),viaPort=try visible(halfPort)
                    guard digest(viaCI)==old[i] else {throw NSError(domain:"control banded stock failed \(id) \(i)",code:2)}
                    let np=stats(nativeCounts),hp=stats(halfCounts)
                    guard (np["pixels"] as? UInt32)==UInt32(w*h),(hp["pixels"] as? UInt32)==UInt32(w*h/4) else {throw DevelopmentV3Error.invalidGraph}
                    let result:[String:Any]=["id":id,"state":i,"archiveSHA256":old[i],"stockBandedDisplaySHA256":digest(viaCI),
                        "candidateDisplaySHA256":digest(viaPort),"stockBandVsArchive":diff(stockDisplay,viaCI),"candidateVsArchive":diff(stockDisplay,viaPort),
                        "candidateVsStockBand":diff(viaCI,viaPort),"nativeRGBAf":np,"halfRGBAf":hp,"externalStockCoverage":externalCoverage,"shader":real ? "public named IOSurface C ABI":variant,"sampleBytes":samples.count,"sampleSHA256":digest(samples)]
                    let sampleURL=out.deletingPathExtension().appendingPathExtension("\(id)-\(i).bin")
                    try samples.write(to:sampleURL,options:.withoutOverwriting)
                    report.append(result)
                    let body:[String:Any]=["cases":report,"inputSHA256":shot.contentSHA256,"archiveSHA256":try RenderFiles.hash(archive),
                        "nativeSize":[w,h],"device":device.name,"runtimeSHA256":runtimeSeal,"sampleContract":"uint4 x/logicalY/0/0 + 3 float4s input/stock/port, header 64"]
                    try JSONSerialization.data(withJSONObject:body,options:[.prettyPrinted,.sortedKeys]).write(to:out,options:.atomic)
                    print("\(id)/\(i) native \(np) half \(hp) display \(diff(stockDisplay,viaPort))");fflush(stdout)
                }
            }
        }
        try check()
    }
    static func main()throws{
        let argv=CommandLine.arguments;guard argv.count==5 else {throw DevelopmentError.invalidEncoding}
        try process(raw:URL(fileURLWithPath:argv[1]),archive:URL(fileURLWithPath:argv[2]),out:URL(fileURLWithPath:argv[3]),ids:Set(argv[4].split(separator:",").map(String.init)))
    }
}

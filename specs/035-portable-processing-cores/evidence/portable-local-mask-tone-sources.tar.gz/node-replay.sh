#!/bin/bash
set -eu
replay=$1;lib=$2;backend=$3;dir=$4
mkdir -p "$dir"
while read -r key file wire maskid; do
 "$replay" "$lib" "$backend" "$file" "$wire" "$maskid" "$dir/$key.rgba" > "$dir/$key.json"
done < intake.tsv

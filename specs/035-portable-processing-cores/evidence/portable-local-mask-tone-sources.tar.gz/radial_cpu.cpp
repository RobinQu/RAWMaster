#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
using RGB=std::array<float,3>;
struct Pixel {float v[4];};
struct U {uint32_t w,h,y,rows; float e[4],a[4],t[4];};
struct R {uint32_t x,y,pad[2];Pixel src,stock,gpu;};
static_assert(sizeof(R)==64 && sizeof(U)==64);
static float clamp01(float x){return std::clamp(x,0.f,1.f);}
static float smooth(float a,float b,float x) {
    float t=clamp01((x-a)/std::max(b-a,1e-5f));return t*t*(3-2*t);
}
static float sign(float x){return (x>0.f)-(x<0.f);}
static float enc(float x){float a=std::abs(x);return sign(x)*(a<=.0031308f?12.92f*a:1.055f*std::pow(a,1.f/2.4f)-.055f);}
static float dec(float x){float a=std::abs(x);return sign(x)*(a<=.04045f?a/12.92f:std::pow((a+.055f)/1.055f,2.4f));}
static float lum(const RGB& c){return std::fma(c[0],.2126f,std::fma(c[1],.7152f,c[2]*.0722f));}
static float fract(float x){return x-std::floor(x);}
static float coverage(const U& u,uint32_t x,uint32_t y) {
    float dx=((x+.5f)/u.w-u.e[0])/u.e[2],dy=(1.f-(y+.5f)/u.h-u.e[1])/u.e[3];
    return clamp01(1.f-smooth(1.f,1.f,std::sqrt(std::fma(dx,dx,dy*dy))));
}
static Pixel point(Pixel p,const U& u,float m) {
    if(m<=0||p.v[3]<=0||!std::all_of(p.v,p.v+4,[](float v){return std::isfinite(v);}))return p;
    RGB c;for(int i=0;i<3;i++)c[i]=(p.v[i]/p.v[3])*std::exp2(2*u.a[0]*m);
    float e=clamp01(enc(lum(c)));float f1=1.f+.5f*u.a[1]*smooth(.5f,1.f,e)*m;
    for(auto& v:c)v*=f1;
    float f2=1.f+.5f*u.a[2]*(1.f-smooth(0,.5f,e))*m;for(auto& v:c)v*=f2;
    float y=lum(c);e=enc(y);float contrast=u.t[0]*m;
    if(e>0&&e<1&&contrast!=0){
        float p=.55f,z=std::exp2(1.3f*contrast);
        float target=e<p ? p*std::pow(e/p,z) : 1.f-(1.f-p)*std::pow((1.f-e)/(1.f-p),z);
        float d=dec(target);for(auto& v:c)v=std::abs(y)>1e-8f?v*(d/y):v+(d-y);
    }
    float k=.05f*u.t[2]*m;for(auto& v:c)v=(v-k)/(1.f-k);
    float white=smooth(.45f,1,clamp01(enc(lum(c))));for(auto& v:c)v*=1.f+.35f*u.t[1]*white*m;
    float hue=u.t[3]*m;
    if(hue!=0) {
        RGB e;std::transform(c.begin(),c.end(),e.begin(),enc);
        float hi=std::max({e[0],e[1],e[2]}),lo=std::min({e[0],e[1],e[2]}),d=hi-lo,h=0;
        if(d>1e-8f)h=hi==e[0]?(e[1]-e[2])/d:hi==e[1]?2.f+(e[2]-e[0])/d:4.f+(e[0]-e[1])/d;
        h=fract(fract(h/6)+hue+1.f);float s=hi>1e-8f?d/hi:0;
        const float offsets[3]={0.f,2.f/3.f,1.f/3.f};
        for(int i=0;i<3;i++){float q=clamp01(std::abs(fract(h+offsets[i])*6-3)-1);c[i]=dec(hi*std::fma(q-1,s,1.f));}
    }
    float gray=lum(c);for(int i=0;i<3;i++)p.v[i]=std::fma(c[i]-gray,1.f+u.a[3]*m,gray)*p.v[3];return p;
}
static int selftest(){
    U u{9504,6336,0,0,{.5f,.5f,.35f,.3f},{},{}};
    const float xs[]={-65504,-1,-0.f,0,0x1p-24f,.00313f,1,65504};uint64_t states=0;
    for(int control=0;control<8;control++)for(float val:{-2.f,-1.f,.15f,.55f,1.f,2.f}){
        if((val==2.f||val==-2.f)&&control!=0&&control!=6&&!(control==4&&val==2.f))continue;
        std::fill(u.a,u.a+4,0);std::fill(u.t,u.t+4,0);
        (control<4?u.a[control]:u.t[control-4])=val;
        for(float a:xs)for(float b:xs)for(float c:xs){Pixel p{{a,b,c,1}};
            Pixel q=point(p,u,0);assert(!std::memcmp(&p,&q,sizeof(p)));
            for(float m:{0x1p-22f,.5f,1.f}){auto t=point(p,u,m);assert(std::all_of(t.v,t.v+4,[](float x){return std::isfinite(x);}));states++;}
        }
    }
    assert(smooth(1,1,1)==0 && smooth(1,1,1.000005f)>0 && smooth(1,1,1.000005f)<1 && smooth(1,1,1.00002f)==1);
    std::cout<<"{\"finiteCases\":"<<states<<",\"zeroIdentityCases\":"<<states/3<<",\"fractionalZeroFeatherRing\":true}\n";return 0;
}
int main(int argc,char** argv){
    if(argc==1)return selftest();
    std::ifstream f(argv[1],std::ios::binary);U u{};if(!f.read((char*)&u,sizeof(u)))return 2;
    size_t count=0,changed=0,wide=0,alpha=0,outside=0,partial=0,empty=0,wet=0;float maxerr=0;
    R r;while(f.read((char*)&r,sizeof(r))){
        float m=coverage(u,r.x,r.y);if(argc>2){std::memcpy(&m,r.pad,4);if(!std::isfinite(m)||m<0||m>1)return 5;}
        auto v=point(r.src,u,m);count++;partial+=m>0&&m<1;empty+=m==0;wet+=m==1;
        if(m==0&&std::memcmp(&r.src,&v,sizeof(v)))return 3;
        for(int k=0;k<4;k++){float d=std::abs(v.v[k]-r.stock.v[k]);maxerr=std::max(maxerr,d);
            bool bits=std::memcmp(v.v+k,r.stock.v+k,4)!=0;changed+=bits;wide+=d>2e-6f;alpha+=bits&&k==3;outside+=bits&&m==0;}
    }
    if(!f.eof()||!count||f.gcount()!=0)return 4;
    std::cout<<"{\"samples\":"<<count<<",\"partial\":"<<partial<<",\"outside\":"<<empty<<",\"inside\":"<<wet
    <<",\"changedComponents\":"<<changed<<",\"over2e6\":"<<wide<<",\"maxAbs\":"<<maxerr<<",\"alphaChanges\":"<<alpha
    <<",\"outsideMismatchComponents\":"<<outside<<"}\n";return 0;
}

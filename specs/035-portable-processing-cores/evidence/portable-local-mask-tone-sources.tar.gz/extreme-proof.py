import ctypes as c,json,struct,sys
from pathlib import Path
z=Path(__file__).resolve().parent
# Exact v2 C ABI, imported as test helper from the core's fixture replayer.
sys.path.insert(0,str(z.parents[3]/'Modules/ImageEdit/tests'))
from replay_named_coverage import open_runtime,Coverage
cpu=int(sys.argv[1]);lib=open_runtime(z/'bin/mac-product.dylib')
wire=json.loads((z/'intake/primary.light-mask-exposure-0.json').read_text())
maskid=wire['nodes'][0]['mask'].encode();h=c.c_void_p();wire=json.dumps(wire).encode()
assert lib.rm_image_plan_open_v2(wire,len(wire),None,0,cpu,c.byref(h))==0
frombits=lambda u:struct.unpack('<f',struct.pack('<I',u))[0]
cases=[]
try:
 for alpha in [0x00800000,1,0x3f800000]:
  for m in [0.,1.]:
   src=(c.c_float*4)(frombits(0x7f7fffff),1,1,frombits(alpha));mask=(c.c_float*1)(m);out=(c.c_float*4)(7,7,7,7)
   plane=Coverage(maskid,len(maskid),mask,1)
   status=lib.rm_image_plan_render_v2(h,1,1,src,4,c.byref(plane),1,out,4)
   cases.append(dict(alphaBits=hex(alpha),density=m,status=status,output=[hex(u) for u in struct.unpack('<4I',bytes(out))]))
finally:lib.rm_image_plan_close_v1(h)
print(json.dumps(cases,indent=2))

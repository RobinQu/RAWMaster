use naga::{back::msl, valid};
use std::{env,fs};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args=env::args().skip(1);
    let source=fs::read_to_string(args.next().ok_or("missing WGSL")?)?;
    let module=naga::front::wgsl::parse_str(&source)
        .map_err(|e|e.emit_to_string(&source))?;
    let info=valid::Validator::new(valid::ValidationFlags::all(),valid::Capabilities::all())
        .validate(&module)?;
    let mut options=msl::Options{lang_version:(2,3),fake_missing_bindings:false,..Default::default()};
    let mut binds=msl::EntryPointResources::default();
    for (binding,target) in [
        (0,msl::BindTarget{texture:Some(0),..Default::default()}),
        (1,msl::BindTarget{texture:Some(1),mutable:true,..Default::default()}),
        (2,msl::BindTarget{buffer:Some(0),..Default::default()}),
        (3,msl::BindTarget{texture:Some(2),..Default::default()}),
    ] { binds.resources.insert(naga::ResourceBinding{group:0,binding},target); }
    options.per_entry_point_map.insert("radial_band".into(),binds);
    let (out,meta)=msl::write_string(&module,&info,&options,&Default::default())?;
    assert_eq!(meta.entry_point_names.len(),1);
    eprintln!("entry: {}",meta.entry_point_names[0].as_ref().unwrap());
    fs::write(args.next().ok_or("missing MSL output")?,out)?;
    Ok(())
}

The original two photos are not included. The stock driver rejects a different source SHA or a different stock final display digest. Use the current RAWMaster Release with the original public FlashRaw 0.3.1 provider and the matching 37-operation native archives named in the verification record.

Extract the archive in an empty directory. Set rawmaster-image.runtime to the sealed product pathname. Launch the driver with absolute paths. Run the two roles sequentially. The output basenames primary.json and secondary.json select the corresponding 16 original recipe wires. Existing sample files cause a failure rather than replacement.

    bash /path/to/study/compile-study.sh
    export RAWMASTER_FLASHRAW_LIBRARY=/path/to/libflashraw_capi.dylib
    export Z3_CI_COVERAGE=1 Z3_HUE_LITERAL=1 Z3_PRODUCT_C_ABI=1 Z3_IMAGE_BINARY=/path/to/real/rawmaster-image.runtime
    controls=color-mask-hue,color-mask-saturation,light-mask-blacks,light-mask-contrast,light-mask-exposure,light-mask-highlights,light-mask-shadows,light-mask-whites
    /path/to/study/bin/radial /path/to/primary.ARW /path/to/primary-official-37-op.json /new/dir/primary.json "$controls"
    /path/to/study/bin/radial /path/to/secondary.ARW /path/to/secondary-official-37-op.json /new/dir/secondary.json "$controls"

The actual v2 JSON wires, exact WGSL used in the diagnostic, separate C++ fixture and official public-ABI replayer are included. The product node itself is under Modules/ImageEdit. Set Z3_PRODUCT_C_ABI=0 to test the independent Rust/Naga WGSL path. With Z3_CI_COVERAGE=0 it reconstructs the analytic zero-feather ellipse; with Z3_HUE_LITERAL=0 it deliberately replaces the original HSV phase expression with fract.

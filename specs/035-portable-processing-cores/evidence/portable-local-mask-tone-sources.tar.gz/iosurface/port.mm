#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <IOSurface/IOSurface.h>
#import <CoreVideo/CoreVideo.h>
#import "rawmaster_image_metal.h"
#import "port.h"
#include <dlfcn.h>
#include <cstdio>
@interface ZSurfaces : NSObject {
@public id<MTLTexture> tex[3]; uint32_t width,height;
}
@end
@implementation ZSurfaces
@end
@interface ZProgram : NSObject {
@public RMImagePlan* plan;RMImageMetalProgram* program;void* imageLib;
  decltype(&rm_image_plan_close_v1) planClose;
  decltype(&rm_image_metal_program_close_v1) programClose;
  decltype(&rm_image_metal_frame_bind_v2) bind;
  decltype(&rm_image_metal_frame_render_v1) render;
  decltype(&rm_image_metal_frame_close_v1) frameClose;
}
@end
@implementation ZProgram
-(void)dealloc{
 if(program)programClose(program);if(plan)planClose(plan);
 if(imageLib)dlclose(imageLib);
}
@end
void *z3_program(const char* path,void* obj,const char* wire,size_t n) {
 ZProgram *o=[ZProgram new];o->imageLib=dlopen(path,RTLD_NOW|RTLD_LOCAL);if(!o->imageLib)return nullptr;
 #define SYM(name) (decltype(&name))dlsym(o->imageLib,#name)
 o->planClose=SYM(rm_image_plan_close_v1);o->programClose=SYM(rm_image_metal_program_close_v1);
 o->frameClose=SYM(rm_image_metal_frame_close_v1);o->bind=SYM(rm_image_metal_frame_bind_v2);o->render=SYM(rm_image_metal_frame_render_v1);
 auto open=SYM(rm_image_plan_open_v2);auto gpu=SYM(rm_image_metal_program_open_v1);
 if(!o->planClose||!o->programClose||!o->frameClose||!o->bind||!o->render||!open||!gpu)return nullptr;
 int rc=open((const uint8_t*)wire,n,nullptr,0,0,&o->plan);if(rc||!o->plan)return nullptr;
 rc=gpu(o->plan,obj,&o->program);if(rc||!o->program)return nullptr;
 return (__bridge_retained void*)o;
}
void *z3_surfaces(void *raw,uint32_t w,uint32_t h) {
 id<MTLDevice> device=(__bridge id<MTLDevice>)raw;ZSurfaces* owner=[ZSurfaces new];owner->width=w;owner->height=h;
 for(int i=0;i<3;i++){
  size_t elem=i==1?4:16;size_t stride=IOSurfaceAlignProperty(kIOSurfaceBytesPerRow,w*elem);
  NSDictionary* desc=@{(__bridge NSString*)kIOSurfaceWidth:@(w),(__bridge NSString*)kIOSurfaceHeight:@(h),(__bridge NSString*)kIOSurfaceBytesPerRow:@(stride),
    (__bridge NSString*)kIOSurfaceBytesPerElement:@(elem),(__bridge NSString*)kIOSurfaceAllocSize:@(stride*h),
    (__bridge NSString*)kIOSurfacePixelFormat:@(i==1?kCVPixelFormatType_OneComponent32Float:kCVPixelFormatType_128RGBAFloat)};
  IOSurfaceRef surface=IOSurfaceCreate((__bridge CFDictionaryRef)desc);if(!surface)return nullptr;
  if(IOSurfaceLock(surface,0,nullptr)!=KERN_SUCCESS){CFRelease(surface);return nullptr;}
  memset(IOSurfaceGetBaseAddress(surface),0,IOSurfaceGetAllocSize(surface));
  if(IOSurfaceUnlock(surface,0,nullptr)!=KERN_SUCCESS){CFRelease(surface);return nullptr;}
  MTLTextureDescriptor *td=[MTLTextureDescriptor texture2DDescriptorWithPixelFormat:i==1?MTLPixelFormatR32Float:MTLPixelFormatRGBA32Float width:w height:h mipmapped:NO];
  td.storageMode=MTLStorageModeShared;td.hazardTrackingMode=MTLHazardTrackingModeTracked;td.usage=MTLTextureUsageShaderRead|MTLTextureUsageShaderWrite;
  owner->tex[i]=[device newTextureWithDescriptor:td iosurface:surface plane:0];CFRelease(surface);
  if(!owner->tex[i])return nullptr;
 }
 return (__bridge_retained void*)owner;
}
void* z3_texture(void* surfaces,uint32_t i) {return (__bridge void*)(((__bridge ZSurfaces*)surfaces)->tex[i]);}
int32_t z3_render(void *handle,void *surfaces,const char* name,size_t n,uint64_t revision,ZCurrent check,void* who) {
 ZProgram* p=(__bridge ZProgram*)handle;ZSurfaces* s=(__bridge ZSurfaces*)surfaces;
 RMImageMetalCoverageV2 coverage={(const uint8_t*)name,n,(__bridge void*)s->tex[1]};
 RMImageMetalSurfacesV2 view={sizeof(RMImageMetalSurfacesV2),s->width,s->height,0,(__bridge void*)s->tex[0],(__bridge void*)s->tex[2],&coverage,1,nullptr,nullptr};
 RMImageMetalFrame* f=nullptr;int b=p->bind(p->program,p->plan,&view,&f);
 if(b||!f){fprintf(stderr,"bind returned %d\n",b);return b?:99;}
 int r=p->render(f,p->plan,revision,check,who);p->frameClose(f);return r;
}
void z3_release(void* obj) {if(obj)CFBridgingRelease(obj);}

Reproduce from a RAWMaster macOS Release checkout on the measured Apple M4 Max/macOS 27 host. Use the verified original files named by the two source SHA-256 values. The check needs the original Swift/Metal benchmark source, testable Release Swift objects and the project's private FlashRaw runtime.

Extract this archive at output/035-development/phase-ab/radial-half; set RAWMASTER_FLASHRAW_LIBRARY to your matching FlashRaw dylib. Run from the checkout:

    study=output/035-development/phase-ab/radial-half
    mkdir -p "$study/bin" "$study/replay" "$study/replay-faults"
    role=primary  # or secondary, matched to the source SHA below
    cargo build --release --locked --manifest-path "$study/module/Cargo.toml" --features native-half-probe --target-dir "$study/cargo-target"
    cp "$study/cargo-target/release/librawmaster_image.dylib" "$study/bin/mask-half-trace.dylib"
    zsh "$study/build-scope.sh"
    zsh "$study/build-witness.sh"
    "$study/bin/scope" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json new-scope.json
    "$study/bin/witness" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json "$study/replay/$role.json" "$study/bin/mask-half-trace.dylib" correct all "$study"
    "$study/bin/witness" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json "$study/replay-faults/$role.json" "$study/bin/mask-half-trace.dylib" fault light-mask-exposure "$study"

FrozenScope compares the exact scope result's alpha over each original 256-row tile. Witness reads the complete native source-sized result and hardware half as four UInt32 components, then checks archived whole sRGB8. The independent correct mode multiplies memory by retaining an extra private full native texture. Fault mode uses the actual production entry in the instrumented library. The normal app uses the production-only, uninstrumented runtime. The package includes no source photos, model weights or user library. run.py contains the original lab paths; the explicit commands above can use other locations.

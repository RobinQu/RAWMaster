import AppKit
import CoreImage
import CryptoKit
import Darwin
import Foundation
import Metal
import RAWMasterCore
@testable import RAWMasterImaging

@main private enum RadialWitness {
    static func context(_ name: String, queue: MTLCommandQueue? = nil) -> CIContext {
        let options: [CIContextOption: Any] = [
            .name: name, .workingColorSpace: DevelopmentColorEngineV3.linearSRGB,
            .workingFormat: CIFormat.RGBAf.rawValue, .cacheIntermediates: false, .memoryTarget: 512,
        ]
        if let queue { return CIContext(mtlCommandQueue: queue, options: options) }
        return CIContext(options: options)
    }

    static func milliseconds(_ begin: UInt64) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e6
    }

    static func peak() throws -> Int64 {
        var info = task_vm_info_data_t()
        var words = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.stride)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(words)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &words)
            }
        }
        guard status == KERN_SUCCESS else { throw DevelopmentError.invalidEncoding }
        return info.ledger_phys_footprint_peak
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func raster(_ pixels: PreviewPixels) throws -> Data {
        guard pixels.outputSize == CGSize(width: 2400, height: 1600) else { throw DevelopmentError.invalidEncoding }
        let frame = DevelopmentPreviewFrame(frameID: UUID(), image: pixels.image, sessionID: .init(),
            sourceGeneration: 1, consumerID: .init(), revision: 1, quality: .settled,
            canonicalPixelSize: pixels.nativeSize, outputPixelSize: pixels.outputSize, outputKey: "half-fit-probe", approximate: false)
        var bytes = Data(count: 2400 * 1600 * 4)
        try bytes.withUnsafeMutableBytes { try frame.copyDisplayRGBA8(into: $0) }
        return bytes
    }

    static func diff(_ expected: Data, _ actual: Data) -> [String: Any] {
        precondition(expected.count == actual.count && expected.count == 2400 * 1600 * 4)
        var changedPixels = 0, maxCode = 0, alphaChanges = 0, edgeChanges = 0, sum = 0
        expected.withUnsafeBytes { (left: UnsafeRawBufferPointer) in
            actual.withUnsafeBytes { (right: UnsafeRawBufferPointer) in
                for index in stride(from: 0, to: expected.count, by: 4) {
                    var changed = false
                    for channel in 0..<4 {
                        let error = abs(Int(left[index + channel]) - Int(right[index + channel]))
                        if error > 0 {
                            maxCode = max(maxCode, error)
                            sum += error
                            if channel == 3 { alphaChanges += 1 }
                            changed = true
                        }
                    }
                    if changed {
                        let x = (index / 4) % 2400
                        let y = (index / 4) / 2400
                        if x == 0 || x == 2399 || y == 0 || y == 1599 { edgeChanges += 1 }
                        changedPixels += 1
                    }
                }
            }
        }
        return ["changedPixels": changedPixels, "edgePixels": edgeChanges, "alphaValues": alphaChanges,
                "maxCodeDifference": maxCode, "meanAbsoluteCodeDifference": Double(sum) / Double(expected.count)]
    }

    static func snapshot(_ raw: URL) throws -> EditingSourceSnapshot {
        let hash = try RenderFiles.hash(raw)
        guard let size = try raw.resourceValues(forKeys:[.fileSizeKey]).fileSize else { throw DevelopmentError.unreadable }
        return .init(projectID: "035-curves",assetID: hash,contentSHA256: hash,byteCount: Int64(size),
                     admissionFingerprint: "curves-v3",sourceLocation: raw)
    }


    static let checkShader = """
    #include <metal_stdlib>
    using namespace metal;
    kernel void seedR(texture2d<float,access::write> tex [[texture(0)]],uint2 id [[thread_position_in_grid]]) {
      if(id.x<tex.get_width() && id.y<tex.get_height()) tex.write(as_type<float4>(uint4(0x7fc00000u)),id);
    }
    kernel void compareR(texture2d<float,access::read> ref [[texture(0)]],texture2d<float,access::read> scalar [[texture(1)]],
      device atomic_uint* sums [[buffer(0)]], constant uint4& dims [[buffer(1)]],uint2 id [[thread_position_in_grid]],
      uint lane [[thread_index_in_simdgroup]]) {
      bool active=id.x<dims.x && id.y<dims.y;
      float a=active?ref.read(id).a:0;float b=active?scalar.read(uint2(id.x,id.y+dims.z)).r:0;
      uint bits=as_type<uint>(b);uint good=simd_sum(uint(active));uint diff=simd_sum(uint(active&& as_type<uint>(a)!=bits));
      uint invalid=simd_sum(uint(active&&(bits>0x3f800000u&&bits!=0x80000000u)));
      uint feather=simd_sum(uint(active&&a>0.f&&a<1.f));uint zero=simd_sum(uint(active&&a==0.f));uint ones=simd_sum(uint(active&&a==1.f));
      if(lane==0){uint k[6]={good,diff,invalid,feather,zero,ones};for(int i=0;i<6;i++)if(k[i])atomic_fetch_add_explicit(sums+i,k[i],memory_order_relaxed);}
    }
    """
    static func main()throws{
      let argv=CommandLine.arguments
      let raw=URL(fileURLWithPath:argv[1]), archive=URL(fileURLWithPath:argv[2]), out=URL(fileURLWithPath:argv[3])
      let shot=try snapshot(raw);let cap=try RenderFiles.verifiedPreviewCapture(shot);defer{try? FileManager.default.removeItem(at:cap.url.deletingLastPathComponent())}
      let check={try cap.requireCurrent(at:cap.url)}
      let uploaded=try FlashRawImageFactory.nativePreviewImage(capture:cap.url,rawDetails:nil,retainNativeTexture:true)
      let w=Int(uploaded.image.extent.width),h=Int(uploaded.image.extent.height)
      let pool=FlashRawCanonicalTexturePool(byteBudget:1024*1024*1024)
      let key=FlashRawCanonicalTextureKey(sourceKey:shot.contentSHA256,captureStamp:cap.stamp,contract:"ab-native-scope",width:w,height:h)
      let pin=try pool.acquireNative(key){uploaded};defer{pin.release()}
      guard try pin.checkOpaqueUpload(pin.image,cancellation:check),let dev=MTLCreateSystemDefaultDevice(),let queue=dev.makeCommandQueue(),
        let pack=try JSONSerialization.jsonObject(with:Data(contentsOf:archive)) as? [String:Any],shot.contentSHA256==pack["sourceSHA256"] as? String,
        let ops=pack["operations"] as? [[String:Any]],let op=ops.first(where:{$0["id"] as? String=="light-mask-exposure"}),
        let desc=(op["stateDescriptions"] as? [[String:Any]])?.first else{throw DevelopmentV3Error.invalidGraph}
      let p=try JSONDecoder().decode(DevelopmentRecipe.self,from:JSONSerialization.data(withJSONObject:desc))
      guard let layer=p.adjustmentsV3?.masks.first else{throw DevelopmentV3Error.invalidGraph}
      let sc=DevelopmentMaskEngineV3.ScopeSelection(layer);try sc.capture(pin.image)
      guard let coverage=sc.coverage else{throw DevelopmentV3Error.invalidGraph}
      let ci=context("ab-exact-f32-scope",queue:queue);defer{ci.clearCaches()}
      let lib=try dev.makeLibrary(source:checkShader,options:nil)
      let seed=try dev.makeComputePipelineState(function:lib.makeFunction(name:"seedR")!),cmp=try dev.makeComputePipelineState(function:lib.makeFunction(name:"compareR")!)
      func make(_ width:Int,_ height:Int,_ format:MTLPixelFormat)throws->MTLTexture {
        let d=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:format,width:width,height:height,mipmapped:false);d.storageMode = .private; d.usage=[.renderTarget,.shaderRead,.shaderWrite]
        guard let t=dev.makeTexture(descriptor:d) else{throw DevelopmentError.invalidEncoding};return t
      }
      func drain(_ c:MTLCommandBuffer)throws{c.commit();c.waitUntilCompleted();guard c.status == .completed else{throw DevelopmentError.invalidEncoding};try check()}
      func render(_ image:CIImage,_ t:MTLTexture,_ r:CGRect,_ origin:CGPoint)throws{
        let dest=CIRenderDestination(mtlTexture:t,commandBuffer:nil);dest.isFlipped=false;dest.isClamped=false;dest.isDithered=false;dest.alphaMode = .premultiplied;dest.colorSpace=DevelopmentColorEngineV3.linearSRGB
        _=try ci.startTask(toRender:image,from:r,to:dest,at:origin).waitUntilCompleted();try check()
      }
      let ref=try make(w,256,.rgba32Float),dst=try make(w,h,.r32Float)
      var reports=[[String:Any]]()
      for mode in ["whole-direct","band-direct","whole-alpha"] {
        let cmd=queue.makeCommandBuffer()!,enc=cmd.makeComputeCommandEncoder()!;enc.setComputePipelineState(seed);enc.setTexture(dst,index:0);enc.dispatchThreads(.init(width:w,height:h,depth:1),threadsPerThreadgroup:.init(width:16,height:16,depth:1));enc.endEncoding();try drain(cmd)
        let start=DispatchTime.now().uptimeNanoseconds
        let z=CIVector(x:0,y:0,z:0,w:0),a=CIVector(x:0,y:0,z:0,w:1)
        let src=mode=="whole-alpha" ? coverage.applyingFilter("CIColorMatrix",parameters:["inputRVector":a,"inputGVector":z,"inputBVector":z,"inputAVector":z,"inputBiasVector":a]) : coverage
        if mode=="band-direct" {for y in stride(from:0,to:h,by:256){try render(src,dst,CGRect(x:0,y:y,width:w,height:min(256,h-y)),CGPoint(x:0,y:y))}}
        else{try render(src,dst,CGRect(x:0,y:0,width:w,height:h),.zero)}
        let elapsed=milliseconds(start)
        let buf=dev.makeBuffer(length:32,options:.storageModeShared)!;memset(buf.contents(),0,32)
        for y in stride(from:0,to:h,by:256){
          let rows=min(256,h-y);try render(coverage,ref,CGRect(x:0,y:y,width:w,height:rows),.zero)
          let c=queue.makeCommandBuffer()!,e=c.makeComputeCommandEncoder()!;e.setComputePipelineState(cmp);e.setTexture(ref,index:0);e.setTexture(dst,index:1);e.setBuffer(buf,offset:0,index:0);var dims=SIMD4<UInt32>(UInt32(w),UInt32(rows),UInt32(y),0);e.setBytes(&dims,length:16,index:1);e.dispatchThreads(.init(width:w,height:rows,depth:1),threadsPerThreadgroup:.init(width:16,height:16,depth:1));e.endEncoding();try drain(c)
        }
        let v=buf.contents().bindMemory(to:UInt32.self,capacity:8);guard v[0]==UInt32(w*h) else{throw DevelopmentV3Error.invalidGraph}
        reports.append(["mode":mode,"dimensions":[w,h],"nativeScalars":v[0],"differingBits":v[1],"invalidOrUnwritten":v[2],"fractional":v[3],"zero":v[4],"one":v[5],"encodingMs":elapsed,"bytes":dst.allocatedSize,"inputSHA256":shot.contentSHA256])
        try JSONSerialization.data(withJSONObject:reports,options:[.prettyPrinted,.sortedKeys]).write(to:out,options:.atomic)
      }
    }
}

import AppKit
import CoreImage
import CryptoKit
import Darwin
import Foundation
import Metal
import RAWMasterCore
@testable import RAWMasterImaging

@main private enum RadialWitness {
    static func context(_ name: String, queue: MTLCommandQueue? = nil) -> CIContext {
        let options: [CIContextOption: Any] = [
            .name: name, .workingColorSpace: DevelopmentColorEngineV3.linearSRGB,
            .workingFormat: CIFormat.RGBAf.rawValue, .cacheIntermediates: false, .memoryTarget: 512,
        ]
        if let queue { return CIContext(mtlCommandQueue: queue, options: options) }
        return CIContext(options: options)
    }

    static func milliseconds(_ begin: UInt64) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e6
    }

    static func peak() throws -> Int64 {
        var info = task_vm_info_data_t()
        var words = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.stride)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(words)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &words)
            }
        }
        guard status == KERN_SUCCESS else { throw DevelopmentError.invalidEncoding }
        return info.ledger_phys_footprint_peak
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func raster(_ pixels: PreviewPixels) throws -> Data {
        guard pixels.outputSize == CGSize(width: 2400, height: 1600) else { throw DevelopmentError.invalidEncoding }
        let frame = DevelopmentPreviewFrame(frameID: UUID(), image: pixels.image, sessionID: .init(),
            sourceGeneration: 1, consumerID: .init(), revision: 1, quality: .settled,
            canonicalPixelSize: pixels.nativeSize, outputPixelSize: pixels.outputSize, outputKey: "half-fit-probe", approximate: false)
        var bytes = Data(count: 2400 * 1600 * 4)
        try bytes.withUnsafeMutableBytes { try frame.copyDisplayRGBA8(into: $0) }
        return bytes
    }

    static func diff(_ expected: Data, _ actual: Data) -> [String: Any] {
        precondition(expected.count == actual.count && expected.count == 2400 * 1600 * 4)
        var changedPixels = 0, maxCode = 0, alphaChanges = 0, edgeChanges = 0, sum = 0
        expected.withUnsafeBytes { (left: UnsafeRawBufferPointer) in
            actual.withUnsafeBytes { (right: UnsafeRawBufferPointer) in
                for index in stride(from: 0, to: expected.count, by: 4) {
                    var changed = false
                    for channel in 0..<4 {
                        let error = abs(Int(left[index + channel]) - Int(right[index + channel]))
                        if error > 0 {
                            maxCode = max(maxCode, error)
                            sum += error
                            if channel == 3 { alphaChanges += 1 }
                            changed = true
                        }
                    }
                    if changed {
                        let x = (index / 4) % 2400
                        let y = (index / 4) / 2400
                        if x == 0 || x == 2399 || y == 0 || y == 1599 { edgeChanges += 1 }
                        changedPixels += 1
                    }
                }
            }
        }
        return ["changedPixels": changedPixels, "edgePixels": edgeChanges, "alphaValues": alphaChanges,
                "maxCodeDifference": maxCode, "meanAbsoluteCodeDifference": Double(sum) / Double(expected.count)]
    }

    static func snapshot(_ raw: URL) throws -> EditingSourceSnapshot {
        let hash = try RenderFiles.hash(raw)
        guard let size = try raw.resourceValues(forKeys:[.fileSizeKey]).fileSize else { throw DevelopmentError.unreadable }
        return .init(projectID: "035-curves",assetID: hash,contentSHA256: hash,byteCount: Int64(size),
                     admissionFingerprint: "curves-v3",sourceLocation: raw)
    }


    final class Access {
      let check:()throws->Void; var calls=0;var stopAt:Int?
      init(_ check:@escaping()throws->Void){self.check=check}
      func touch()->Bool{calls+=1;do{try check();return stopAt.map{calls<$0} ?? true}catch{return false}}
    }
    typealias Auth = @convention(c)(UnsafeMutableRawPointer?,UInt64)->UInt32
    static let auth:Auth = {obj,rev in guard rev==93,let obj else{return 0};return Unmanaged<Access>.fromOpaque(obj).takeUnretainedValue().touch() ? 1:0}
    typealias P = UnsafeMutableRawPointer
    typealias PlanOpen = @convention(c)(UnsafePointer<UInt8>?,Int,UnsafePointer<UInt8>?,Int,UInt32,UnsafeMutablePointer<P?>)->Int32
    typealias Open = @convention(c)(P,P,UnsafeMutablePointer<P?>)->Int32
    typealias Close = @convention(c)(P)->Void
    typealias Run = @convention(c)(P,P,P,UnsafePointer<UInt8>,Int,P,P,UInt64,Auth,P)->Int32
    typealias Trace = @convention(c)(P,P,P,UnsafePointer<UInt8>,Int,P,P,P,UInt64,Auth,P)->Int32
    static func main()throws {
      let av=CommandLine.arguments;let raw=URL(fileURLWithPath:av[1]),archive=URL(fileURLWithPath:av[2]),out=URL(fileURLWithPath:av[3]),libURL=URL(fileURLWithPath:av[4]),measured=av[5]=="speed",fault=av[5]=="fault"
      let selected=av[6].split(separator:",").map(String.init)
      guard let dl=dlopen(libURL.path,RTLD_LOCAL|RTLD_NOW) else{throw DevelopmentError.invalidEncoding};defer{dlclose(dl)}
      func sym<T>(_ name:String,_ type:T.Type)throws->T{guard let s=dlsym(dl,name) else{throw NSError(domain:name,code:1)};return unsafeBitCast(s,to:type)}
      let parse=try sym("rm_image_plan_open_v2",PlanOpen.self),open=try sym("rm_image_metal_mask_half_program_open_v1",Open.self),run=try sym("rm_image_metal_mask_half_render_v1",Run.self),trace=try sym("rm_image_test_mask_half_trace",Trace.self),close=try sym("rm_image_metal_half_program_close_v1",Close.self),closePlan=try sym("rm_image_plan_close_v1",Close.self)
      let shot=try snapshot(raw),cap=try RenderFiles.verifiedPreviewCapture(shot);defer{try? FileManager.default.removeItem(at:cap.url.deletingLastPathComponent())}
      let check={try cap.requireCurrent(at:cap.url)}
      guard let desc=try JSONSerialization.jsonObject(with:Data(contentsOf:archive)) as? [String:Any],
            let ops=desc["operations"] as? [[String:Any]],desc["sourceSHA256"] as? String==shot.contentSHA256,
            let dev=MTLCreateSystemDefaultDevice(),let q=dev.makeCommandQueue(),let rule=CIRAWFilter(imageURL:cap.url) else{throw DevelopmentError.invalidEncoding}
      let upload=try FlashRawImageFactory.nativePreviewImage(capture:cap.url,rawDetails:nil,retainNativeTexture:true)
      let w=Int(upload.image.extent.width),h=Int(upload.image.extent.height)
      let pool=FlashRawCanonicalTexturePool(byteBudget:1024*1024*1024)
      let pin=try pool.acquireNative(.init(sourceKey:shot.contentSHA256,captureStamp:cap.stamp,contract:"ab-real-half",width:w,height:h)){upload};defer{pin.release()}
      guard try pin.checkOpaqueUpload(pin.image,cancellation:check) else {throw DevelopmentV3Error.invalidGraph}
      let authority=Access{try check();guard pin.isCurrent(for:pin.image) else{throw DevelopmentV3Error.invalidGraph}}
      nonisolated func p(_ x:AnyObject)->P{Unmanaged.passUnretained(x).toOpaque()}
      let oracle=URL(fileURLWithPath:av[7]);let src=try String(contentsOf:oracle.appendingPathComponent("measure.metal"),encoding:.utf8)
      let m=try dev.makeLibrary(source:src,options:nil),cmp=try dev.makeComputePipelineState(function:m.makeFunction(name:"compare")!),sample=try dev.makeComputePipelineState(function:m.makeFunction(name:"halfSample")!)
      let options:MTLTextureUsage=[.renderTarget,.shaderRead,.shaderWrite]
      func make(_ ww:Int,_ hh:Int,_ fmt:MTLPixelFormat)throws->MTLTexture{let d=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:fmt,width:ww,height:hh,mipmapped:false);d.storageMode = .private;d.usage=options;guard let t=dev.makeTexture(descriptor:d) else{throw DevelopmentError.invalidEncoding};return t}
      func drain(_ c:MTLCommandBuffer)throws{c.commit();c.waitUntilCompleted();guard c.status == .completed else{throw c.error ?? DevelopmentError.invalidEncoding};try check()}
      func clear(_ tex:MTLTexture,_ red:Double=0)throws{let pass=MTLRenderPassDescriptor();pass.colorAttachments[0].texture=tex;pass.colorAttachments[0].loadAction = .clear;pass.colorAttachments[0].storeAction = .store;pass.colorAttachments[0].clearColor = .init(red:red,green:0,blue:0,alpha:0)
        guard let c=q.makeCommandBuffer(),let e=c.makeRenderCommandEncoder(descriptor:pass) else{throw DevelopmentError.invalidEncoding};e.endEncoding();try drain(c)}
      func dispatch(_ c:MTLCommandBuffer,_ pipe:MTLComputePipelineState,_ textures:[MTLTexture],_ ww:Int,_ hh:Int,_ setup:(MTLComputeCommandEncoder)->Void)throws{guard let e=c.makeComputeCommandEncoder() else{throw DevelopmentError.invalidEncoding};e.setComputePipelineState(pipe);for (i,t) in textures.enumerated(){e.setTexture(t,index:i)};setup(e);e.dispatchThreads(.init(width:ww,height:hh,depth:1),threadsPerThreadgroup:.init(width:8,height:8,depth:1));e.endEncoding()}
      func compare(_ c:MTLCommandBuffer,_ a:MTLTexture,_ b:MTLTexture,_ sums:MTLBuffer,_ ww:Int,_ hh:Int)throws{
        var dims=SIMD2<UInt32>(UInt32(ww),UInt32(hh));try dispatch(c,cmp,[a,b],ww,hh){$0.setBuffer(sums,offset:0,index:0);$0.setBytes(&dims,length:8,index:1)}
      }
      func stats(_ b:MTLBuffer)->[String:Any]{let s=b.contents().bindMemory(to:UInt32.self,capacity:8);return ["pixels":s[0],"changedPixels":s[1],"components":s[2],"alpha":s[3],"maximum":Float(bitPattern:s[4]),"nonfinite":s[5]]}
      let resident=try make(w,h,.r32Float);let half=try make(w/2,h/2,.rgba32Float);let native = !measured && !fault ? try make(w,h,.rgba32Float):nil
      let ref=(!measured && !fault) ? try make(w,256,.rgba32Float):nil, actualBand=(!measured && !fault) ? try make(w,256,.rgba32Float):nil
      let stockHalf = !measured && !fault ? try make(w/2,h/2,.rgba32Float):nil
      try clear(half);if let native {try clear(native)}
      let ctx=context("ab-stock-band",queue:q);defer{ctx.clearCaches()}
      var active:[String:P]=[:];defer{for program in active.values{close(program)}}
      var frozenLayer:DevelopmentMaskLayerV3?
      func mask(_ layer:DevelopmentMaskLayerV3,force:Bool=false)throws->Bool{
        var geometry=layer; geometry.adjustments = .init()
        if !force,geometry==frozenLayer{return false}
        let sc=DevelopmentMaskEngineV3.ScopeSelection(layer);try sc.capture(pin.image);guard let coverage=sc.coverage else{throw DevelopmentV3Error.invalidGraph}
        try clear(resident,Double.nan)
        let dest=CIRenderDestination(mtlTexture:resident,commandBuffer:nil);dest.isFlipped=false;dest.isDithered=false;dest.isClamped=false;dest.alphaMode = .premultiplied;dest.colorSpace=DevelopmentColorEngineV3.linearSRGB
        _=try ctx.startTask(toRender:coverage,from:pin.image.extent,to:dest,at:.zero).waitUntilCompleted();try check()
        frozenLayer=geometry;return true
      }
      let assetSeal=try RenderFiles.hash(libURL)
      var results=[[String:Any]]();let wb=DevelopmentAsShotWhiteBalance(temperature:rule.neutralTemperature,tint:rule.neutralTint)
      for op in ops {
        guard let id=op["id"] as? String,(selected.contains(id)||selected.contains("all")),let states=op["stateDescriptions"] as? [[String:Any]],let expected=op["firstStateFullFrameDigests"] as? [String] else{continue}
        let all:Set<String>=["color-mask-hue","color-mask-saturation","light-mask-blacks","light-mask-contrast","light-mask-exposure","light-mask-highlights","light-mask-shadows","light-mask-whites"];guard all.contains(id) else{continue}
        for (index,desc) in states.enumerated(){
          try autoreleasepool{
            let recipe=try JSONDecoder().decode(DevelopmentRecipe.self,from:JSONSerialization.data(withJSONObject:desc));guard let a=recipe.adjustmentsV3,let layer=a.masks.first,try FlashRawImageFactory.applyInputAdjustments(a,to:pin.image,asShotWhiteBalance:wb)===pin.image else{throw DevelopmentV3Error.invalidGraph}
            let src=id.split(separator:"-").last!;let wireURL=oracle.appendingPathComponent("intake").appendingPathComponent("\(out.deletingPathExtension().lastPathComponent).\(id)-\(index).json")
            let wire=try Data(contentsOf:wireURL);var handle:P?;guard wire.withUnsafeBytes({parse($0.bindMemory(to:UInt8.self).baseAddress,wire.count,nil,0,0,&handle)})==0,let plan=handle else{throw DevelopmentV3Error.invalidGraph};defer{closePlan(plan)}
            let start=DispatchTime.now().uptimeNanoseconds
            let didFreeze=try mask(layer);let freezeMs=milliseconds(start)
            let label=layer.id.uuidString;let pg:P
            if let previous=active[label]{pg=previous}else{var created:P?;let ret=open(plan,p(dev),&created);guard ret==0,let created else{throw NSError(domain:"native mask half open",code:Int(ret))};active[label]=created;pg=created}
            let nativeStart=DispatchTime.now().uptimeNanoseconds
            var ret:Int32 = -1
            var observedFaults=[String:Int32]()
            let held=try pin.withCheckedOpaqueTexture(for:pin.image,check:check){ photo -> Bool? in
              func go(_ n:String,_ mt:MTLTexture,_ traceTarget:MTLTexture?)->Int32{
                let bytes=Array(n.utf8);return bytes.withUnsafeBufferPointer{ids in
                    if let traceTarget{return trace(pg,plan,p(photo),ids.baseAddress!,bytes.count,p(mt),p(half),p(traceTarget),93,Self.auth,p(authority))}
                    return run(pg,plan,p(photo),ids.baseAddress!,bytes.count,p(mt),p(half),93,Self.auth,p(authority))
                }
              }
              if fault {
                observedFaults["wrongNamedPlane"]=go(label+"x",resident,nil)
                observedFaults["sourceAsMask"]=go(label,photo,nil)
                let illegal=try make(w,h,.r32Float);try clear(illegal,Double.nan)
                observedFaults["unwrittenOrNaN"]=go(label,illegal,nil)
                authority.calls=0;authority.stopAt=7;observedFaults["withdrawAfterSubmission"]=go(label,resident,nil);authority.stopAt=nil
                guard observedFaults==["wrongNamedPlane":1,"sourceAsMask":1,"unwrittenOrNaN":3,"withdrawAfterSubmission":5] else{throw NSError(domain:"bad rejection \(observedFaults)",code:1)}
              }
              ret=go(label,resident,native);guard ret==0 else{throw NSError(domain:"rust resident mask half \(src)",code:Int(ret))};return true
            }
            guard held==true else{throw DevelopmentV3Error.invalidGraph}
            let nativeMs=milliseconds(nativeStart)
            let stockCtx=context("ab-stock-graph");defer{stockCtx.clearCaches()};let t0=DispatchTime.now().uptimeNanoseconds
            let graph=try DevelopmentCanonicalFiniteGPU.$residentPhotoWorkingBudget.withValue(DevelopmentCanonicalFiniteGPU.workingSetLimit){try DevelopmentRendererV3.develop(cap.url,recipe:recipe,suppliedRawBase:pin.image,context:stockCtx,residentGlobalSource:pin)}
            let stock=try raster(V3PreviewMaterializer.materialize(graph,context:stockCtx,maxPixel:2400));guard digest(stock)==expected[index] else{throw NSError(domain:"archive stock",code:2)}
            let stockMs=milliseconds(t0)
            guard let image=CIImage(mtlTexture:half,options:[.colorSpace:DevelopmentColorEngineV3.linearSRGB]) else{throw DevelopmentError.invalidEncoding}
            let display=context("ab-original-fit");defer{display.clearCaches()};let t1=DispatchTime.now().uptimeNanoseconds
            let pixels=try raster(V3PreviewMaterializer.materialize(graph,context:display,maxPixel:2400,checkedLinearHalf:image));let displayMs=milliseconds(t1)
            var line:[String:Any]=["id":id,"state":index,"nativeSize":[w,h],"archive":expected[index],"actualSHA256":digest(pixels),"display":diff(stock,pixels),"maskBytes":resident.allocatedSize,"halfBytes":half.allocatedSize,"actualNativeMS":nativeMs,"maskFreezeMS":freezeMs,"newGeometry":didFreeze,"stockDevelopAndDisplayMS":stockMs,"candidateDisplayMS":displayMs,"faults":observedFaults]
            if let native,let ref,let actualBand,let stockHalf{
              let proof=context("ab-reference-band",queue:q);defer{proof.clearCaches()};var bandReports=[[String:Any]]()
              try clear(ref,Double.nan);try clear(actualBand,Double.nan);try clear(stockHalf,Double.nan)
              let counts=dev.makeBuffer(length:32,options:.storageModeShared)!,hc=dev.makeBuffer(length:32,options:.storageModeShared)!;memset(counts.contents(),0,32);memset(hc.contents(),0,32)
              for y in stride(from:0,to:h,by:256){
                let rows=min(256,h-y);let dest=CIRenderDestination(mtlTexture:ref,commandBuffer:nil);dest.isFlipped=false;dest.isClamped=false;dest.isDithered=false;dest.alphaMode = .premultiplied;dest.colorSpace=DevelopmentColorEngineV3.linearSRGB
                _=try proof.startTask(toRender:graph.image,from:CGRect(x:0,y:y,width:w,height:rows),to:dest,at:.zero).waitUntilCompleted();try check()
                guard let c=q.makeCommandBuffer(),let blit=c.makeBlitCommandEncoder() else{throw DevelopmentError.invalidEncoding}
                blit.copy(from:native,sourceSlice:0,sourceLevel:0,sourceOrigin:.init(x:0,y:y,z:0),sourceSize:.init(width:w,height:rows,depth:1),to:actualBand,destinationSlice:0,destinationLevel:0,destinationOrigin:.init(x:0,y:0,z:0));blit.endEncoding();try compare(c,ref,actualBand,counts,w,rows)
                var params=Array<UInt32>(repeating:0,count:16);params[0]=UInt32(w);params[1]=UInt32(h);params[2]=UInt32(y);params[3]=UInt32(rows)
                try dispatch(c,sample,[ref,stockHalf],w/2,rows/2){e in params.withUnsafeBytes{e.setBytes($0.baseAddress!,length:64,index:0)}}
                let ai=dev.makeBuffer(length:1024,options:.storageModeShared)!;let checkBlit=c.makeBlitCommandEncoder()!;for (idx,tex) in [ref,actualBand].enumerated(){checkBlit.copy(from:tex,sourceSlice:0,sourceLevel:0,sourceOrigin:.init(x:0,y:0,z:0),sourceSize:.init(width:1,height:1,depth:1),to:ai,destinationOffset:256*idx,destinationBytesPerRow:256,destinationBytesPerImage:256)};checkBlit.endEncoding()
                let prev=counts.contents().assumingMemoryBound(to:UInt32.self)[1];try drain(c);proof.clearCaches();let now=counts.contents().assumingMemoryBound(to:UInt32.self)[1];if now != prev{bandReports.append(["y":y,"changed":now-prev,"refF32":Array(UnsafeBufferPointer(start:ai.contents().assumingMemoryBound(to:UInt32.self),count:4)),"candidateF32":Array(UnsafeBufferPointer(start:ai.contents().advanced(by:256).assumingMemoryBound(to:UInt32.self),count:4))])}
              }
              let c=q.makeCommandBuffer()!;try compare(c,stockHalf,half,hc,w/2,h/2);try drain(c);line["native"]=stats(counts);line["half"]=stats(hc);line["differingBands"]=bandReports
            }
            results.append(line);let header:[String:Any]=["sourceSHA256":shot.contentSHA256,"runtimeSHA256":assetSeal,"actualPrivateNativeScope":true,"results":results,"peak":try peak()]
            try JSONSerialization.data(withJSONObject:header,options:[.prettyPrinted,.sortedKeys]).write(to:out,options:.atomic)
          }
        }
      }
    }
}

import sys,os,subprocess
from pathlib import Path
z=Path(__file__).resolve().parent; root=z.parents[3]; outputs=root/'output/035-development';old=outputs/'phase-z/radial-port'
main=Path('/Users/robinqu/Workspace/github/robinqu/RAWMaster')
dest=z/sys.argv[1];dest.mkdir(parents=True,exist_ok=True)
for role in sys.argv[2].split(','):
 raw,arc={'primary':('acr-benchmark.ARW','candidate-batch29-cross-backend-enabled/photo-operators-v2.json'),'secondary':('jpeg-batch-sources/02.ARW','fit-pass-study/native-02/release-02-secondary-0.json')}[role]
 env=dict(os.environ,RAWMASTER_FLASHRAW_LIBRARY=str(main/'output/tools/flashraw-target/release/libflashraw_capi.dylib'))
 with (dest/(role+'.log')).open('w') as log:
  subprocess.run([z/'bin/witness',main/'output/performance'/raw,outputs/arc,dest/(role+'.json'),z/'bin/mask-half-trace.dylib',sys.argv[3],sys.argv[4],old],env=env,stdout=log,stderr=log,check=True)

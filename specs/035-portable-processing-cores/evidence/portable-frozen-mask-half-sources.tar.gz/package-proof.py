from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import sys
import tarfile

study=Path(__file__).resolve().parent
base=study.parents[1]
work=base.parents[1]
spec=work/'specs/035-portable-processing-cores'
destination=spec/'evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rawfiles=[study/p for p in ('scope-primary.json','scope-secondary.json','all32/primary.json','all32/secondary.json','faults/primary.json','first/primary.json','diagnosed/primary.json','diagnosed/secondary.json')]
sources={}
curves={'light-mask-exposure','light-mask-highlights','light-mask-shadows','light-mask-whites','light-mask-blacks',
        'light-mask-contrast','color-mask-hue','color-mask-saturation'}
for role in ('primary','secondary'):
    scope=json.loads((study/f'scope-{role}.json').read_bytes())
    data=json.loads((study/'all32'/f'{role}.json').read_bytes())
    rows=data['results']
    assert len(rows)==16 and {s['id'] for s in rows}==curves
    assert all(s['differingBits']==s['invalidOrUnwritten']==0 for s in scope)
    assert all(t['native']['components']==t['native']['nonfinite']==t['half']['components']==t['half']['nonfinite']==t['display']['changedPixels']==0 and not t['differingBands'] and t['actualSHA256']==t['archive'] for t in rows)
    sources[role]={'sourceSHA256':data['sourceSHA256'],'nativeDimensions':rows[0]['nativeSize'],
                'scalarsInOriginalScope':scope[0]['nativeScalars'],'scopeZero':scope[0]['zero'],'scopeOne':scope[0]['one'],'scopeFractional':scope[0]['fractional'],
                'privateMaskAllocationBytes':rows[0]['maskBytes'],'privateHalfAllocationBytes':rows[0]['halfBytes'],
                'hostReservedMaskHalfAndMaxScratchBytes':rows[0]['maskBytes']+rows[0]['halfBytes']+48*1024*1024,
                'states':len(rows),'fullNativePixelsCompared':sum(t['native']['pixels'] for t in rows),
                'fullHalfPixelsCompared':sum(t['half']['pixels'] for t in rows),
                'nativeRGBA32BitDifferences':0,'hardwareHalfRGBA32BitDifferences':0,'displayRGBA8Differences':0,
                'displayFrameSHA256':{f"{t['id']}/{t['state']}":t['archive'] for t in rows}}
errors=json.loads((study/'faults'/'primary.json').read_bytes())
expected={'sourceAsMask':1,'unwrittenOrNaN':3,'withdrawAfterSubmission':5,'wrongNamedPlane':1}
assert len(errors['results'])==2 and all(t['faults']==expected and t['archive']==t['actualSHA256'] for t in errors['results'])
files={p.relative_to(study).as_posix():p for p in rawfiles}
for name in ('FrozenScope.swift','NativeMaskHalfWitness.swift','build-witness.sh','build-scope.sh','run.py','legacy-profile.py','normal-receipt.py','package-proof.py'):
    files[name]=study/name
files['measure.metal']=base/'phase-z/radial-port/measure.metal'
for wire in sorted((base/'phase-z/radial-port/intake').glob('*.json')):
    if wire.name.split('.',1)[0] in ('primary','secondary'):
        files['intake/'+wire.name]=wire
for name in ('Cargo.toml','Cargo.lock','build.rs'):
    files['module/'+name]=study/'module'/name
for sub in ('src','shaders','include','examples'):
    for f in sorted((study/'module'/sub).rglob('*')):
        if f.is_file():files[f.relative_to(study).as_posix()]=f
for name in ('normal.json','legacy/verified.json','host-xctest.log'):
    path=study/name
    if path.is_file():files[name]=path
for path in sorted((study/'legacy').glob('*/preview.json')):files[path.relative_to(study).as_posix()]=path
if (study/'normal.json').is_file():
    for run in json.loads((study/'normal.json').read_bytes())['runs']:
        path=study.parent/'photo-combined-final'/run['file']
        assert sha(path)==run['sha256']
        files['profile/'+path.name]=path
    files['profile/photo-abba.sh']=study.parent/'photo-abba.sh'
    files['profile/profile-settled-photo.swift']=work/'scripts/performance/profile-settled-photo.swift'

metadata={'schemaVersion':1,'scope':'Primary settled 2400 FlashRaw 0.3.1 preview with one whole original frozen radial F32 plane and one nonzero local tone or hue control; default off.',
          'qualification':'Single verified immutable original RGBA16F, opaque native finite proof, default geometry and raw details, EXIF1, two measured landscape extents on Apple M4 Max, 512 MiB CI working target. Exact real graph object and zero-overdraw pass/pixel estimate required before the masked half can be consumed.',
          'nativeShape':'Rust Metal renders the named mask_tone_v3 node on original pixels into one private 256-row RGBA32F texture. In each of four bands it checks native source/covered result, uses hardware normalized linear sampling into the independent RGBA32F half, verifies real workgroup counts and drains the submitted command before retaining the half.',
          'flag':'RAWMASTER_QA_PORTABLE_MASK_HALF_FIT=1','newCABI':['rm_image_metal_mask_half_program_open_v1','rm_image_metal_mask_half_render_v1'],
          'timingScope':'Annotated full-native tracing and standalone scope freeze are correctness runs. Scratch masks may be reused across recipes of equal geometry. The real Swift host generates and reserves its R32F mask for each admitted request; only sealed normal-entry timings are comparable.',
          'witness':'Independent feature-only trace blits each actual Rust native band into a full-size private diagnostic texture. Independent original Core Image RGBAf proof context, native hardware half and full display use every source position. The expensive full intermediate and test symbol are excluded from the shipped library.',
          'negativeControl':'The first primary exposure control reported differences in all four components of one 256-row native band (2,433,024 pixels) and its corresponding half, while its actual final display matched. Replacing the shared diagnostic context with an independent stock proof context and explicitly initializing the baseline texture eliminated the difference on both photos. Those two changes were tested together; the raw first and diagnosed reports are archived.',
          'traceRuntimeSHA256':errors['runtimeSHA256'],'sources':sources,
          'faults':{'twoPrimaryExposureStates':expected,'sameProgramRetryExactDisplays':2},
          'rawChecksums':{p.relative_to(study).as_posix():sha(p) for p in rawfiles}}
for name,key in [('normal.json','normalEntry'),('legacy/verified.json','oldRuntimeFallback')]:
    test=study/name
    if test.is_file():metadata[key]=json.loads(test.read_bytes())
if (study/'host-xctest.log').is_file():metadata['nativeAuthorityXCTestLogSHA256']=sha(study/'host-xctest.log')
sealed=base/'candidate-batch30-native-mask-ring'
runtime=sealed/'RAWMasterImagingTests.xctest/Contents/Resources/ImageEdit_RAWMasterImage.bundle/Contents/Resources/rawmaster-image.runtime'
if runtime.is_file():
    import subprocess
    exported=subprocess.check_output(['nm','-gU',str(runtime)],text=True)
    names=set(line.split()[-1].lstrip('_') for line in exported.splitlines() if line.split())
    assert all(s in names for s in metadata['newCABI']) and 'rm_image_test_mask_half_trace' not in names
    metadata['sealedRuntime']={'package':sealed.name,'imageRuntimeSHA256':sha(runtime),'maskedSymbolsPresent':True,'diagnosticTraceSymbolPresent':False}
production=['Modules/ImageEdit/src/gpu/metal_surface/native_half.rs','Modules/ImageEdit/src/gpu/metal_surface/native_half_main.wgsl','Modules/ImageEdit/src/gpu/metal_surface/native_half_mask.wgsl','Modules/ImageEdit/src/premultiplied_f32.wgsl','Modules/ImageEdit/src/mask_tone_v3.wgsl','Modules/ImageEdit/include/rawmaster_image_metal.h','Modules/ImageEdit/Bridge/ImageEditLoader.c','Modules/ImageEdit/Bridge/include/ImageEditLoader.h','Modules/ImageEdit/Swift/RAWMasterImageKernel.swift','Sources/RAWMasterImaging/PreviewPortableMaskTone.swift','Sources/RAWMasterImaging/PreviewPortableHalfFIT.swift','Sources/RAWMasterImaging/PreviewPortableBasic.swift','Sources/RAWMasterImaging/DevelopmentMaskEngineV3.swift','Sources/RAWMasterImaging/PreviewCanonicalHalfFIT.swift','Sources/RAWMasterImaging/PreviewNativeSource.swift','Sources/RAWMasterImaging/DevelopmentPreviewService.swift','Tests/RAWMasterImagingTests/PreviewPortableHalfFITTests.swift']
metadata['reviewedSources']={p:sha(work/p) for p in production}

readme="""Reproduce from a RAWMaster macOS Release checkout on the measured Apple M4 Max/macOS 27 host. Use the verified original files named by the two source SHA-256 values. The check needs the original Swift/Metal benchmark source, testable Release Swift objects and the project's private FlashRaw runtime.

Extract this archive at output/035-development/phase-ab/radial-half; set RAWMASTER_FLASHRAW_LIBRARY to your matching FlashRaw dylib. Run from the checkout:

    study=output/035-development/phase-ab/radial-half
    mkdir -p "$study/bin" "$study/replay" "$study/replay-faults"
    role=primary  # or secondary, matched to the source SHA below
    cargo build --release --locked --manifest-path "$study/module/Cargo.toml" --features native-half-probe --target-dir "$study/cargo-target"
    cp "$study/cargo-target/release/librawmaster_image.dylib" "$study/bin/mask-half-trace.dylib"
    zsh "$study/build-scope.sh"
    zsh "$study/build-witness.sh"
    "$study/bin/scope" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json new-scope.json
    "$study/bin/witness" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json "$study/replay/$role.json" "$study/bin/mask-half-trace.dylib" correct all "$study"
    "$study/bin/witness" PATH_TO_RAW MATCHING_ORIGINAL_ARCHIVE.json "$study/replay-faults/$role.json" "$study/bin/mask-half-trace.dylib" fault light-mask-exposure "$study"

FrozenScope compares the exact scope result's alpha over each original 256-row tile. Witness reads the complete native source-sized result and hardware half as four UInt32 components, then checks archived whole sRGB8. The independent correct mode multiplies memory by retaining an extra private full native texture. Fault mode uses the actual production entry in the instrumented library. The normal app uses the production-only, uninstrumented runtime. The package includes no source photos, model weights or user library. run.py contains the original lab paths; the explicit commands above can use other locations.
"""
header='portable-frozen-mask-half-sources.tar.gz'
archive=destination/header
with archive.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for name,item in sorted({**files,'README.txt':readme.encode()}.items()):
        content=item if isinstance(item,bytes) else item.read_bytes()
        info=tarfile.TarInfo(name);info.size=len(content);info.mode=0o755 if name.endswith('.sh') else 0o644
        tar.addfile(info,io.BytesIO(content))
metadata['replayArchive']={'path':header,'sha256':sha(archive),'bytes':archive.stat().st_size}
out=destination/'portable-frozen-mask-half.json'
out.write_text(json.dumps(metadata,sort_keys=True,indent=2)+'\n')
print(out,sha(out),archive.stat().st_size)

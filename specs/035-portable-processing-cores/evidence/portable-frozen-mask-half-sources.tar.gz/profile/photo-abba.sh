#!/usr/bin/env bash
set -euo pipefail
base="$PWD/output/035-development"
stage="$base/phase-ab"
main=/Users/robinqu/Workspace/github/robinqu/RAWMaster
results="$stage/$1"
mkdir "$results"
products="$PWD/.build/release"
module_maps="$PWD/.build/out/Intermediates.noindex/GeneratedModuleMaps"
for bundle in RAWMaster_RAWMasterImaging RAWMaster_RAWMasterCore ImageEdit_RAWMasterImage \
    LibraryCatalog_RAWMasterLibrary PhotoExport_RAWMasterPhotoExport; do
  cp -cR "$products/$bundle.bundle" "$results/$bundle.bundle"
done
shasum -a 256 "$products/ImageEdit_RAWMasterImage.bundle/Contents/Resources/rawmaster-image.runtime" > "$results/runtime.sha256"
map_flags=()
for module in CFlashRaw CImageEditABI CLibraryCatalogABI; do
  map_flags+=(-Xcc "-fmodule-map-file=$module_maps/$module.modulemap")
done
objects=()
for module in RAWMasterImaging RAWMasterCore RAWMasterImage RAWMasterLibrary RAWMasterPhotoExport \
    MaskAI CFlashRaw CImageEditABI CLibraryCatalogABI; do
  objects+=("$products/$module.o")
done
swiftc -O -parse-as-library -swift-version 5 -target "$(uname -m)-apple-macos15.0" \
  -I "$products" -I "$PWD/Sources/CSQLite" -I "$PWD/experiments/MaskAI/Sources/CONNXRuntime" \
  "${map_flags[@]}" "$PWD/scripts/performance/profile-settled-photo.swift" "${objects[@]}" \
  -lsqlite3 -lz -framework AVKit -o "$results/profile-settled-photo" > "$results/link.log" 2>&1

export RAWMASTER_FLASHRAW_LIBRARY="$main/output/tools/flashraw-target/release/libflashraw_capi.dylib"
export RAWMASTER_VERIFIED_LOCAL_SOURCE_BINDING=1 RAWMASTER_QA_CANONICAL_STAGE_TIMING=1
export RAWMASTER_QA_PORTABLE_CANONICAL_HALF_FIT=1 RAWMASTER_QA_CANONICAL_HALF_FIT=0 RAWMASTER_QA_CANONICAL_SHARPEN_MEAN=1
export RAWMASTER_QA_PORTABLE_CURVES_PREVIEW=0 RAWMASTER_QA_PORTABLE_BASIC_PREVIEW=0 RAWMASTER_PORTABLE_METAL_PREVIEW=0
export RAWMASTER_QA_NATIVE_DEHAZE_HALF_EROSION=1 RAWMASTER_QA_NATIVE_DEHAZE_RESTORE_PROOF=1
export RAWMASTER_QA_NATIVE_DEHAZE_RESTORE_HALF_FIT=1
export RAWMASTER_QA_CANONICAL_GROUPED_SCALARS=1 RAWMASTER_QA_CANONICAL_GRAIN_MASK_TILES=1
export RAWMASTER_QA_CANONICAL_FULL_VALIDATION_CACHE=1 RAWMASTER_QA_NATIVE_DEHAZE_GROUPED_EROSION=1
export RAWMASTER_CANONICAL_SERIAL_FINITE=0 RAWMASTER_QA_LOCAL_BAND_PAIR_CLEAR=0 RAWMASTER_QA_CANONICAL_LOCAL_MASK_BANDS=0
unset RAWMASTER_MAXIMUM_QA_SCALARS


index=0
for arm in 0 1 1 0; do
  index=$((index + 1))
  for source in primary secondary; do
    if [[ "$source" == primary ]]; then
      raw="$main/output/performance/acr-benchmark.ARW"
      archive="$base/candidate-batch29-cross-backend-enabled/photo-operators-v2.json"
    else
      raw="$main/output/performance/jpeg-batch-sources/02.ARW"
      archive="$base/fit-pass-study/native-02/release-02-secondary-0.json"
    fi
    prefix="$results/$index-$source-$arm"
    RAWMASTER_QA_CANONICAL_CONTEXT_REUSE=1 RAWMASTER_QA_PORTABLE_MASK_HALF_FIT="$arm" RAWMASTER_QA_NATIVE_DEHAZE_RING_EROSION="$arm" python3 scripts/run-performance-command.py --timeout 150 --log "$prefix.log" -- \
      "$results/profile-settled-photo" "$raw" "$archive" "$prefix.json" --all-archived-controls \
      > "$prefix.command.json"
  done
done

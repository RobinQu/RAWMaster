const BASIC_LUMA = vec3<f32>(0.2126, 0.7152, 0.0722);

fn basic_encode(linear: vec3<f32>) -> vec3<f32> {
    let encoded = filter_encode(abs(linear));
    return select(encoded, -encoded, linear < vec3<f32>(0));
}

fn basic_decode(encoded: vec3<f32>) -> vec3<f32> {
    let value = abs(encoded);
    let decoded = select(pow((value + 0.055) / 1.055, vec3<f32>(2.4)), value / 12.92,
                         value <= vec3<f32>(0.04045));
    return select(decoded, -decoded, encoded < vec3<f32>(0));
}

fn basic_contrast(value: f32, amount: f32) -> f32 {
    if value <= 0.0 || value >= 1.0 || amount == 0.0 {
        return value;
    }
    let pivot = 0.55;
    let exponent = exp2(1.3 * amount);
    if value < pivot {
        return pivot * pow(value / pivot, exponent);
    }
    return 1.0 - (1.0 - pivot) * pow((1.0 - value) / (1.0 - pivot), exponent);
}

fn basic_v3(pixel: vec4<f32>, light: vec4<f32>, color: vec4<f32>, mono: vec4<f32>) -> vec4<f32> {
    let flags = u32(color.w);
    if flags == 0u || pixel.a <= 0.0 {
        return pixel;
    }
    var rgb = pixel.rgb / pixel.a;
    let exponent_bits = vec3<u32>(0x7f800000u);
    if any((bitcast<vec3<u32>>(rgb) & exponent_bits) == exponent_bits) {
        return invalid_pixel();
    }
    if (flags & 1u) != 0u {
        let y = dot(rgb, BASIC_LUMA);
        let encoded = basic_encode(vec3<f32>(y)).x;
        let w = clamp(encoded, 0.0, 1.0);
        let tone = basic_contrast(encoded + 0.8 * light.x * w * (1.0 - w), light.y);
        let linear = basic_decode(vec3<f32>(tone)).x;
        if abs(y) > 1e-8 {
            rgb *= linear / y;
        } else {
            rgb += vec3<f32>(linear - y);
        }
        let black = 0.05 * light.z;
        rgb = (rgb - vec3<f32>(black)) / (1.0 - black);
        let white_weight = smoothstep(0.45, 1.0, clamp(basic_encode(vec3<f32>(dot(rgb, BASIC_LUMA))).x, 0.0, 1.0));
        rgb *= 1.0 + 0.35 * light.w * white_weight;
    }
    if (flags & 2u) != 0u {
        var encoded = basic_encode(rgb);
        let y = dot(encoded, BASIC_LUMA);
        let top = max(encoded.r, max(encoded.g, encoded.b));
        let bottom = min(encoded.r, min(encoded.g, encoded.b));
        let saturation = clamp((top - bottom) / max(abs(top), 1e-4), 0.0, 1.0);
        let skin = select(1.0, 0.5, encoded.r > encoded.g && encoded.g > encoded.b);
        let warm = select(0.0, 1.0, encoded.r > encoded.b && encoded.g > encoded.b);
        let blue = max(0.0, encoded.b - max(encoded.r, encoded.g)) * (1.0 - clamp(y, 0.0, 1.0));
        let scale = (1.0 + color.x * (1.0 - 0.391 * warm)) * (1.0 + 1.35 * color.y * (1.0 - saturation) * skin);
        encoded = vec3<f32>(y) + (encoded - vec3<f32>(y)) * scale;
        encoded += blue * (color.x * vec3<f32>(-2.576, -0.364, 0.447) + color.y * vec3<f32>(-1.830, -0.494, -0.142));
        let tint = vec3<f32>(dot(encoded, vec3<f32>(0.0214143, 0.0479051, -0.0105798)) - 0.0019973,
                             0.0, dot(encoded, vec3<f32>(-0.0231834, -0.0894344, -0.0299565)) + 0.0047775);
        rgb = basic_decode(encoded + 2.0 * color.z * tint);
    }
    if (flags & 4u) != 0u {
        let encoded = basic_encode(rgb);
        var gray = dot(encoded, BASIC_LUMA) + mono.x * (0.09 * (encoded.g - encoded.r) + 0.392 * (encoded.g - encoded.b));
        let w = clamp(gray, 0.0, 1.0);
        gray += 0.8 * mono.y * w * (1.0 - w);
        rgb = basic_decode(vec3<f32>(basic_contrast(gray, mono.z)));
    }
    return vec4<f32>(rgb * pixel.a, pixel.a);
}

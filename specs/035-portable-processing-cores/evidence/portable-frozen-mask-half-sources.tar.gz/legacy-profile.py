"""Run the sealed Swift service binary against private copies of two earlier image runtimes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

study = Path(__file__).resolve().parent
base = study.parents[1]
work = base.parents[1]
host = Path(sys.argv[1]).resolve()
output = study / (sys.argv[2] if len(sys.argv) > 2 else 'legacy')
main = Path('/Users/robinqu/Workspace/github/robinqu/RAWMaster')
raw = main/'output/performance/acr-benchmark.ARW'
arc = base/'candidate-batch29-cross-backend-enabled/photo-operators-v2.json'
assert host.is_file() and arc.is_file()
output.mkdir(exist_ok=False)
env = dict(os.environ,
           RAWMASTER_VERIFIED_LOCAL_SOURCE_BINDING='1', RAWMASTER_QA_CANONICAL_STAGE_TIMING='1',
           RAWMASTER_QA_CANONICAL_HALF_FIT='0', RAWMASTER_QA_PORTABLE_MASK_HALF_FIT='1',
           RAWMASTER_QA_PORTABLE_CANONICAL_HALF_FIT='0', RAWMASTER_CANONICAL_SERIAL_FINITE='0',
           RAWMASTER_FLASHRAW_LIBRARY=str(main/'output/tools/flashraw-target/release/libflashraw_capi.dylib'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for tag in ('candidate-batch29-cross-backend', 'candidate-batch19b-source'):
    dest=output/tag
    dest.mkdir()
    shutil.copy2(host, dest/host.name)
    for bundle in sorted(host.parent.glob('*.bundle')):
        if bundle.name!='ImageEdit_RAWMasterImage.bundle':
            (dest/bundle.name).symlink_to(bundle.resolve(),target_is_directory=True)
    runtime_bundle=base/tag/'RAWMasterImagingTests.xctest/Contents/Resources/ImageEdit_RAWMasterImage.bundle'
    subprocess.run(['ditto',str(runtime_bundle),str(dest/runtime_bundle.name)],check=True)
    runtime=dest/runtime_bundle.name/'Contents/Resources/rawmaster-image.runtime'
    symbols=subprocess.check_output(['nm','-gU',str(runtime)],text=True)
    assert '_rm_image_metal_mask_half_program_open_v1' not in symbols
    args=[str(dest/host.name),str(raw),str(arc),str(dest/'preview.json'),'color-mask-hue','light-mask-exposure']
    with (dest/'run.log').open('w') as log: subprocess.run(args,env=env,stdout=log,stderr=log,check=True)
    report=json.loads((dest/'preview.json').read_bytes())
    assert report['sourceSHA256']==report['sourceSHA256After'] and report['verified'] and report['binarySHA256']==sha(host)
    samples=[s for op in report['operations'] for s in op['samples'] if s['quality']=='settled']
    assert len(samples)==4 and all(not s['approximate'] for s in samples)
    assert all(not any(e['operation']=='PreviewPortableMaskHalfFIT' for e in s['stages']) for s in samples)
    assert all(any(e['operation']=='显影有限值检查' for e in s['stages']) for s in samples)
    results.append(dict(tag=tag,hostSHA256=sha(host),runtimeSHA256=sha(runtime),
                        symbolPresent=False,settledArchiveMatches=len(samples),finiteChecks=True,
                        dataSHA256=sha(dest/'preview.json')))
(output/'verified.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print(json.dumps(results))

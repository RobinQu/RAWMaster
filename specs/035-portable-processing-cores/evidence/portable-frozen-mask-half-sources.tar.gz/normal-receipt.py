"""Check one sealed ABBA normal-entry run, including absence of mask execution in other control families."""
import hashlib
import json
import re
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
ids = {'light-mask-exposure', 'light-mask-highlights', 'light-mask-shadows',
       'light-mask-whites', 'light-mask-blacks', 'light-mask-contrast', 'color-mask-hue', 'color-mask-saturation'}
sources={}
runs=[]
digests={}
frame_digests={}
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for p in sorted(root.glob('*.json')):
    m = re.fullmatch(r'([1-4])-(primary|secondary)-([01])', p.stem)
    if not m: continue
    ix,role,arm=m.groups()
    assert int(arm)==(0,1,1,0)[int(ix)-1]
    data=json.loads(p.read_bytes())
    assert data['verified'] and data['sourceSHA256']==data['sourceSHA256After']
    assert len(data['operations'])==37
    # Every archived operation has two states, each with interactive and settled requests.
    src=sources.setdefault(role,{'rows':{},'footprintBytes':{'0':[],'1':[]},'sourceSHA256':data['sourceSHA256']})
    src['footprintBytes'][arm].append(data['processPeakPhysicalFootprintBytes'])
    targets=0
    hits=0
    for op in data['operations']:
        assert len(op['samples'])==4
        for s in op['samples']:
            mask=[e for e in s['stages'] if e['operation']=='PreviewPortableMaskHalfFIT']
            key=(role,op['id'],s['state'],s['quality'])
            assert frame_digests.setdefault(key,(s['digest'],s['approximate']))==(s['digest'],s['approximate']), (p,key)
            targeted=s['quality']=='settled' and op['id'] in ids
            if targeted and int(arm):
                assert len(mask)==1 and mask[0]['outcome']=='成功' and mask[0]['boundary']=='GPU 完成'
                assert mask[0]['pixels']==int(data['sourceSize'][0]*data['sourceSize'][1])//4
                hits+=1
            else: assert not mask, (p,op['id'],s['quality'])
            if s['quality']=='settled':
                assert not s['approximate']
                key=(role,op['id'],s['state'])
                assert digests.setdefault(key,s['digest'])==s['digest']
            if targeted:
                targets+=1
                line=src['rows'].setdefault(f"{op['id']}/{s['state']}",{'sha256':s['digest'],'ms':{'0':[],'1':[]},'maskGpuBoundaryMS':[]})
                line['ms'][arm].append(s['ms'])
                line['maskGpuBoundaryMS'].extend(e['ms'] for e in mask)
    assert targets==16 and hits==(16 if int(arm) else 0)
    runs.append(dict(file=p.name,sha256=sha(p),binarySHA256=data['binarySHA256'],settledStates=74,
                     approximateFrames=sum(s['approximate'] for o in data['operations'] for s in o['samples']),
                     hits=hits,processPeak=data['processPeakPhysicalFootprintBytes']))
assert len(runs)==8 and len({r['binarySHA256'] for r in runs})==1 and len(digests)==148 and len(frame_digests)==296
def quant(a):
    z=sorted(a)
    return {'p50':statistics.median(z),'p95NearestRank':z[(len(z)*95+99)//100-1],'minimum':z[0],'maximum':z[-1]}
for src in sources.values():
    assert len(src['rows'])==16
    sw={a:[v for row in src['rows'].values() for v in row['ms'][a]] for a in ('0','1')}
    assert len(sw['0'])==len(sw['1'])==32
    src['settledTimingMS']={arm:quant(values) for arm,values in sw.items()}
result={'method':'sealed normal editing service, sequential A/B/B/A, 37 pairs on each of two photos; mask-only execution verified', 'runs':runs,'sources':sources,
        'allInteractiveAndSettledObservations':1184,'uniqueSourceControlStateQualityPairs':296,'settledArchiveMatches':592,'eligibleSettledCalls':128,'maskOnCalls':64,
        'controlNote':'The ring and mask flags toggle together; per-event intersections were checked. Whole-process peak can contain other operators.'}
out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v['settledTimingMS'] for k,v in sources.items()},indent=2))

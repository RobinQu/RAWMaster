#include <metal_stdlib>
using namespace metal;

uint hash_value(uint n) {
    n ^= n >> 16;
    n *= 0x7feb352du;
    n ^= n >> 15;
    n *= 0x846ca68bu;
    return n ^ (n >> 16);
}

float value(uint n) {
    return float(hash_value(n) >> 9) * 0x1p-23f * 3.2f - 0.25f;
}

kernel void input(texture2d<float, access::write> colors [[texture(0)]],
                  texture2d<float, access::write> phases [[texture(1)]],
                  constant uint& spread [[buffer(0)]],
                  uint2 p [[thread_position_in_grid]]) {
    const uint i = p.y * colors.get_width() + p.x;
    float3 rgb = float3(value(3 * i), value(3 * i + 1), value(3 * i + 2));
    if (spread != 0) {
        const uint3 k = uint3(hash_value(3 * i), hash_value(3 * i + 1), hash_value(3 * i + 2));
        rgb = as_type<float3>((k & 0x807fffff) | ((112u + ((k >> 23u) % 26u)) << 23u));
    }
    colors.write(float4(rgb, 1), p);
    phases.write(float4(p.x % 2, p.y % 2, 0, 1), p);
}

float4 lerp_delta(float4 a, float4 b, float f) { return fma(float4(f), b - a, a); }
float4 lerp_weight(float4 a, float4 b, float f) { return fma(float4(f), b, (1 - f) * a); }
float4 lerp_complement(float4 a, float4 b, float f) { return fma(float4(1 - f), a, f * b); }
float4 lerp_sum(float4 a, float4 b, float f) { return a * (1 - f) + b * f; }
float4 lerp_split(float4 a, float4 b, float f) { return a + f * (b - a); }

struct PairSum { float4 hi, lo; };

PairSum sum_exact(float4 a, float4 b) {
    const float4 s = a + b;
    const float4 tail = s - a;
    return {s, (a - (s - tail)) + (b - tail)};
}

PairSum average_precise(float4 a, float4 b, float4 c, float4 d) {
    const PairSum left = sum_exact(a, b), right = sum_exact(c, d);
    const PairSum total = sum_exact(left.hi, right.hi);
    return sum_exact(total.hi, left.lo + right.lo + total.lo);
}

float4 cast_average(PairSum sum) {
    const uint4 bits = as_type<uint4>(sum.hi);
    const float4 neighbor = as_type<float4>(bits + 1u);
    const bool4 towardAway = (sum.lo > 0.0f) == (sum.hi > 0.0f);
    const bool4 exactlyHalf = abs(sum.lo) == 0.5f * abs(neighbor - sum.hi);
    return select(sum.hi, neighbor, towardAway && exactlyHalf) * 0.25f;
}

struct Witness { float4 fields[23]; };

kernel void measure(texture2d<float, access::sample> colors [[texture(0)]],
                    texture2d<float, access::sample> phases [[texture(1)]],
                    device Witness* report [[buffer(0)]],
                    uint2 lane [[thread_position_in_grid]]) {
    constexpr sampler nativeSampler(coord::normalized, address::clamp_to_edge, filter::linear);
    const uint width = colors.get_width(), height = colors.get_height();
    const uint2 p = 2 * uint2(lane.x, (lane.y * 37) % (height / 2));
    const float2 uv = float2(p + uint2(1)) / float2(width, height);
    const float2 exact = phases.sample(nativeSampler, uv, level(0)).rg;
    const float4 a = colors.read(p), b = colors.read(p + uint2(1, 0));
    const float4 c = colors.read(p + uint2(0, 1)), d = colors.read(p + uint2(1, 1));
    device Witness& w = report[lane.y * (width / 2) + lane.x];
    w.fields[0] = colors.sample(nativeSampler, uv, level(0));
    w.fields[1] = float4(exact, uv);
    w.fields[2] = 0.5f * (0.5f * (a + b) + 0.5f * (c + d));
    w.fields[3] = 0.5f * (0.5f * (a + c) + 0.5f * (b + d));
    w.fields[4] = lerp_delta(lerp_delta(a,b,exact.x), lerp_delta(c,d,exact.x), exact.y);
    w.fields[5] = lerp_delta(lerp_delta(a,c,exact.y), lerp_delta(b,d,exact.y), exact.x);
    w.fields[6] = lerp_weight(lerp_weight(a,b,exact.x), lerp_weight(c,d,exact.x), exact.y);
    w.fields[7] = lerp_weight(lerp_weight(a,c,exact.y), lerp_weight(b,d,exact.y), exact.x);
    w.fields[8] = lerp_complement(lerp_complement(a,b,exact.x), lerp_complement(c,d,exact.x), exact.y);
    w.fields[9] = lerp_complement(lerp_complement(a,c,exact.y), lerp_complement(b,d,exact.y), exact.x);
    w.fields[10] = lerp_sum(lerp_sum(a,b,exact.x), lerp_sum(c,d,exact.x), exact.y);
    w.fields[11] = lerp_sum(lerp_sum(a,c,exact.y), lerp_sum(b,d,exact.y), exact.x);
    w.fields[12] = lerp_split(lerp_split(a,b,exact.x), lerp_split(c,d,exact.x), exact.y);
    w.fields[13] = lerp_split(lerp_split(a,c,exact.y), lerp_split(b,d,exact.y), exact.x);
    w.fields[14] = (a + b + c + d) * 0.25f;
    w.fields[15] = float4(fma(uv, float2(width,height), -float2(p) - 0.5f),
                          uv * float2(width,height) - float2(p) - 0.5f);
    w.fields[16] = mix(mix(a,b,exact.x), mix(c,d,exact.x), exact.y);
    w.fields[17] = a; w.fields[18] = b; w.fields[19] = c; w.fields[20] = d;
    const PairSum sum = average_precise(a, b, c, d);
    w.fields[21] = sum.hi * 0.25f;
    w.fields[22] = cast_average(sum);
}

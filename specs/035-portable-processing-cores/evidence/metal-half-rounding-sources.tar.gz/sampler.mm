#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <algorithm>
#include <cmath>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static uint32_t bits(float value) {
    uint32_t raw; memcpy(&raw, &value, 4); return raw;
}

int main(int argc, char** argv) {
    @autoreleasepool {
        if (argc != 5 && argc != 6) return 1;
        const unsigned int spread = argc == 6;
        const NSUInteger width = static_cast<NSUInteger>(atoi(argv[2]));
        const NSUInteger height = static_cast<NSUInteger>(atoi(argv[3]));
        if (width % 2 || height % 2 || width < 2 || height < 2) return 2;
        const NSUInteger rows = 16, stride = 23 * 4, count = width / 2 * rows;
        NSError* error = nil;
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        id<MTLCommandQueue> queue = [device newCommandQueue];
        NSString* path = [NSString stringWithUTF8String:argv[1]];
        NSString* source = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
        if (!source) { fprintf(stderr,"%s\n",error.localizedDescription.UTF8String); return 3; }
        MTLCompileOptions* opts = [MTLCompileOptions new];
        opts.mathMode = strcmp(argv[4], "fast") == 0 ? MTLMathModeFast : MTLMathModeSafe;
        opts.mathFloatingPointFunctions = MTLMathFloatingPointFunctionsPrecise;
        id<MTLLibrary> lib = [device newLibraryWithSource:source options:opts error:&error];
        if (!lib) { fprintf(stderr,"%s\n",error.localizedDescription.UTF8String); return 4; }
        id<MTLComputePipelineState> initializer = [device newComputePipelineStateWithFunction:[lib newFunctionWithName:@"input"] error:&error];
        id<MTLComputePipelineState> witness = [device newComputePipelineStateWithFunction:[lib newFunctionWithName:@"measure"] error:&error];
        if (!initializer || !witness) { fprintf(stderr,"%s\n",error.localizedDescription.UTF8String); return 5; }
        MTLTextureDescriptor* td = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA32Float width:width height:height mipmapped:NO];
        td.storageMode = MTLStorageModePrivate; td.usage = MTLTextureUsageShaderRead | MTLTextureUsageShaderWrite;
        id<MTLTexture> rgb = [device newTextureWithDescriptor:td], phase = [device newTextureWithDescriptor:td];
        id<MTLBuffer> results = [device newBufferWithLength:count * stride * sizeof(float) options:MTLResourceStorageModeShared];
        if (!rgb || !phase || !results) return 6;
        id<MTLCommandBuffer> cmd = [queue commandBuffer];
        void (^dispatch)(id<MTLComputePipelineState>, NSUInteger, NSUInteger, BOOL) =
            ^(id<MTLComputePipelineState> pipeline, NSUInteger w, NSUInteger h, BOOL out) {
              id<MTLComputeCommandEncoder> encoder = [cmd computeCommandEncoder];
              [encoder setComputePipelineState:pipeline];
              [encoder setTexture:rgb atIndex:0]; [encoder setTexture:phase atIndex:1];
              if (out) [encoder setBuffer:results offset:0 atIndex:0];
              else [encoder setBytes:&spread length:sizeof(spread) atIndex:0];
              [encoder dispatchThreads:MTLSizeMake(w,h,1) threadsPerThreadgroup:MTLSizeMake(8,8,1)];
              [encoder endEncoding];
            };
        dispatch(initializer,width,height,NO); dispatch(witness,width/2,rows,YES);
        [cmd commit]; [cmd waitUntilCompleted];
        if (cmd.status != MTLCommandBufferStatusCompleted) { fprintf(stderr,"%s\n",cmd.error.localizedDescription.UTF8String); return 7; }
        const float* raw = static_cast<const float*>(results.contents);
        unsigned int different[17] = {}, phaseDiff[4] = {}, wideDiff[4] = {}, aboveWide = 0, belowWide = 0, beyondTies = 0;
        float phaseMin[2] = {1, 1}, phaseMax[2] = {0, 0};
        float maxDelta[17] = {};
        for (NSUInteger i=0; i<count; ++i) {
            const float* r = raw+i*stride;
            for (int ch=0; ch<2; ++ch) {
                phaseMin[ch] = std::min(phaseMin[ch], r[4+ch]);
                phaseMax[ch] = std::max(phaseMax[ch], r[4+ch]);
                phaseDiff[ch] += bits(r[4+ch]) != bits(r[4*15+ch]);
                phaseDiff[2+ch] += bits(r[4+ch]) != bits(r[4*15+2+ch]);
            }
            for (int mode=2; mode<17; ++mode) {
                if (mode==15) continue;
                for (int ch=0; ch<3; ++ch) {
                    different[mode] += bits(r[ch]) != bits(r[4*mode+ch]);
                    maxDelta[mode] = std::max(maxDelta[mode], fabsf(r[ch] - r[4*mode+ch]));
                }
            }
            for (int ch=0; ch<3; ++ch) {
                const double exact = 0.25 * (double(r[17*4+ch]) + r[18*4+ch] + r[19*4+ch] + r[20*4+ch]);
                const float wide = static_cast<float>(exact);
                const float away = std::nextafter(wide, std::copysign(INFINITY, wide));
                const float reference = fabs(wide) < fabs(exact) && 0.5 * (double(wide) + away) == exact ? away : wide;
                wideDiff[0] += bits(wide) != bits(r[ch]);
                wideDiff[1] += bits(r[21*4+ch]) != bits(r[ch]);
                aboveWide += r[ch] > wide;
                belowWide += r[ch] < wide;
                wideDiff[2] += bits(reference) != bits(r[ch]);
                wideDiff[3] += bits(r[22*4+ch]) != bits(r[ch]);
                if (bits(reference)!=bits(r[ch]) && ++beyondTies <= 5)
                    fprintf(stderr,"above ties: %a %a %a %a, expected %.16a hardware %a\n",
                            r[17*4+ch], r[18*4+ch], r[19*4+ch], r[20*4+ch], exact, r[ch]);
            }
        }
        printf("{\"size\":[%lu,%lu],\"mode\":\"%s\",\"exponentSpread\":%u,\"comparedPixels\":%lu,\"phase\":[[%.9g,%.9g],[%.9g,%.9g]],\"phaseDifferences\":[%u,%u,%u,%u],\"bitDifferences\":[",width,height,argv[4],spread,count,phaseMin[0],phaseMax[0],phaseMin[1],phaseMax[1],phaseDiff[0],phaseDiff[1],phaseDiff[2],phaseDiff[3]);
        for (int mode=0; mode<17; ++mode) printf("%s%u",mode?",":"",different[mode]);
        printf("],\"maxDelta\":[");
        for (int mode=0; mode<17; ++mode) printf("%s%.9g",mode?",":"",maxDelta[mode]);
        printf("],\"wideDifferences\":[%u,%u,%u,%u],\"aboveAndBelowWide\":[%u,%u]}\n",wideDiff[0],wideDiff[1],wideDiff[2],wideDiff[3],aboveWide,belowWide);
    }
}

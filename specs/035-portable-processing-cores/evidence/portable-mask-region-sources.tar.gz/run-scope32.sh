#!/bin/zsh
set -euo pipefail
base="$PWD/output/035-development"
z="$base/phase-ac/radial"
main=/Users/robinqu/Workspace/github/robinqu/RAWMaster
export RAWMASTER_FLASHRAW_LIBRARY="$main/output/tools/flashraw-target/release/libflashraw_capi.dylib"
"$z/bin/scope32" "$main/output/performance/acr-benchmark.ARW" "$base/candidate-batch30-native-mask-ring-final-enabled/photo-operators-v2.json" "$z/scope32/primary.json"
"$z/bin/scope32" "$main/output/performance/jpeg-batch-sources/02.ARW" "$base/fit-pass-study/native-02/release-02-secondary-0.json" "$z/scope32/secondary.json"

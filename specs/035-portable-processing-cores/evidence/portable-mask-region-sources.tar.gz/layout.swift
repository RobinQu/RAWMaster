import Metal
let dev=MTLCreateSystemDefaultDevice()!
let w=9504, h=6336
for (x0,y0,x1,y1) in [(1408,1024,8096,5120),(2240,1792,7168,4608),(2336,1792,7168,4608),(2304,1792,7168,4608),(2336,1792,7136,4608),(0,256,3072,1536)] {
func td(_ w:Int,_ h:Int,_ f:MTLPixelFormat)->MTLTextureDescriptor{let d=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:f,width:w,height:h,mipmapped:false);d.storageMode = .private;d.usage=[.renderTarget,.shaderRead,.shaderWrite];return d}
let c=td(x1-x0,y1-y0,.r32Float),half=td(w/2,h/2,.rgba32Float),b=(w*h-(x1-x0)*(y1-y0))*4
let cs=dev.heapTextureSizeAndAlign(descriptor:c),hs=dev.heapTextureSizeAndAlign(descriptor:half),bs=dev.heapBufferSizeAndAlign(length:b,options:.storageModePrivate)
print(x0,y0,x1,y1,cs.size,hs.size,bs.size,cs.size+hs.size+bs.size+48*1024*1024,cs.size+hs.size+bs.size+48*1024*1024-512*1024*1024)
if let ct=dev.makeTexture(descriptor:c),let ht=dev.makeTexture(descriptor:half),let bm=dev.makeBuffer(length:b,options:.storageModePrivate){print("actual",ct.allocatedSize,ht.allocatedSize,bm.allocatedSize, bm.length, b)}
}

import AppKit
import CoreImage
import CryptoKit
import Darwin
import Foundation
import Metal
import RAWMasterCore
@testable import RAWMasterImaging

@main private enum RadialWitness {
    static func context(_ name: String, queue: MTLCommandQueue? = nil) -> CIContext {
        let options: [CIContextOption: Any] = [
            .name: name, .workingColorSpace: DevelopmentColorEngineV3.linearSRGB,
            .workingFormat: CIFormat.RGBAf.rawValue, .cacheIntermediates: false, .memoryTarget: 512,
        ]
        if let queue { return CIContext(mtlCommandQueue: queue, options: options) }
        return CIContext(options: options)
    }

    static func milliseconds(_ begin: UInt64) -> Double {
        Double(DispatchTime.now().uptimeNanoseconds - begin) / 1e6
    }

    static func peak() throws -> Int64 {
        var info = task_vm_info_data_t()
        var words = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.stride)
        let status = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(words)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &words)
            }
        }
        guard status == KERN_SUCCESS else { throw DevelopmentError.invalidEncoding }
        return info.ledger_phys_footprint_peak
    }

    static func digest(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func raster(_ pixels: PreviewPixels) throws -> Data {
        guard pixels.outputSize == CGSize(width: 2400, height: 1600) else { throw DevelopmentError.invalidEncoding }
        let frame = DevelopmentPreviewFrame(frameID: UUID(), image: pixels.image, sessionID: .init(),
            sourceGeneration: 1, consumerID: .init(), revision: 1, quality: .settled,
            canonicalPixelSize: pixels.nativeSize, outputPixelSize: pixels.outputSize, outputKey: "half-fit-probe", approximate: false)
        var bytes = Data(count: 2400 * 1600 * 4)
        try bytes.withUnsafeMutableBytes { try frame.copyDisplayRGBA8(into: $0) }
        return bytes
    }

    static func diff(_ expected: Data, _ actual: Data) -> [String: Any] {
        precondition(expected.count == actual.count && expected.count == 2400 * 1600 * 4)
        var changedPixels = 0, maxCode = 0, alphaChanges = 0, edgeChanges = 0, sum = 0
        expected.withUnsafeBytes { (left: UnsafeRawBufferPointer) in
            actual.withUnsafeBytes { (right: UnsafeRawBufferPointer) in
                for index in stride(from: 0, to: expected.count, by: 4) {
                    var changed = false
                    for channel in 0..<4 {
                        let error = abs(Int(left[index + channel]) - Int(right[index + channel]))
                        if error > 0 {
                            maxCode = max(maxCode, error)
                            sum += error
                            if channel == 3 { alphaChanges += 1 }
                            changed = true
                        }
                    }
                    if changed {
                        let x = (index / 4) % 2400
                        let y = (index / 4) / 2400
                        if x == 0 || x == 2399 || y == 0 || y == 1599 { edgeChanges += 1 }
                        changedPixels += 1
                    }
                }
            }
        }
        return ["changedPixels": changedPixels, "edgePixels": edgeChanges, "alphaValues": alphaChanges,
                "maxCodeDifference": maxCode, "meanAbsoluteCodeDifference": Double(sum) / Double(expected.count)]
    }

    static func snapshot(_ raw: URL) throws -> EditingSourceSnapshot {
        let hash = try RenderFiles.hash(raw)
        guard let size = try raw.resourceValues(forKeys:[.fileSizeKey]).fileSize else { throw DevelopmentError.unreadable }
        return .init(projectID: "035-curves",assetID: hash,contentSHA256: hash,byteCount: Int64(size),
                     admissionFingerprint: "curves-v3",sourceLocation: raw)
    }


    static let checkShader = """
    #include <metal_stdlib>
    using namespace metal;
    kernel void compareR(texture2d<float,access::read> full [[texture(0)]],texture2d<float,access::read> region [[texture(1)]],
      device atomic_uint* sums [[buffer(0)]], constant uint4& d [[buffer(1)]],constant uint4& box [[buffer(2)]],
      uint2 id [[thread_position_in_grid]],uint lane [[thread_index_in_simdgroup]]) {
      bool active=id.x<d.x && id.y<d.y;
      uint2 p=uint2(id.x,id.y+d.z);
      bool inside=active&&all(p>=box.xy)&&all(p<box.xy+box.zw);
      uint a=active?as_type<uint>(full.read(id).a):0u;
      uint b=inside?as_type<uint>(region.read(p-box.xy).r):0u;
      uint v[8]={uint(active),uint(active&&a!=b),uint(inside&&b>0x3f800000u),uint(active&&!inside&&a!=0u),
                 uint(active&&a>0u&&a<0x3f800000u),uint(inside),uint(active&&a==0u),uint(active&&a==0x3f800000u)};
      for(int i=0;i<8;i++){uint n=simd_sum(v[i]); if(lane==0 && n)atomic_fetch_add_explicit(sums+i,n,memory_order_relaxed);}
    }
    """
    static func main()throws{
      let argv=CommandLine.arguments
      let raw=URL(fileURLWithPath:argv[1]), archive=URL(fileURLWithPath:argv[2]), out=URL(fileURLWithPath:argv[3])
      let shot=try snapshot(raw);let cap=try RenderFiles.verifiedPreviewCapture(shot);defer{try? FileManager.default.removeItem(at:cap.url.deletingLastPathComponent())}
      let check={try cap.requireCurrent(at:cap.url)}
      let uploaded=try FlashRawImageFactory.nativePreviewImage(capture:cap.url,rawDetails:nil,retainNativeTexture:true)
      let w=Int(uploaded.image.extent.width),h=Int(uploaded.image.extent.height)
      let pool=FlashRawCanonicalTexturePool(byteBudget:1024*1024*1024)
      let key=FlashRawCanonicalTextureKey(sourceKey:shot.contentSHA256,captureStamp:cap.stamp,contract:"ab-native-scope",width:w,height:h)
      let pin=try pool.acquireNative(key){uploaded};defer{pin.release()}
      guard try pin.checkOpaqueUpload(pin.image,cancellation:check),let dev=MTLCreateSystemDefaultDevice(),let queue=dev.makeCommandQueue(),
        let pack=try JSONSerialization.jsonObject(with:Data(contentsOf:archive)) as? [String:Any],shot.contentSHA256==pack["sourceSHA256"] as? String,
        let ops=pack["operations"] as? [[String:Any]],let op=ops.first(where:{$0["id"] as? String=="light-mask-exposure"}),
        let desc=(op["stateDescriptions"] as? [[String:Any]])?.first else{throw DevelopmentV3Error.invalidGraph}
      let p=try JSONDecoder().decode(DevelopmentRecipe.self,from:JSONSerialization.data(withJSONObject:desc))
      guard let baseline=p.adjustmentsV3?.masks.first else{throw DevelopmentV3Error.invalidGraph}

      let proof=context("ac-reference-rgba",queue:queue), ci=context("ac-compact-f32",queue:queue)
      defer {proof.clearCaches(); ci.clearCaches()}
      let lib=try dev.makeLibrary(source:checkShader,options:nil)
      let cmp=try dev.makeComputePipelineState(function:lib.makeFunction(name:"compareR")!)
      func make(_ ww:Int,_ hh:Int,_ format:MTLPixelFormat)throws->MTLTexture {
        let d=MTLTextureDescriptor.texture2DDescriptor(pixelFormat:format,width:ww,height:hh,mipmapped:false)
        d.storageMode = .private;d.usage=[.renderTarget,.shaderRead,.shaderWrite]
        guard let t=dev.makeTexture(descriptor:d) else { throw DevelopmentError.invalidEncoding };return t
      }
      func drain(_ c:MTLCommandBuffer)throws {c.commit();c.waitUntilCompleted();guard c.status == .completed else{throw DevelopmentError.invalidEncoding};try check()}
      func clear(_ t:MTLTexture)throws {
        let pass=MTLRenderPassDescriptor();pass.colorAttachments[0].texture=t;pass.colorAttachments[0].loadAction = .clear;pass.colorAttachments[0].storeAction = .store
        pass.colorAttachments[0].clearColor=MTLClearColorMake(.nan,.nan,.nan,.nan)
        guard let c=queue.makeCommandBuffer(),let e=c.makeRenderCommandEncoder(descriptor:pass) else{throw DevelopmentError.invalidEncoding};e.endEncoding();try drain(c)
      }
      func render(_ engine:CIContext,_ image:CIImage,_ tex:MTLTexture,_ r:CGRect)throws{
        let d=CIRenderDestination(mtlTexture:tex,commandBuffer:nil);d.isFlipped=false;d.isClamped=false;d.isDithered=false;d.alphaMode = .premultiplied;d.colorSpace=DevelopmentColorEngineV3.linearSRGB
        _=try engine.startTask(toRender:image,from:r,to:d,at:.zero).waitUntilCompleted();try check()
      }
      var geometries=[("archive",baseline)]
      for (name,cx,cy,rx,ry) in [("bottom-right",0.993,0.991,0.135,0.062),("top-left",0.005,0.002,0.087,0.151),("small",0.375001,0.50001,0.001,0.001),("inside-offcenter",0.712345,0.301415,0.117,0.165)] {
        var v=baseline;v.center = .init(x:cx,y:cy);v.radiusX=rx;v.radiusY=ry;geometries.append((name,v))
      }
      let full=try make(w,256,.rgba32Float)
      var reports=[[String:Any]]()
      for (name,layer) in geometries {
        try autoreleasepool{
          let scope=DevelopmentMaskEngineV3.ScopeSelection(layer);try scope.capture(pin.image)
          guard let coverage=scope.coverage,let rawSupport=DevelopmentMaskEngineV3.CanonicalValidation.pointwiseSupport(layer,extent:pin.image.extent) else{throw DevelopmentError.invalidEncoding}
          let x0=16*(Int(rawSupport.minX)/16),y0=256*(Int(rawSupport.minY)/256)
          let x1=min(w,16*((Int(rawSupport.maxX)+15)/16)),y1=min(h,256*((Int(rawSupport.maxY)+255)/256))
          let roi=CGRect(x:x0,y:y0,width:x1-x0,height:y1-y0)
          let compact=try make(x1-x0,y1-y0,.r32Float);try clear(compact)
          let begin=DispatchTime.now().uptimeNanoseconds;try render(ci,coverage,compact,roi);let ms=milliseconds(begin)
          guard let buf=dev.makeBuffer(length:32,options:.storageModeShared) else{throw DevelopmentError.invalidEncoding}
          memset(buf.contents(),0,32)
          for y in stride(from:0,to:h,by:256) {
            let rows=min(256,h-y);try clear(full);try render(proof,coverage,full,CGRect(x:0,y:y,width:w,height:rows))
            guard let c=queue.makeCommandBuffer(),let e=c.makeComputeCommandEncoder() else{throw DevelopmentError.invalidEncoding}
            e.setComputePipelineState(cmp);e.setTexture(full,index:0);e.setTexture(compact,index:1);e.setBuffer(buf,offset:0,index:0)
            var dims=SIMD4<UInt32>(UInt32(w),UInt32(rows),UInt32(y),0),box=SIMD4<UInt32>(UInt32(x0),UInt32(y0),UInt32(x1-x0),UInt32(y1-y0))
            e.setBytes(&dims,length:16,index:1);e.setBytes(&box,length:16,index:2)
            e.dispatchThreads(.init(width:w,height:rows,depth:1),threadsPerThreadgroup:.init(width:16,height:16,depth:1));e.endEncoding();try drain(c)
          }
          let v=buf.contents().bindMemory(to:UInt32.self,capacity:8)
          guard v[0]==UInt32(w*h),v[5]==UInt32((x1-x0)*(y1-y0)),v[0]==v[4]+v[6]+v[7] else{throw DevelopmentError.invalidEncoding}
          reports.append(["geometry":name,"inputSHA256":shot.contentSHA256,"native":[w,h],"rect":[x0,y0,x1-x0,y1-y0],"coverScalars":v[0],"inside":v[5],"outsideNonzero":v[3],"different":v[1],"invalidOrMissed":v[2],"fractional":v[4],"zeros":v[6],"ones":v[7],"allocated":compact.allocatedSize,"firstFreezeMs":ms])
          try JSONSerialization.data(withJSONObject:reports,options:[.prettyPrinted,.sortedKeys]).write(to:out,options:.atomic)
        }
      }
    }
}

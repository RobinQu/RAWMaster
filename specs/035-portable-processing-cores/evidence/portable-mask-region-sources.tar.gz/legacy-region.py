"""Run the same released NativeSource service against authenticated older image ABI bundles."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
z=Path(__file__).resolve().parent;base=z.parents[1];host=Path(sys.argv[1]).resolve();out=z/'legacy'
main=Path(os.environ.get('RAWMASTER_MAIN_WORKTREE','/Users/robinqu/Workspace/github/robinqu/RAWMaster'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
src=main/'output/performance/acr-benchmark.ARW'
arc=base/'candidate-batch29-cross-backend-enabled/photo-operators-v2.json'
ev=dict(os.environ, RAWMASTER_QA_CANONICAL_STAGE_TIMING='1',RAWMASTER_QA_PORTABLE_MASK_REGION_HALF_FIT='1',
 RAWMASTER_QA_PORTABLE_GRADING_HALF_FIT='1',RAWMASTER_QA_PORTABLE_MASK_HALF_FIT='1',RAWMASTER_QA_CANONICAL_HALF_FIT='0',RAWMASTER_QA_PORTABLE_CANONICAL_HALF_FIT='0',
 RAWMASTER_FLASHRAW_LIBRARY=str(main/'output/tools/flashraw-target/release/libflashraw_capi.dylib'))
out.mkdir(exist_ok=True);rows=[]
for tag,old_mask in [('candidate-batch30-native-mask-ring',True),('candidate-batch19b-source',False)]:
 p=out/tag;p.mkdir(exist_ok=False);shutil.copy2(host,p/host.name)
 for b in host.parent.glob('*.bundle'):
  if b.name!='ImageEdit_RAWMasterImage.bundle':(p/b.name).symlink_to(b.resolve(),target_is_directory=True)
 bundle=base/tag/'RAWMasterImagingTests.xctest/Contents/Resources/ImageEdit_RAWMasterImage.bundle'
 subprocess.run(['ditto',bundle,p/bundle.name],check=True);runtime=p/bundle.name/'Contents/Resources/rawmaster-image.runtime'
 symbols=subprocess.check_output(['nm','-gU',runtime],text=True)
 assert '_rm_image_metal_mask_region_program_open_v1' not in symbols and ('_rm_image_metal_mask_half_program_open_v1' in symbols)==old_mask
 with (p/'run.log').open('w') as log:
  subprocess.run([p/host.name,src,arc,p/'preview.json','color-mask-hue','light-mask-exposure','grading-balance','grading-blending'],env=ev,stdout=log,stderr=log,check=True)
 result=json.loads((p/'preview.json').read_bytes());ss=[s for op in result['operations'] for s in op['samples'] if s['quality']=='settled']
 assert result['verified'] and result['sourceSHA256']==result['sourceSHA256After'] and result['binarySHA256']==sha(host)
 assert len(ss)==8 and len(result['operations'])==4
 assert all(not s['approximate'] and not any(ev['operation'].startswith('PreviewPortableMask') or ev['operation']=='PreviewPortableGradingHalfFIT' and ev.get('outcome') in ('成功','succeeded') for ev in s['stages']) for s in ss)
 mask=[s for op in result['operations'] if 'mask' in op['id'] for s in op['samples'] if s['quality']=='settled']
 assert len(mask)==4 and all(any(ev['operation']=='显影有限值检查' for ev in s['stages']) for s in mask)
 rows.append(dict(release=tag,source=result['sourceSHA256'],hostSHA256=sha(host),runtimeSHA256=sha(runtime),fullMaskCapability=old_mask,
                  compactMaskCapability=False,settledArchiveMatches=len(ss),maskSettled=4,gradingSettled=4,maskStockFiniteChecks=True,receiptSHA256=sha(p/'preview.json')))
(out/'verified.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')

import os,subprocess,sys
from pathlib import Path
z=Path(__file__).resolve().parent;base=z.parents[1];root=base.parents[1];old=base/'phase-z/radial-port'
main=Path('/Users/robinqu/Workspace/github/robinqu/RAWMaster');dest=z/sys.argv[1];dest.mkdir(exist_ok=True)
for role in sys.argv[2].split(','):
 raw,arc={'primary':('acr-benchmark.ARW','candidate-batch30-native-mask-ring-final-enabled/photo-operators-v2.json'),'secondary':('jpeg-batch-sources/02.ARW','fit-pass-study/native-02/release-02-secondary-0.json')}[role]
 env=dict(os.environ,RAWMASTER_FLASHRAW_LIBRARY=str(main/'output/tools/flashraw-target/release/libflashraw_capi.dylib'))
 with (dest/(role+'.log')).open('w') as log:
  subprocess.run([z/'bin/witness',main/'output/performance'/raw,base/arc,dest/(role+'.json'),z/'bin/region-trace.dylib',sys.argv[3],sys.argv[4],old],env=env,stdout=log,stderr=log,check=True)

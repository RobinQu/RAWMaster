from pathlib import Path
z=Path(__file__).resolve().parent
orig=z.parents[1]/'phase-ab/radial-half/module/src/gpu/metal_surface'
out=z/'module/src/gpu/metal_surface'
s=(orig/'native_half.rs').read_text()
def replace(a,b,n=1):
 global s
 assert s.count(a)>=n,(a[:60],s.count(a))
 s=s.replace(a,b,n)
replace('            let m = textureLoad(frozen_mask,p,0).r;', '''            let rect=vec4<u32>(params.rows[9]); var m=0.0;
            if all(p>=rect.xy) && all(p < rect.xy+rect.zw) { m=textureLoad(frozen_mask,p-rect.xy,0).r; }''')
replace('code.push_str(&include_str!("native_half_main.wgsl").replace("half_point_graph(source)", "half_point_graph(source, p)"));','code.push_str(include_str!("native_half_region.wgsl"));')
replace('        debug_native: Option<&metal::TextureRef>,','        debug_native: Option<&metal::TextureRef>,\n        area: Option<[u32;5]>,')
replace('        let device = self.gpu.metal_device().map_err(|_| 2)?;\n        if let Some(mask) = coverage {','''        let device = self.gpu.metal_device().map_err(|_| 2)?;
        let iw=input.width() as u32;let ih=input.height() as u32;
        let [x0,y0,rw,rh,hot]=area.unwrap_or([0,0,iw,ih,0]);
        if rw==0 || rh==0 || hot>1 || x0%16!=0 || y0%BAND!=0 || rw%2!=0 || rh%2!=0 ||
           x0>iw || rw>iw-x0 || y0>ih || rh>ih-y0 || (y0+rh!=ih && rh%BAND!=0) { return Err(1); }
        if let Some(mask)=coverage {''')
replace('mask.width() != input.width() || mask.height() != input.height()', 'mask.width() != u64::from(rw) || mask.height() != u64::from(rh)')
replace('        let mut parameters = parameter_bytes(plan, width, height);','''        let mut parameters = parameter_bytes(plan, width, height);
        if coverage.is_some() {
            for component in [x0,y0,rw,rh,hot,0,0,0] { parameters.extend_from_slice(&(component as f32).to_ne_bytes()); }
        }
        let first_band = if hot==1 { (y0/BAND) as usize } else { 0 };
        let after_band = if hot==1 { (y0+rh).div_ceil(BAND) as usize } else { band_count };
        let active_width=if hot==1 {rw} else {width};
        let start_x=if hot==1 {x0} else {0};''')
replace('receipts[band % depth]', 'receipts[(band + depth - first_band % depth) % depth]')
replace('for first in (0..band_count).step_by(depth) {\n            let last = (first + depth).min(band_count);','for first in (first_band..after_band).step_by(depth) {\n            let last = (first + depth).min(after_band);')
start=s.index('for first in (first_band..after_band)');end=s.index('        if current() {',start);part=s[start:end]
part=part.replace('groups(width','groups(active_width').replace(', width, rows',', active_width, rows').replace(', width / 2, rows / 2',', active_width / 2, rows / 2')
part=part.replace('encoder.copy_texture_to_texture(tile.as_image_copy(),', 'let mut copy=tile.as_image_copy(); copy.origin.x=start_x;encoder.copy_texture_to_texture(copy,')
part=part.replace('Origin3d{x:0,y:index','Origin3d{x:start_x,y:index').replace('Extent3d{width,height:rows','Extent3d{width:active_width,height:rows')
s=s[:start]+part+s[end:]
replace('                None, None,\n', '                None, None, None,\n')
replace('half: *mut c_void, trace: *mut c_void,\n    revision:', 'half: *mut c_void, trace: *mut c_void, area: Option<[u32;5]>,\n    revision:')
replace('coverage.cast())),debug,|| check(context,revision)', 'coverage.cast())),debug,area,|| check(context,revision)')
replace('half,ptr::null_mut(),rev,current,context)', 'half,ptr::null_mut(),None,rev,current,context)')
replace('half,trace,rev,current,context)', 'half,trace,None,rev,current,context)')
s+='''
#[cfg(feature="native-half-probe")]
#[no_mangle]
pub unsafe extern "C" fn rm_image_test_mask_region_half(
    program:*const HalfProgram, recipe:*const ImagePlan, source:*mut c_void, name:*const u8, n:usize,
    mask:*mut c_void, half:*mut c_void, debug:*mut c_void, region:*const [u32;5], rev:u64,
    current:Option<Current>, ctx:*mut c_void) -> i32 {
    let Some(area)=region.as_ref() else{return 1};
    mask_render(program,recipe,source,name,n,mask,half,debug,Some(*area),rev,current,ctx)
}
'''
(out/'native_half.rs').write_text(s)
g=(orig/'native_half_main.wgsl').read_text().replace('half_point_graph(source)', 'half_point_graph(source,p)')
g=g.replace('let value = native_point(id.xy + vec2<u32>(0u,params.band_y));\n        textureStore(half_target,id.xy,value);','''let x0=select(0u,u32(params.rows[9].x),params.rows[10].x==1.0);
        let physical=id.xy+vec2<u32>(x0,0u);
        let value=native_point(physical+vec2<u32>(0u,params.band_y));textureStore(half_target,physical,value);''')
start=g.index('fn sampled_half(');part=g[start:]
part=part.replace('let rows=min(256u,params.size.y-params.band_y);', '''let rows=min(256u,params.size.y-params.band_y);
    let warm=params.rows[10].x==1.0; let rw=select(params.size.x,u32(params.rows[9].z),warm);
    let x0=select(0u,u32(params.rows[9].x),warm);''')
part=part.replace('id.x < params.size.x/2u','id.x < rw/2u').replace('let p=2u*id.xy;','let p=2u*id.xy+vec2<u32>(x0,0u);').replace('vec2<u32>(0u,params.band_y/2u)','vec2<u32>(x0/2u,params.band_y/2u)').replace('((params.size.x+7u)/8u)','((rw+7u)/8u)')
g=g[:start]+part
# Native width is rounded to 16 for interior domains. Last right edge is always the exact even native width.
(out/'native_half_region.wgsl').write_text(g)

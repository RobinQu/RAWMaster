"""Recheck actual optical pixels, all absolute coverage values, exterior privacy and owner transitions."""
import gzip,hashlib,io,json,re,statistics,tarfile
from pathlib import Path
z=Path(__file__).resolve().parent; phase=z.parent;base=phase.parent; root=base.parents[1]; spec=root/'specs/035-portable-processing-cores/evidence'
read=lambda p:json.loads(Path(p).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows={}; controls={'color-mask-hue','color-mask-saturation','light-mask-blacks','light-mask-contrast','light-mask-exposure','light-mask-highlights','light-mask-shadows','light-mask-whites'}
faults=dict(wrongNamedPlane=1,sourceAsMask=1,misalignedY=1,oddOrigin=1,outside=1,unknownMode=1,unwrittenOrNaN=3,withdrawAfterSubmission=5)
for role in ('primary','secondary'):
 scope=read(z/'scope32'/f'{role}.json') if (z/'scope32'/f'{role}.json').exists() else read(z/'scope'/f'{role}.json')
 assert len(scope)==5 and all(i['different']==i['invalidOrMissed']==i['outsideNonzero']==0 and i['zeros']+i['ones']+i['fractional']==i['coverScalars'] for i in scope)
 a=read(z/'all32'/f'{role}.json');b=read(z/'product-all32'/f'{role}.json');f=read(z/'product-faults'/f'{role}.json');g=read(z/'product-shape'/f'{role}.json');rs=a['results'];ps=b['results'];rr=g['results'];fs=f['results']
 assert a['sourceSHA256']==b['sourceSHA256']==scope[0]['inputSHA256']==f['sourceSHA256']==g['sourceSHA256']
 assert len(rs)==len(ps)==16 and {(s['id'],s['state']) for s in rs}=={(i,j) for i in controls for j in (0,1)}
 assert [s['warmDonor'] for s in rs] == [False]+[True]*15 == [s['warmDonor'] for s in ps]
 for x,y in zip(rs,ps):
  w,h=x['nativeSize']; assert y['id']==x['id'] and y['state']==x['state'] and x['native']['pixels']==w*h and x['half']['pixels']==y['half']['pixels']==w*h//4
  for cmp in (x['native'],x['half'],y['half']):assert cmp['components']==cmp['nonfinite']==cmp['alpha']==cmp['changedPixels']==0
  assert x['display']['changedPixels']==y['display']['changedPixels']==0 and x['actualSHA256']==x['archive']==y['actualSHA256']==y['archive']
 assert len(fs)==2 and [s['warmDonor'] for s in fs]==[False,True]
 assert fs[0]['faults']==faults and fs[1]['faults']==dict(faults,partialReceiptLeavesPoisonedExterior=0)
 assert all(s['actualSHA256']==s['archive'] for s in fs)
 assert [s['warmDonor'] for s in rr]==[False,True]*3 and [s['archivedRecipe'] for s in rr]==[True,True,False,False,True,True]
 assert rr[0]['workRect'][:4]==rr[4]['workRect'][:4]!=rr[2]['workRect'][:4] and all(s['half']['components']==s['display']['changedPixels']==0 and s['actualSHA256']==s['archive'] for s in rr)
 rec=rs[0];ext=scope[0];rx,ry,rw,rh=rec['workRect'][:4];w,h=rec['nativeSize']
 rows[role]=dict(sourceSHA256=a['sourceSHA256'],size=[w,h],realScopeShapes=len(scope),scopePixelComparisons=sum(s['coverScalars'] for s in scope),
    fractionalEdgeValues=ext['fractional'],rectangle=[rx,ry,rw,rh],patchNativePixels=rw*rh,nativePixels=w*h,
    patchFraction=rw*rh/(w*h), compactCoverageAllocatedBytes=rec['maskBytes'],immutableExteriorAllocatedBytes=rec['donorAllocated'],
    exclusiveOutputAllocatedBytes=rec['halfBytes'],maxRustScratch=48*1024*1024,
    nativeCounters=sum(s['native']['pixels'] for s in rs),physicalHalfPixelComparisons=sum(s['half']['pixels'] for s in ps),
    nativeStatus='diagnostic physical band; cold-validated source exterior retained for the warm native witness',
    completeHalf='also compared on production C interface without a diagnostic native target',
    cold=1,warm=15,finalRGBA8Digests=[dict(id=s['id'],state=s['state'],sha256=s['archive']) for s in ps],
    shapeTransitions=[dict(warm=s['warmDonor'],workRect=s['workRect'][:4],archive=s['archivedRecipe'],digest=s['actualSHA256']) for s in rr],
    faults=[s['faults'] for s in fs])
docs=['Modules/ImageEdit/src/gpu/metal_surface/native_half.rs','Modules/ImageEdit/src/gpu/metal_surface/native_half_mask_region.wgsl','Modules/ImageEdit/include/rawmaster_image_metal.h','Modules/ImageEdit/Bridge/ImageEditLoader.c','Modules/ImageEdit/Bridge/include/ImageEditLoader.h','Modules/ImageEdit/Swift/RAWMasterImageKernel.swift','Sources/RAWMasterImaging/PreviewPortableMaskRegion.swift','Sources/RAWMasterImaging/PreviewPortableMaskTone.swift','Sources/RAWMasterImaging/PreviewPortableHalfFIT.swift','Sources/RAWMasterImaging/PreviewCanonicalHalfFIT.swift','Sources/RAWMasterImaging/PreviewNativeSource.swift','Tests/RAWMasterImagingTests/PreviewPortableMaskRegionTests.swift']
docs=[p for p in docs if (root/p).is_file()]
data=dict(phase=31,compiledOptIn='RAWMASTER_QA_PORTABLE_MASK_REGION_HALF_FIT=1 with RAWMASTER_QA_PORTABLE_MASK_HALF_FIT=1',
 scope='verified opaque FlashRaw native input, EXIF1, original extent, Apple M4 Max, ordinary primary settled 2400, isolated named hard radial control',
 wire=['rm_image_metal_mask_region_program_open_v1','rm_image_metal_mask_region_render_v1'],globalReceiptOnlyWhenPatchOnlyIsZero=True,
 inputs=rows,diagnosticRuntimeSHA256=sha(z/'bin/region-trace.dylib'),releaseCRuntimeSHA256=sha(z/'bin/region-product.dylib'),
 sourceSeals={p:sha(root/p) for p in docs},contractTests='rect-rust.log',
 budgetCounterexample=dict(path='standalone-buffer-page.log',heapReports=131293184,actualStandaloneAllocated=131301376,additionalBytes=8192,vmPageBytes=16384,limitBytes=512*1024*1024,originalResult='first sealed cold request returned nil',corrected='reserve the standalone VM-page rounding and verify allocatedSize within the unchanged 512 MiB boundary'),
 reportScope='32 real source/state pairs; 12 geometry frames and four fault/retry frames are separate. Timers from diagnostic or concurrent builds are excluded.')
if (z/'sealed-all32/secondary.json').exists():
 seals=set();passes=0;half_count=0
 for role in ('primary','secondary'):
  baseline=read(z/'product-all32'/f'{role}.json');candidate=read(z/'sealed-all32'/f'{role}.json')
  assert candidate['sourceSHA256']==baseline['sourceSHA256']
  for x,y in zip(candidate['results'],baseline['results'],strict=True):
   assert x['archive']==x['actualSHA256']==y['actualSHA256'] and x['half']['components']==x['half']['nonfinite']==x['display']['changedPixels']==0 and x['warmDonor']==y['warmDonor'];passes+=1;half_count+=x['half']['pixels']
  seals.add(candidate['runtimeSHA256'])
 assert len(seals)==1 and passes==32
 data['sealedInterface']=dict(runtimeSHA256=next(iter(seals)),archiveFrames=passes,physicalHalfPixelComparisons=half_count)
if (z/'legacy/verified.json').exists():data['olderRuntimes']=read(z/'legacy/verified.json')
if (z/'normal.json').exists():
 data['normalEntry']=read(z/'normal.json')
 if 'sealedInterface' in data:assert data['normalEntry']['runtimeSHA256']==data['sealedInterface']['runtimeSHA256']
if (z/'host-xctest.log').exists():
 line=next((t.strip() for t in (z/'host-xctest.log').read_text().splitlines() if 'testExteriorRequiresCompletedDisplaySameCaptureOriginalAndGeometry' in t and 'passed' in t),None)
 assert line;data['nativeLifecycleTest']=line
files=['CroppedScope.swift','CroppedScope32.swift','CroppedWitness.swift','ProductCroppedWitness.swift','build-witness.sh','build-c-witness.sh','build-scope.sh','build-scope32.sh','run-scope.sh','run-scope32.sh','verify-seal.sh','run-witness.py','run-product.py','shape.py','collect.py','legacy-region.py','rect-rust.log','layout.swift','standalone-buffer-page.log','normal-summary.py','README.txt','module/src/gpu/metal_surface/native_half.rs','module/src/gpu/metal_surface/native_half_region.wgsl','prep-native.py','normal.json','host-xctest.log','host-xctest-before.log']
files=[z/n for n in files if (z/n).is_file()]
for n in ('normal-raw','scope','scope32','all32','product-all32','product-faults','product-shape','sealed-all32','legacy'):
 files+=sorted((z/n).glob('**/*.json'))
# Exclude bulky bundles and user files: retain only source, raw receipts, and the loader checks.
extra=spec/'portable-mask-region-sources.tar.gz'
with extra.open('wb') as fh, gzip.GzipFile(fileobj=fh,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(set(files)):
  raw=p.read_bytes();name=p.relative_to(z).as_posix();i=tarfile.TarInfo(name);i.size=len(raw);i.mtime=0;i.mode=0o644;tar.addfile(i,io.BytesIO(raw))
data['reproduction']={'archive':extra.name,'sha256':sha(extra),'rawReceipts':{str(p.relative_to(z)):sha(p) for p in files if p.suffix=='.json'}}
out=spec/'portable-mask-region.json';out.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print(out,sha(out),sha(extra))

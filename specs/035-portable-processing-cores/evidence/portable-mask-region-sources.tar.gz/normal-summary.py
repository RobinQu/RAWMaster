import hashlib,json,math,statistics,re,sys
from pathlib import Path
z=Path(__file__).resolve().parent;parent=Path(sys.argv[1]).resolve()
ids={'color-mask-hue','color-mask-saturation','light-mask-blacks','light-mask-contrast','light-mask-exposure','light-mask-highlights','light-mask-shadows','light-mask-whites'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pct=lambda a: sorted(a)[math.ceil(len(a)*.95)-1]
source={};previous={};reference={};total=0;selected=0
for p in sorted(parent.glob('*.json')):
 m=re.fullmatch(r'([1-4])-(primary|secondary)-([01])',p.stem)
 if not m:continue
 ix,role,arm=m.groups();assert int(arm)==(0,1,1,0)[int(ix)-1]
 a=json.loads(p.read_bytes());assert a['verified'] and a['sourceSHA256']==a['sourceSHA256After'] and len(a['operations'])==37
 if role not in reference:
  ref=json.loads((z/'product-all32'/f'{role}.json').read_bytes());reference[role]={(s['id'],s['state']):s['archive'] for s in ref['results']};assert a['sourceSHA256']==ref['sourceSHA256']
 q=source.setdefault(role,dict(sha=a['sourceSHA256'],hostSHA256=a['binarySHA256'],arms={}))
 assert q['hostSHA256']==a['binarySHA256']
 kind=q['arms'].setdefault(arm,dict(samples=[],peaks=[],runs=[],byOperation={}))
 kind['runs'].append(dict(index=ix,receiptSHA256=sha(p)));kind['peaks'].append(a['processPeakPhysicalFootprintBytes'])
 for op in a['operations']:
  for s in op['samples']:
   key=(role,op['id'],s['state'],s['quality']);sign=(s['digest'],s['approximate'])
   assert previous.setdefault(key,sign)==sign;total+=1
   stages=[e for e in s['stages'] if e['operation'] in ('PreviewPortableMaskRegionPatch','PreviewPortableMaskRegionFull','PreviewPortableMaskHalfFIT') and e['outcome'] in ('成功','succeeded')]
   matched=op['id'] in ids and s['quality']=='settled'
   if not matched:assert not stages;continue
   assert not s['approximate'] and s['digest']==reference[role][(op['id'],s['state'])];selected+=1
   sub=kind['byOperation'].setdefault(op['id'],[]);sub.append(s['ms'])
   assert len(stages)==1,(p.name,op['id'],s['state'],stages)
   e=stages[0];operation=e['operation']
   assert (operation=='PreviewPortableMaskHalfFIT')==(arm=='0')
   kind['samples'].append(dict(ms=s['ms'],stage=e['ms'],operation=operation,pixels=e['pixels']))
assert total==1184 and selected==128 and len(previous)==296
for role,q in source.items():
 for arm,s in q['arms'].items():
  data=s.pop('samples');assert len(data)==32 and len(s['runs'])==2
  score=[v['ms'] for v in data];stage=[v['stage'] for v in data]
  splits={}
  for name in sorted({v['operation'] for v in data}):
   ev=[v for v in data if v['operation']==name];splits[name]=dict(n=len(ev),frameP50MS=statistics.median(v['ms'] for v in ev),stageP50MS=statistics.median(v['stage'] for v in ev))
  s.update(byEvent=splits,samples=len(data),p50MS=statistics.median(score),p95NearestMS=pct(score),stageP50MS=statistics.median(stage),
     events={op:sum(v['operation']==op for v in data) for op in sorted({v['operation'] for v in data})},
     successfulPixelCounts=sorted({v['pixels'] for v in data}),byOperationP50={op:statistics.median(times) for op,times in s.pop('byOperation').items()})
out=z/'normal.json';out.write_text(json.dumps(dict(frames=total,distinctFrames=len(previous),targetSettled=selected,otherFrames=total-selected,
   reference='same sealed helper and eight independent processes, reversible ABBA toggles for disjoint target families; baseline uses the previously shipped full named-mask capability',
   runtimeSHA256=(parent/'runtime.sha256').read_text().split()[0],sources=source),indent=2,sort_keys=True)+'\n');print(out,sha(out))

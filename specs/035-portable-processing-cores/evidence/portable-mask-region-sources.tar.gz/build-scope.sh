#!/bin/zsh
set -euo pipefail
study="$PWD/output/035-development/phase-ac/radial"
products="$PWD/.build/release"
maps="$PWD/.build/out/Intermediates.noindex/GeneratedModuleMaps"
typeset -a flags objects
for name in CFlashRaw CImageEditABI CLibraryCatalogABI; do
   flags+=(-Xcc "-fmodule-map-file=$maps/$name.modulemap")
done
for name in RAWMasterImaging RAWMasterCore RAWMasterImage RAWMasterLibrary RAWMasterPhotoExport MaskAI CFlashRaw CImageEditABI CLibraryCatalogABI; do objects+=("$products/$name.o"); done
for name in RAWMaster_RAWMasterImaging RAWMaster_RAWMasterCore ImageEdit_RAWMasterImage LibraryCatalog_RAWMasterLibrary PhotoExport_RAWMasterPhotoExport; do 
  [[ -d "$study/bin/$name.bundle" ]] || cp -cR "$products/$name.bundle" "$study/bin/"
done
swiftc -O -parse-as-library -swift-version 5 -target arm64-apple-macos15.0 -I "$products" -I "$study/iosurface" -I "$PWD/Sources/CSQLite" -I "$PWD/experiments/MaskAI/Sources/CONNXRuntime" "${flags[@]}" "$study/CroppedScope.swift" "${objects[@]}"  -framework IOSurface -framework CoreVideo -lc++ -lsqlite3 -lz -framework AVKit -o "$study/bin/scope"

#!/bin/zsh
set -euo pipefail
repo="$PWD"
out="$repo/output/035-development"
z="$out/phase-ac/radial"
host="$out/phase-ac/photo-combined/profile-settled-photo"
seal="$out/candidate-batch31-optical-snapshots-verified/RAWMasterImagingTests.xctest/Contents/Resources/ImageEdit_RAWMasterImage.bundle/Contents/Resources/rawmaster-image.runtime"
python3 "$z/legacy-region.py" "$host"
RM_AC_RUNTIME="$seal" python3 "$z/run-product.py" sealed-all32 primary,secondary correct all
zsh "$z/run-scope32.sh"

import copy,json
from pathlib import Path
z=Path(__file__).resolve().parent;base=z.parents[1]
for role,src in [('primary',base/'candidate-batch30-native-mask-ring-final-enabled/photo-operators-v2.json'),('secondary',base/'fit-pass-study/native-02/release-02-secondary-0.json')]:
 data=json.loads(src.read_bytes());op=next(op for op in data['operations'] if op['id']=='light-mask-exposure')
 b=copy.deepcopy(op)
 for s in b['stateDescriptions']:
  layer=s['adjustmentsV3']['masks'][0];layer['center']={'x':0.15,'y':0.85};layer['radiusX']=0.17;layer['radiusY']=0.08
 b['firstStateFullFrameDigests']=['independent-stock']*2
 data['operations']=[op,b,op]
 dest=z/'shape';dest.mkdir(exist_ok=True)
 (dest/(role+'.json')).write_text(json.dumps(data))

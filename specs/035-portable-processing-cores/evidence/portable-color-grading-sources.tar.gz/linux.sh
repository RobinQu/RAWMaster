#!/usr/bin/env bash
set -euo pipefail
root="$PWD"
state="$root/output/035"
evidence="$root/output/035-development/phase-ab/grading"
docker run --rm -i --platform linux/arm64 --cpus=2 \
  --mount "type=bind,source=$root,target=/repo,readonly" \
  --mount "type=bind,source=$state/linux-cargo-registry,target=/usr/local/cargo/registry" \
  --mount "type=bind,source=$state/linux-image-target,target=/target" \
  --mount "type=bind,source=$evidence,target=/evidence" \
  -e CARGO_TARGET_DIR=/target --workdir /repo \
  rust@sha256:ade39a710ef85f3506cffcfec3e8a24ba090badef1dff2fb798f71d878833fea sh -s <<'CONTAINER'
set -eu
export PYTHONDONTWRITEBYTECODE=1
rustc --version --verbose
cargo test --locked --offline --release --no-default-features --jobs 2 --manifest-path Modules/ImageEdit/Cargo.toml > /evidence/linux-cpu-tests.log 2>&1
cargo build --locked --offline --release --no-default-features --jobs 2 --manifest-path Modules/ImageEdit/Cargo.toml
cp /target/release/librawmaster_image.so /evidence/linux-grade-cpu.so
python3 /evidence/replay.py /evidence/linux-grade-cpu.so /evidence/full-first /evidence/actual-linux-cpu.json
apt-get -qq update
apt-get -qq install -y libvulkan1 mesa-vulkan-drivers
export XDG_RUNTIME_DIR=/tmp VK_ICD_FILENAMES=/usr/share/vulkan/icd.d/lvp_icd.aarch64.json WGPU_BACKEND=vulkan
dpkg-query -W libvulkan1 mesa-vulkan-drivers
cargo test --locked --offline --release --no-default-features --features gpu --jobs 2 --manifest-path Modules/ImageEdit/Cargo.toml -- --include-ignored --test-threads=1 > /evidence/linux-vulkan-tests.log 2>&1
cargo build --locked --offline --release --no-default-features --features gpu --jobs 2 --manifest-path Modules/ImageEdit/Cargo.toml
cp /target/release/librawmaster_image.so /evidence/linux-grade-vulkan.so
python3 /evidence/replay.py /evidence/linux-grade-vulkan.so /evidence/full-first /evidence/actual-linux-vulkan.json --gpu
CONTAINER

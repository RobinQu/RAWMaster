#!/usr/bin/env bash
set -euo pipefail
stage="$PWD/output/035-development/phase-ab/grading"
products="$PWD/.build/release"
maps="$PWD/.build/out/Intermediates.noindex/GeneratedModuleMaps"
mkdir -p "$stage/bin"
xcrun clang++ -std=c++17 -O2 -fobjc-arc -c -IModules/ImageEdit/include "$stage/bridge/port.mm" -o "$stage/bridge/port.o"
mod_flags=()
for module in CFlashRaw CImageEditABI CLibraryCatalogABI; do mod_flags+=(-Xcc "-fmodule-map-file=$maps/$module.modulemap"); done
objects=()
for module in RAWMasterImaging RAWMasterCore RAWMasterImage RAWMasterLibrary RAWMasterPhotoExport MaskAI CFlashRaw CImageEditABI CLibraryCatalogABI; do objects+=("$products/$module.o"); done
for bundle in RAWMaster_RAWMasterImaging RAWMaster_RAWMasterCore ImageEdit_RAWMasterImage LibraryCatalog_RAWMasterLibrary PhotoExport_RAWMasterPhotoExport; do
    [[ -e "$stage/bin/$bundle.bundle" ]] || ln -s "$products/$bundle.bundle" "$stage/bin/$bundle.bundle"
done
swiftc -O -parse-as-library -swift-version 5 -target arm64-apple-macos15.0 -I "$products" -I "$stage/bridge" -I "$PWD/Sources/CSQLite" -I "$PWD/experiments/MaskAI/Sources/CONNXRuntime" \
  "${mod_flags[@]}" "$stage/GradeWitness.swift" "${objects[@]}" "$stage/bridge/port.o" -framework IOSurface -framework CoreVideo -lc++ -lsqlite3 -lz -framework AVKit -o "$stage/bin/grade"

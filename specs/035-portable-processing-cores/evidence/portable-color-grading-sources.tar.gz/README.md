# Spec 035 的全局色轮对照探针

在 RAWMaster 仓库根目录将源码归档解到 `output/035-development/phase-ab/grading/`。
先完成当前版本 `swift build -c release --build-tests -Xswiftc -enable-testing --jobs 7`，再以 Bash 执行归档中的 `build.sh`。
探针使用 Release 的 RAW 解码、原 V3 色轮和定稿对象，并从 `AB_IMAGE_RUNTIME`
读取封存的 `rawmaster-image.runtime`。在环境中设置匹配的
`RAWMASTER_FLASHRAW_LIBRARY`，传入原片、该原片的完整基线照片 JSON、输出 JSON
和 `grading-balance,grading-blending,grading-luminance` 四个位置参数。
原件和基线的 SHA-256 在结果中登记。生产图片和编译产物没有打包。

整图探针用公共 IOSurface ABI 处理原尺寸数据，在同一硬件采样器读取半幅，
再用原定稿显示链比较完整 sRGB8。逐图另外记录带边界的稀疏窗口。
缓冲区对照从这些窗口读取输入、原 V3 输出和借入纹理输出，通过同一公开配方 C ABI
执行，每组分别记录输入、查验基准及候选的 SHA-256。用
`python3 replay.py <runtime> <samples-dir> <report.json>` 运行 CPU。
同一命令加 `--gpu` 运行 Metal 或 Vulkan。Linux 容器须与 macOS 探针使用同样的
样本，`linux.sh` 记录本次 Docker 镜像、依赖目录与 Vulkan 设置，可将夹具目录
`full-first` 指向当前探针输出。色轮的数值门槛为每个分量绝对差
`2e-6`。SwiftUI 主画布定稿另维持完整显示逐位比对。

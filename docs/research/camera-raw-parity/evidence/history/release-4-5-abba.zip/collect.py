"""Run all failing native controls and interactive groups, plus the 15-file workload, in A/B/B/A order."""
import hashlib,json,os,subprocess,sys,time,zipfile
from datetime import datetime,timezone
from pathlib import Path
root=Path.cwd()
lab=root/'output/performance/release-background-20261122'
reference,candidate=[lab/v for v in sys.argv[1:3]]
out=lab/'frozen-regression-repeats'
out.mkdir(exist_ok=False)
exe=subprocess.check_output(['xcrun','--find','xctest'],text=True).strip()
raw=root/'output/performance/acr-benchmark.ARW'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def failures(kind):
 return sorted({error.split(':',1)[0] for error in read(candidate/(kind+'-comparison.json'))['failures']})
groups=failures('interactive');controls=failures('control')
base={**os.environ,'RAWMASTER_FLASHRAW_LIBRARY':str(root/'output/tools/flashraw-target/release/libflashraw_capi.dylib'),
      'RAWMASTER_SCENE_DEPTH_MODEL':str(root/'output/tools/monocular-depth/DepthAnythingV2SmallF16.mlmodelc')}
report={'protocol':'frozen-native-regression-abba-v1','reference':reference.name,'candidate':candidate.name,
        'recordedAt':datetime.now(timezone.utc).isoformat(),'rawSHA256':digest(raw),
        'interactiveOperations':groups,'controlOperations':controls,'rounds':[]}
for i,origin in enumerate((reference,candidate,candidate,reference),1):
 product=origin/'test-products/RAWMasterImagingTests.xctest'
 binary=digest(product/'Contents/MacOS/RAWMasterImagingTests')
 assert binary==read(origin/'test-build.json')['testBinariesSHA256']['RAWMasterImagingTests']
 dest=out/str(i);dest.mkdir()
 round={'round':i,'origin':origin.name,'binarySHA256':binary,'commands':{}}
 plan=[('image','ImagePerformanceTests',{'RAWMASTER_RUN_IMAGE_PERF':'1','RAWMASTER_IMAGE_PERF_SOURCE':'/Volumes/SM9100-8T/RAW Dumps/2026-10-06-a/DCIM/100MSDCF','RAWMASTER_IMAGE_PERF_COUNT':'15','RAWMASTER_IMAGE_PERF_REPORT':str(dest/'image.json'),'RAWMASTER_PERF_PHASE':'regression','RAWMASTER_IMAGE_PERF_BASELINE':str(reference/'image.json')},'image.json')]
 if groups:
  plan.append(('interactive','EditingInteractivePerformanceTests',{'RAWMASTER_REQUIRE_FLASHRAW':'1','RAWMASTER_CANONICAL_FLASHRAW':'0','RAWMASTER_INTERACTIVE_PERF':'1','RAWMASTER_INTERACTIVE_PERF_ONLY':','.join(groups),'RAWMASTER_INTERACTIVE_PREWARM':'1','RAWMASTER_INTERACTIVE_RAW_BASE_CACHE':'1','RAWMASTER_INTERACTIVE_PERF_SOURCE':str(raw),'RAWMASTER_INTERACTIVE_PERF_OUTPUT':str(dest/'interactive')},'interactive/interactive-performance.json'))
 if controls:
  plan.append(('controls','IndividualControlPerformanceTests/testChangedControlsOnResidentRAW',{'RAWMASTER_CONTROL_RAW':str(raw),'RAWMASTER_CONTROL_REPORT':str(dest/'controls.json'),'RAWMASTER_CONTROL_SAMPLES':'20','RAWMASTER_CONTROL_ONLY':','.join(controls)},'controls.json'))
 for name,selector,env,path in plan:
  begin=time.monotonic()
  with (dest/(name+'.log')).open('w') as log:proc=subprocess.run([exe,'-XCTest','RAWMasterImagingTests.'+selector,str(product)],env={**base,**env},stdout=log,stderr=subprocess.STDOUT,timeout=200)
  rawfile=dest/path
  if not rawfile.is_file():raise RuntimeError(f'{origin}/{selector} failed to produce raw records')
  round['commands'][name]={'selector':selector,'exitCode':proc.returncode,'seconds':time.monotonic()-begin,'report':str(rawfile.relative_to(out)),'sha256':digest(rawfile)}
  print(i,origin.name,name,proc.returncode,flush=True)
 report['rounds'].append(round);(out/'index.json').write_text(json.dumps(report,indent=2)+'\n')
report['finishedAt']=datetime.now(timezone.utc).isoformat()
(out/'index.json').write_text(json.dumps(report,indent=2)+'\n')

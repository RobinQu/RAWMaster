const {app,BrowserWindow} = require('electron');
const fs = require('node:fs');
const layer = require('./layer.node');
app.setPath('userData',process.env.RAWMASTER_LF_PROFILE);
app.commandLine.appendSwitch('remote-debugging-port','0');
app.commandLine.appendSwitch('disable-background-networking');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.setActivationPolicy('prohibited');
app.whenReady().then(async()=>{
  layer.configure();
  const area=require('electron').screen.getPrimaryDisplay().workArea;
  const win = new BrowserWindow({show:false, focusable:false, skipTaskbar:true, frame:false, x:area.x+2,y:area.y+2,width:Math.min(area.width-4,1780),height:Math.min(area.height-4,1090), webPreferences:{backgroundThrottling:false,contextIsolation:true,sandbox:true,nodeIntegration:false}});
  const id=layer.configure(win.getNativeWindowHandle());
  win.showInactive();
  layer.configure(win.getNativeWindowHandle());
  fs.writeFileSync(process.env.RAWMASTER_LF_WINDOW,JSON.stringify({id,bounds:win.getBounds(),chrome:process.versions.chrome,electron:process.versions.electron}));
  await win.loadURL(process.env.RAWMASTER_LF_ORIGIN);
}).catch(e=> {console.error(String(e));app.exit(1);});

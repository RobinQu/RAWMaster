import argparse,hashlib,importlib.util,json,os,secrets,subprocess,sys,tempfile,threading,time
from datetime import datetime,timezone
from functools import partial
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen
root=Path.cwd(); scripts=root/'scripts/performance';sys.path.insert(0,str(scripts)); spec=importlib.util.spec_from_file_location('lightflow_ui',scripts/'lightflow-ui.py');lf=importlib.util.module_from_spec(spec);spec.loader.exec_module(lf)
base=root/'output/performance/lf-window-observer/electron';site=root/'output/lightflow-research/site';raw=root/'output/performance/acr-benchmark.ARW';binary=base/'runtime/Electron.app/Contents/MacOS/Electron';app='org.rawmaster.benchmark.lightflow-chromium';helper=root/'output/performance/acroperation-window/capture-modal-checked';args=argparse.ArgumentParser();args.add_argument('--run',choices=('setup','single','all'),default='setup');opt=args.parse_args()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def front():return subprocess.check_output(['osascript','-l','JavaScript','-e','ObjC.import("AppKit"); $.NSWorkspace.sharedWorkspace.frontmostApplication.bundleIdentifier.js'],text=True).strip()
assert sha(site/lf.EDITOR)==lf.EDITOR_SHA
prior=front();served=set();route='/'+secrets.token_urlsafe(18)+'/benchmark.ARW';handler=partial(lf.EditorFiles,directory=str(site),raw=raw,raw_path=route,served=served)
with tempfile.TemporaryDirectory() as folder,ThreadingHTTPServer(('127.0.0.1',0),handler) as server:
 io=Path(folder);origin=f'http://127.0.0.1:{server.server_port}';threading.Thread(target=server.serve_forever,daemon=True).start(); profile=io/'profile'; marker=io/'window.json'; env=dict(os.environ,RAWMASTER_LF_PROFILE=str(profile),RAWMASTER_LF_WINDOW=str(marker),RAWMASTER_LF_ORIGIN=origin); proc=subprocess.Popen([binary,base/'main.cjs'],env=env,stdout=open(base/'browser.log','w'),stderr=subprocess.STDOUT)
 try:
  def wait(fn,msg,timeout=16):
   end=time.monotonic()+timeout
   while time.monotonic()<end:
    got=fn()
    if got:return got
    if proc.poll() is not None: raise RuntimeError('Host exited '+str(proc.returncode))
    time.sleep(.1)
   raise TimeoutError(msg)
  wait(marker.exists,'non-activating WindowServer window');wait((profile/'DevToolsActivePort').exists,'private DevTools port');port=(profile/'DevToolsActivePort').read_text().splitlines()[0]
  def tab():return next((x for x in json.load(urlopen(f'http://127.0.0.1:{port}/json/list')) if x['type']=='page' and x['url'].startswith(origin)),None)
  page=wait(tab,'local LightFlow page'); cdp=lf.DevTools(page['webSocketDebuggerUrl']); active=front();assert active!=app,(prior,active);wait(lambda:cdp.evaluate('!!window.__lightflow?.develop'),'stock editor');cdp.evaluate('window.__lightflow.importUrls(['+json.dumps(origin+route)+'])');photo=wait(lambda:cdp.evaluate('window.__lightflow.stores.catalog.get().order[0]'),'RAW catalog');cdp.evaluate('window.__lightflow.setActive('+json.dumps(photo)+');window.__lightflow.setWorkspace("develop")');wait(lambda:lf.view_geometry(cdp),'full-size RAW',40)
  title='LightFlow RAW benchmark '+secrets.token_hex(4);cdp.evaluate('document.title='+json.dumps(title));win=json.loads(marker.read_text()); windows=json.loads(subprocess.check_output([helper,'list',app]));print('windows',[(w['id'],w['title']) for w in windows],win,flush=True); match=next(w for w in windows if w['id']==win['id']);state=lf.set_zoom(cdp,2368);bounds,roi=lf.photo_roi(state,match)
  session={'title':match['title'],'build':'2d41ab1','windowID':win['id'],'windowBundle':app,'visible':True,'sourceSHA256':sha(raw),'browserBinarySHA256':sha(binary),'electron':win,'tab':page['webSocketDebuggerUrl'],'pid':proc.pid,'photo':photo,'view':state,'uiSHA256':{f:sha(site/f) for f in sorted(served) if (site/f).is_file()},'foregroundBefore':prior,'foregroundAfterSetup':front(),'photoRectPixels':bounds,'roi':roi}
  (base/'setup.json').write_text(json.dumps(session,indent=2)+'\n');print('ready', bounds,roi,session['foregroundAfterSetup'],flush=True)
  if opt.run!='setup':
   params=argparse.Namespace(raw=raw,binary=helper,output=base/('screen-'+opt.run+'.json'),frames=base/('frames-'+opt.run),samples=10,settle=.55,photo_width=2368,operations=['light-exposure'] if opt.run=='single' else None)
   lf.capture(cdp,session,params)
 finally:
  proc.terminate()
  try:proc.wait(timeout=4)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
  server.shutdown();print('front',prior,front(),flush=True)

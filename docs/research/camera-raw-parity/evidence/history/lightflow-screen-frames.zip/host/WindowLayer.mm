#import <AppKit/AppKit.h>
#include <node_api.h>
#include <cstring>
static napi_value configure(napi_env env,napi_callback_info info){
  size_t argc=1; napi_value args[1],out; napi_get_cb_info(env,info,&argc,args,NULL,NULL);
  [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];
  if(argc==1){
    void *bytes=nullptr;size_t count=0;napi_get_buffer_info(env,args[0],&bytes,&count);
    if(!bytes || count < sizeof(void *)){napi_throw_error(env,nullptr,"Invalid window handle");return nullptr;}
    void* opaque=nullptr;std::memcpy(&opaque,bytes,sizeof(opaque));NSView *view=(__bridge NSView *)opaque;
    if(![view isKindOfClass:[NSView class]] || !view.window){napi_throw_error(env,nullptr,"No AppKit content view");return nullptr;}
    NSWindow *w=view.window;w.level=CGWindowLevelForKey(kCGDesktopIconWindowLevelKey)+1;w.ignoresMouseEvents=YES;w.hidesOnDeactivate=NO;w.excludedFromWindowsMenu=YES;w.animationBehavior=NSWindowAnimationBehaviorNone;
    [w orderBack:nil];napi_create_int64(env,w.windowNumber,&out);return out;
  }
  napi_get_undefined(env,&out);return out;
}
static napi_value init(napi_env env,napi_value exports){napi_value fn;napi_create_function(env,"configure",NAPI_AUTO_LENGTH,configure,nullptr,&fn);napi_set_named_property(env,exports,"configure",fn);return exports;}
NAPI_MODULE(NODE_GYP_MODULE_NAME,init)
